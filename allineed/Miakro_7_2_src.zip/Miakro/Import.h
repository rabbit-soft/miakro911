#ifndef ImportH
#define ImportH

#include "Miakro.h"
#include "Rabbit.h"

const unsigned short max_breeds = 50;

enum OPER { OP_VOID,CHANGE_TIER_TYPE,REMAP_RABBIT };

//---------------------------------------------------------------------------

class Header;
class Mapper;
bool ImportFile(const AnsiString& Path);
void ClearBase();
void FixNeededFuckers();
Mapper * ProcessMap();
enum { H_NAMES,H_BREEDS,H_FARM,H_FA,H_MO,H_CHIL,H_KFA,H_KMO,H_KCHIL,H_NOTES,H_BUTCHER,H_MAX };

typedef Set<char,0,127> ConvSet;
extern ConvSet HdSets[H_MAX];

//---------------------------------------------------------------------------

struct DbHead
{
	char					 vers; 				// 3
	char					 year;    		// ������
	char					 month;    		// ������
	char					 date;    		// ������
	unsigned long  numrec;			// ����� �������
	unsigned short headlen;  		// ����� ���������
	unsigned short reclen;	  	// ����� ������
	char           reserve[20]; // �������������
};                            // ����� �� 32 ����� �� ������ ���� ������ � +0D

//---------------------------------------------------------------------------

struct DbRec
{
	char					 name[11];		// ���
	char					 type; 				// ���
	char 					 addr[4];			//
	char					 len;  				// ����� ����
	char 					 dec;	  			// ���. ����
	char           m_user[2];
	char 					 id;
	char					 m_user2[2];
	char 					 setid;
	char           reserve[8]; 	// �������������
};                            

//---------------------------------------------------------------------------

class Field
{
	private:
		char 					name[11];
		char 					type;      		// C N L D M
		union
		{
			unsigned short bias;       // �������� �� ������ ������
			char *				 addr;       // ��������
		};
		unsigned char len;       		// ����� ����
		char					dec;       		// ����� ������ ����� ���������� �����
		char     			reserved[14];
	public:
									__fastcall Field(TStream& s);
						 void __fastcall SetBias(unsigned char x) { bias = x; }
		unsigned char __fastcall GetBias() { return bias; }
						 char	__fastcall GetLen()  { return len;  }
		unsigned char __fastcall GetType() { return type; }
};

//---------------------------------------------------------------------------

class FieldList : public TList
{
	private:
	public:
						__fastcall FieldList(TStream& s);
						__fastcall ~FieldList();
		Field * __fastcall GetField(int i) { return (Field *) Items[i]; }
};

//---------------------------------------------------------------------------

class Header
{
	private:
		FieldList 		 *fields;
		char 					 *start;
		unsigned long		numrec;
		unsigned short	reclen;
		unsigned short	__fastcall Breeder(char *rec,Rabbit *r,char field);
		void 						__fastcall Namer(char *rec,Rabbit *r,char field,SEX ctrl = SEX_VOID);
		void						__fastcall Farmer(char *rec,Rabbit *r,char farm,char area,Mapper *mapper);
		void					  __fastcall Blooder(char *rec,char field);
		void 						__fastcall Parenter(char *rec,Rabbit *r,char field,SEX sex);
		int	 						__fastcall ExtractDate(const char *field);
		const char * 		__fastcall CheckName(char *name,char *adr);
	public:
		static Rabbit *glob_rab;
									__fastcall Header(TStream& s,char i);
									__fastcall ~Header() { if (fields) free(fields); if (start) free(start); }
		char * 				__fastcall GetRecord(int n);
		unsigned char __fastcall GetFieldLen(int i) { return fields->GetField(i)->GetLen(); }
		char 					__fastcall GetFieldType(int i) { return fields->GetField(i)->GetType(); }
		char * 				__fastcall GetField(char *rec,int field,bool adr = false);
		FieldList *		__fastcall GetFields() { return fields; }
		bool    			__fastcall IsTrue(char *rec,int field) { return *GetField(rec,field) == 'T'; }
		char * 				__fastcall GetField(int rec,int field) { return GetField(GetRecord(rec),field); }
		char * 				__fastcall FindRecByKey(char *key,char keylen,unsigned char k_field_num);
		void 					__fastcall InsertNames();
		void 					__fastcall InsertBreeds();
		void 					__fastcall InsertFarm(Mapper *mapper);
		void 					__fastcall InsertKFathers(Mapper *mapper);
		void 					__fastcall InsertKMothers(Mapper *mapper);
		void 					__fastcall InsertKChildren(Mapper *mapper);
		char *				__fastcall FindRabbitByName(const char *name,char field);
		friend bool ImportFile(const AnsiString& Path);
		friend void FixNeededFuckers();
};

//---------------------------------------------------------------------------

class Map
{
	public:
		OPER					 oper;
		unsigned short block;
		unsigned short shed;
		unsigned short minished;
		unsigned short id;
		TIER					 u_tier; 		// ��������������� ���� �������� ��� ������������� �����
		TIER					 l_tier; 		// ��������������� ���� ������� �����
		TIER_ID     	 tid; 			// ����- ��� �����������
		char 					 area;  		// ������ ������ �������
				           __fastcall Map(OPER op = OP_VOID) { oper = op; block = shed = minished = id = area = 0; tid = SINGLE_TIER; u_tier = T_BARIN; l_tier = T_FEMALE; }
		void           __fastcall SetTierType(TIER type,bool lower = false) { if (lower) l_tier = type; else u_tier = type; }
		void           __fastcall SetId(unsigned short i) { id = i; }
		unsigned short __fastcall GetId() const { return id; }
		TIER           __fastcall GetUpperTierType() const { return u_tier; }
		TIER           __fastcall GetLowerTierType() const { return l_tier; }
		bool           __fastcall HasTwoTiers() const { return tid != SINGLE_TIER; }
		void           __fastcall SetBlock(unsigned short b) { block = b; }
		unsigned short __fastcall GetBlock() const { return block; }
		void           __fastcall SetShed(unsigned short s) { shed = s; }
		unsigned short __fastcall GetShed() const { return shed; }
		void           __fastcall SetMiniShed(unsigned short s) { minished = s; }
		unsigned short __fastcall GetMiniShed() const { return minished; }
		void           __fastcall SetArea(char a) { area = a; }
		char           __fastcall GetArea() const { return area; }
		void           __fastcall SetTierId(TIER_ID t_id) { tid = t_id; }
		TIER_ID        __fastcall GetTierId() const { return tid; }
		OPER 					 __fastcall GetOper() const { return oper; }
		friend bool operator == (const Map& a,const Map& b);
};

//---------------------------------------------------------------------------

class Maps : public TList
{
	public:
					__fastcall Maps() : TList() {}
					__fastcall ~Maps() { for (int i = 0; i < Count; i++) delete GetMap(i); }
		Map * __fastcall GetMap(int i) { return (Map *) Items[i]; }
};

//---------------------------------------------------------------------------

class Mapper
{
	public:
		TList *ids;
		TList *tns;
		Maps *src;
		Maps *dest;
					__fastcall Mapper() { src = new Maps; dest = new Maps; ids = new TList; tns = new TList; }
					__fastcall ~Mapper() { delete src; delete dest; delete ids; delete tns; }
		Map * __fastcall AddSrc(OPER op) { Map *m; src->Add(m = new Map(op)); return m; }
		Map * __fastcall AddDest(OPER op = OP_VOID) { Map *m; dest->Add(m = new Map(op)); return m; }
		Map * __fastcall GetDest(int i) { return i >= 0 ? dest->GetMap(i) : NULL; }
		Map * __fastcall GetSrc(int i) { return i >= 0 ? src->GetMap(i) : NULL; }
		int   __fastcall Find(int id,OPER oper = OP_VOID);
		int   __fastcall FindRabMap(int id,char area,bool use_area = true);
		bool  __fastcall FindAtLeft(int id);
		void	__fastcall AddTreeNodeRef(TTreeNode *tn,unsigned short mf_id) { ids->Add((void *) mf_id); tns->Add(tn); }
};

//---------------------------------------------------------------------------

#endif
