#include <vcl.h>
#pragma hdrstop

#include "ReportYoung.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"
TRepYoungForm *RepYoungForm;

//---------------------------------------------------------------------------

__fastcall TRepYoungForm::TRepYoungForm(TComponent* Owner) : TForm(Owner)
{
}

//---------------------------------------------------------------------------

