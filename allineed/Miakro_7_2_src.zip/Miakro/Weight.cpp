#include <vcl.h>
#pragma hdrstop

#include "Weight.h"
#include "Zoo.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"
TWeightForm *WeightForm;

//---------------------------------------------------------------------------

__fastcall TWeightForm::TWeightForm(TComponent* Owner) : TForm(Owner)
{
}

//---------------------------------------------------------------------------

void __fastcall TWeightForm::FormShow(TObject *)
{
  Date->Date = ZooForm->ZooDater->Date;
  Weight->Clear();
}

//---------------------------------------------------------------------------

void __fastcall TWeightForm::FormCloseQuery(TObject *,bool &CanClose)
{
  if (ModalResult != mrOk) return;
  try
  {
    int x = Weight->Text.ToInt();
    if (x < 10 || x > 20000) throw(NULL);
    if ((int) Date->Date > today)
    {
      Application->MessageBox("���� �� ����� ���� � �������!","������",MB_APPLMODAL|MB_ICONERROR|MB_OK);     Weight->SetFocus();
      Date->SetFocus();
      CanClose = false;
    }
  }
  catch (...)
  {
    Application->MessageBox("��� ����� �����������!","������",MB_APPLMODAL|MB_ICONERROR|MB_OK);
    Weight->SetFocus();
    CanClose = false;
  }

}

//---------------------------------------------------------------------------

