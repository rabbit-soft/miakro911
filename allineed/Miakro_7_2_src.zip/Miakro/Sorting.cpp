#include <vcl.h>
#pragma hdrstop

#include <assert.h>

#include "Miakro.h"
#include "Sorting.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)

//---------------------------------------------------------------------------

TStream& operator >> (TStream& s,TList *tl)
{
	int max,v;
	s.ReadBuffer(&max,sizeof(max));
	tl->Capacity = max;
	while (max--)
	{
		s.ReadBuffer(&v,sizeof(v));
		tl->Add((void *) v);
	}
	return s;
}

//---------------------------------------------------------------------------

TStream& operator << (TStream& s,TList *tl)
{
	int v = tl->Count;
	s.WriteBuffer(&v,sizeof(v));
	for (int i = 0; i < tl->Count; s.WriteBuffer(&v,sizeof(v)))
		v = (int) tl->Items[i++];
	return s;
}

//---------------------------------------------------------------------------

static int __stdcall SorterProc(long a,long b,long which)
{
	const TListItem *x = (const TListItem *) a;
	const TListItem *y = (const TListItem *) b;
	const Srt *sorter = (const Srt *) which;

	int res = y->Checked - x->Checked;
	if (res) return res;
	TListColumn *lc;
	int col;
	int max = sorter->columns->Count;
	String A,B;
	try
	{
		for (int i = 0; !res && i < max; i++)
		{
			lc = sorter->GetColumn(i); // ���������� ����� TListColumn
			col = sorter->GetIndex(i);
			if (col)
			{
				if (x->SubItems->Count >= col)
					A = x->SubItems->Strings[col - 1].Trim();
				else
					A == "";
				if (y->SubItems->Count >= col)
					B = y->SubItems->Strings[col - 1].Trim();
				else
					B == "";
			}
			else
			{
				A = x->Caption;
				B = y->Caption;
			}
			switch (lc->Tag)
			{
				case as_dat:
					res = StrToDate(A) - StrToDate(B);
					break;
				case as_flo:
					if (!A.IsEmpty() && !B.IsEmpty() && isdigit(A[1]) && isdigit(B[1]))
					{
						double d = atof(A.c_str()) - atof(B.c_str());
						res = d ? (d > 0 ? 1 : -1) : 0;
					}
					else
						res = A.AnsiCompareIC(B);
					break;
				case as_int:
					res = atoi(A.c_str()) - atoi(B.c_str());
					break;
				case as_sex:
				{
					int al = A.Length() - 2;
					int bl = B.Length() - 2;
					res = al <= 0 || bl <= 0 ? A[1] - B[1] : atoi(A.SubString(3,al).c_str()) - atoi(B.SubString(3,bl).c_str());
					break;
				}
				case as_cla:
					if (res = A.AnsiCompareIC(B))
					{
						switch (A[1])
						{
							case '�':
								res = -1;
								break;
							case '�':
								res = 1;
								break;
							default:
								switch (B[1])
								{
									case '�':
										res = 1;
										break;
									case '�':
										res = -1;
								}
						}
					}
					break;
				case as_mix:
					if (res = atoi(A.c_str()) - atoi(B.c_str()))
						break;
				case as_txt:
					res = A.AnsiCompareIC(B);
					break;
				default:
					MessageBeep(-1);
			}
			if (res)
				return (sorter->IsReversed(i) ? -res : res);
		}
	}
	catch(...)
	{
		MessageBeep(-1);
	}
	return res;
}

//---------------------------------------------------------------------------

__fastcall Srt::Srt(TListView *lw)
{
	listview = lw;
	TListColumns *lcs = lw->Columns;
	int cols = lcs->Count;
	columns = new ColumnList;
	columns->Capacity = cols;
	flags = new TList;
	flags->Capacity = cols;
	indexes = new TList;
	indexes->Capacity = cols;
	for (int i = 0; i < cols; i++)
	{
		flags->Add((void *) 0);
		indexes->Add((void *) i);
		columns->Add(lcs->Items[i]);
	}
}

//---------------------------------------------------------------------------

void __fastcall Srt::Reverse(const TListColumn *lc)
{
	int i = columns->IndexOf((void *) lc);
	flags->Items[i] = (void *) ((int) flags->Items[i] ^ reverse_bit);
}

//---------------------------------------------------------------------------

void __fastcall Srt::Process(const TListColumn *lc)
{
	if (lc)
	{
		if (lc == columns->GetColumn(0))
			Reverse(lc);
		else
			ToHead(lc);
	}
	for (int i = 0; i < indexes->Count; i++)
	{
		lc = columns->GetColumn(i);
		bool rev = IsReversed(i);
		switch (i)
		{
			case 0:
				if (indexes->Count > 1)
					lc->ImageIndex = rev ? GREEN_DESCENDING : GREEN_ASCENDING;
				else
					lc->ImageIndex = rev ? DESCENDING : ASCENDING;
				break;
			case 1:
				lc->ImageIndex = rev ? YELLOW_DESCENDING : YELLOW_ASCENDING;
				break;
			case 2:
				lc->ImageIndex = rev ? RED_DESCENDING : RED_ASCENDING;
				break;
			default:
				lc->ImageIndex = -1;
		}
	}
	listview->Items->BeginUpdate();
	listview->CustomSort(SorterProc,(int) this);
	listview->Items->EndUpdate();
}

//---------------------------------------------------------------------------

void __fastcall Srt::ToHead(const TListColumn *lc)
{
	int i = columns->IndexOf((void *) lc);
	assert(i != -1);
	columns->Move(i,0);
	flags->Move(i,0);
	indexes->Move(i,0);
}

//---------------------------------------------------------------------------

__fastcall Srt::~Srt()
{
	delete columns;
	delete flags;
	delete indexes;
}

//---------------------------------------------------------------------------

TStream& operator << (TStream& s,Srt *so)
{
	s << so->flags << so->indexes;
	return s;
}

//---------------------------------------------------------------------------

TStream& operator >> (TStream& s,Srt *so)
{
	so->Clear();
	s >> so->flags >> so->indexes;
	int max = so->indexes->Count;
	so->columns->Capacity = max;
	for (int i = 0; i < max; so->columns->Add(so->listview->Columns->Items[(int) so->indexes->Items[i++]]));
	so->Process();
	return s;
}

//---------------------------------------------------------------------------

void __fastcall Srt::Clear()
{
	flags->Clear();
	columns->Clear();
	indexes->Clear();
}
