#ifndef RepBuildH
#define RepBuildH

#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Db.hpp>
#include <DBTables.hpp>
#include <ExtCtrls.hpp>
#include <quickrpt.hpp>
#include <Qrctrls.hpp>
#include <QuickRpt.hpp>

//---------------------------------------------------------------------------

class TRepBuildForm : public TForm
{
__published:
	TQuickRep *Report;
	TDataSource *DataSource1;
	TTable *Table;
	TQRBand *QRBand1;
	TQRBand *QRBand2;
	TQRBand *QRBand3;
	TQRBand *QRBand4;
	TQRLabel *Title;
	TQRBand *QRBand5;
	TQRLabel *Summary;
	TQRSysData *QRSysData3;
	TQRSysData *QRSysData4;
	TQRLabel *QRLabel1;
	TQRLabel *QRLabel2;
	TQRLabel *QRLabel3;
	TQRLabel *QRLabel4;
	TQRLabel *QRLabel5;
	TQRLabel *QRLabel6;
	TQRLabel *QRLabel7;
	TQRLabel *QRLabel8;
	TQRDBText *QRDBText1;
	TQRDBText *QRDBText2;
	TQRDBText *QRDBText3;
	TQRDBText *QRDBText4;
	TQRDBText *QRDBText5;
	TQRDBText *QRDBText6;
	TQRDBText *QRDBText7;
	TQRDBText *QRDBText8;
  TQRShape *QRShape1;
private:
public:
	__fastcall TRepBuildForm(TComponent* Owner);
};

//---------------------------------------------------------------------------

extern PACKAGE TRepBuildForm *RepBuildForm;

//---------------------------------------------------------------------------

#endif

