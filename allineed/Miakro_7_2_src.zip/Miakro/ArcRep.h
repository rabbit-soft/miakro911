//---------------------------------------------------------------------------
#ifndef ArcRepH
#define ArcRepH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Db.hpp>
#include <DBTables.hpp>
#include <ExtCtrls.hpp>
#include <Qrctrls.hpp>
#include <QuickRpt.hpp>
//---------------------------------------------------------------------------
class TArcRepForm : public TForm
{
__published:	// IDE-managed Components
	TQuickRep *Report;
	TQRBand *QRBand2;
	TQRLabel *DeltaLabel;
	TQRLabel *JobLabel;
	TQRLabel *QRLabel3;
	TQRLabel *Address;
	TQRLabel *QRLabel5;
	TQRLabel *QRLabel6;
	TQRLabel *QRLabel7;
	TQRLabel *QRLabel8;
	TQRBand *QRBand4;
	TQRDBText *Delta;
	TQRDBText *QRDBText2;
	TQRDBText *QRDBText3;
	TQRDBText *QRDBText4;
	TQRDBText *QRDBText5;
	TQRDBText *QRDBText6;
	TQRDBText *QRDBText7;
	TQRDBText *Job;
	TQRBand *QRBand5;
	TQRLabel *Summary;
	TQRBand *QRBand3;
	TQRSysData *WhenPrinted;
	TQRSysData *QRSysData4;
	TDataSource *DataSource1;
	TTable *Table;
	TQRLabel *QRLabel1;
	TQRDBText *QRDBText1;
	TQRBand *QRBand1;
	TQRLabel *Title;
  TQRShape *HorLIne;
private:	// User declarations
public:		// User declarations
	__fastcall TArcRepForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TArcRepForm *ArcRepForm;
//---------------------------------------------------------------------------
#endif

