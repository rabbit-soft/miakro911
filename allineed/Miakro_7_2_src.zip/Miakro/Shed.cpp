#include <vcl.h>
#pragma hdrstop

#include "Miakro.h"
#include "Builds.h"
#include "Shed.h"
#include "MoneyForm.h"
#include "Params.h"
#include "Bone.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"

TShedForm *ShedForm;
TChart *TShedForm::shed_charts[MAX_CHARTS];

const int hor_charts = 3,ver_charts = 2;

//---------------------------------------------------------------------------

__fastcall TShedForm::TShedForm(TComponent* Owner) : TForm(Owner)
{
  TShedForm::shed_charts[RAB_CHART] = ShedChart;
  TShedForm::shed_charts[TIER_CHART] = TierChart;
  TShedForm::shed_charts[SEC_CHART] = SecChart;
  TShedForm::shed_charts[FREE_SEC_CHART] = FreeSecChart;
  TShedForm::shed_charts[STAT_CHART] = StatChart;
  TShedForm::shed_charts[CLASS_CHART] = ClassChart;
}

//---------------------------------------------------------------------------

void __fastcall TShedForm::Render(const RabInfo *ri)
{
  enum { IDEAL,OVERALL,MAX_SERIES };
  enum { PERVO_MOTHERS,SUKROLS,FATHERS,CANDIDATES,BUTCHERS,BRIDES,FEED_FEM,FEED_MAL,SUCK_FEM,SUCK_UNKN,NESTED,ORPHANS };
  const int 	per_femtier = 6;
  const int 	per_vertep = 3.2; // 1.2 ������� + 2 ��������
  const float pregn_per_tier = 0.3114;
  const float feed_girls_per_tier = 0.6;
  const float feed_boys_per_tier = 2.0;
  const float unkn_sucks_per_tier = 2.7;
  int free_areas = 0,all_areas = 0,all_tiers = ri->one_tier + ri->two_tiers;
  MiniFarm Fake;
  ShedChart->Foot->Text->Clear();
  String X(String("������� ����� �� ") + BuildWin->Decipher(Fake.GetFullAddress(true)) + AnsiString("�� ") + DateToStr(today));
  for (char i = 0; i < MAX_CHARTS; shed_charts[i++]->Title->Text->Strings[0] = X);
  for (int i = IDEAL; i < MAX_SERIES; ShedChart->Series[i++]->Clear());
	TierChart->Series[0]->Clear();
	SecChart->Series[0]->Clear();
	FreeSecChart->Series[0]->Clear();
  StatChart->Series[0]->Clear();
  ClassChart->Series[0]->Clear();
  int fact = ri->overall;
  int ideal = per_vertep * (ri->types[T_VERTEP] + ri->types[T_BARIN] + 4 * ri->types[T_QUARTA] + 2 * ri->types[T_COMPLEX] + ri->types[T_CABIN] / 2) + per_femtier * (2 * (ri->types[T_DFEMALE] + ri->types[T_JURTA]) + ri->types[T_FEMALE] + ri->types[T_COMPLEX] + ri->types[T_CABIN]);
  if (fact)
  {
    StatChart->Series[0]->AddY(ri->mothers - ri->pervo,"�������",clTeeColor);
    StatChart->Series[0]->AddY(ri->pervo,"�����������",clTeeColor);
    StatChart->Series[0]->AddY(ri->brides,"�������",clTeeColor);
    StatChart->Series[0]->AddY(ri->girls_feed + ri->girls_podsos,"�������",clTeeColor);
    StatChart->Series[0]->AddY(ri->fathers,"�������������",clTeeColor);
    StatChart->Series[0]->AddY(ri->kandidates,"���������",clTeeColor);
    StatChart->Series[0]->AddY(ri->boys_feed + ri->boys_podsos,"��������",clTeeColor);
    StatChart->Series[0]->AddY(ri->sexless_podsos + ri->lost_suckers,"��������",clTeeColor);
    ShedChart->Series[IDEAL]->AddY(ideal,"���",clTeeColor);
    ShedChart->Series[OVERALL]->AddY(fact,"",clTeeColor);
    fact = ri->mothers;
    ideal = ri->types[T_FEMALE] + 2 * (ri->types[T_DFEMALE] + ri->types[T_JURTA]) + ri->types[T_COMPLEX];
    ShedChart->Series[IDEAL]->AddY(ideal,"���������",clTeeColor);
    ShedChart->Series[OVERALL]->AddY(fact,"",clTeeColor);
    fact = ri->pregnant;
    ideal *= pregn_per_tier;
    ShedChart->Series[IDEAL]->AddY(ideal,"����������",clTeeColor);
    ShedChart->Series[OVERALL]->AddY(fact,"",clTeeColor);
    fact = ri->girls_feed;
    ideal = feed_girls_per_tier * all_tiers;
    ShedChart->Series[IDEAL]->AddY(ideal,"�. ������",clTeeColor);
    ShedChart->Series[OVERALL]->AddY(fact,"",clTeeColor);
    fact = ri->boys_feed;
    ideal = feed_boys_per_tier * all_tiers;
    ShedChart->Series[IDEAL]->AddY(ideal,"�. ������",clTeeColor);
    ShedChart->Series[OVERALL]->AddY(fact,"",clTeeColor);
    fact = ri->podsos;
    ideal = unkn_sucks_per_tier * all_tiers;
    ShedChart->Series[IDEAL]->AddY(ideal,"���������",clTeeColor);
    ShedChart->Series[OVERALL]->AddY(fact,"",clTeeColor);
    fact = ri->nested;
    ideal = fact - ri->delta_nested;
    ShedChart->Series[IDEAL]->AddY(ideal,"���������",clTeeColor);
    ShedChart->Series[OVERALL]->AddY(fact,"",clTeeColor);
  }
  else
    ShedChart->Foot->Text->Add("����� ����� �� ����!");
  for (int i = T_FEMALE; i < MAX_TIER_TYPE; i++)
    if (fact = ri->types[i])
    {
      TierChart->Series[0]->AddY(fact,ParamForm->GetTierName(i,AS_FULL),clTeeColor);
      if (ri->secs[i])
        SecChart->Series[0]->AddY(ri->secs[i],ParamForm->GetTierName(i,AS_FULL),clTeeColor);
      if (ri->free_secs[i])
        FreeSecChart->Series[0]->AddY(ri->free_secs[i],ParamForm->GetTierName(i,AS_FULL),clTeeColor);
    }
  ListRab *su,*lr = PopulationWin->rabbits;
  Rabbit *r;
  int classes[MAX_BON];
  memset(classes,0,sizeof(classes));
  for (int i = 0; i < lr->Count; i++)
  {
    r = lr->GetRabbit(i);
    classes[r->CalcBon()] += r->GetGroup();
    if (su = r->GetSuckersList())
      for (int j = 0; j < su->Count; j++)
      {
        r = su->GetRabbit(j);
        classes[r->CalcBon()] += r->GetGroup();
      }
  }
  for (char i = 0; i < (char) MAX_BON; i++)
   ClassChart->Series[0]->AddY(classes[i],bon_names[i],clTeeColor);
}

//---------------------------------------------------------------------------

void __fastcall TShedForm::PrintClick(TObject *)
{
  int width,height,h_margin,v_margin;
  TPrinterOrientation OldOrientation;
  TWaitCursor Wait;
  OldOrientation = Printer()->Orientation;
  Printer()->Orientation = poLandscape;
  try
  {
    Printer()->BeginDoc();
    try
    {
      Printer()->Title = "������� �����";
      width = Printer()->PageWidth / 100 * (int) ParamForm->Config.shed_scale;
      height = Printer()->PageHeight / 100 * (int) ParamForm->Config.shed_scale;
      h_margin = (Printer()->PageWidth - width) / 2;
      v_margin = (Printer()->PageHeight - height) / 2;
      shed_charts[ShedPages->ActivePage->PageIndex]->PrintPartial(TRect(h_margin,v_margin,h_margin + width,v_margin + height));
      Printer()->EndDoc();
    }
    catch (...)
    {
      Printer()->Abort();
      Printer()->EndDoc();
      throw;
    }
  }
  __finally
  {
    Printer()->Orientation = OldOrientation;
  }
}

//---------------------------------------------------------------------------

void __fastcall TShedForm::ShedTimerTimer(TObject *)
{
  char x = ShedPages->ActivePage->PageIndex;
  if (Visible && x && ParamForm->Config.rotation)
  {
    TShedForm::shed_charts[x]->View3DOptions->Tilt = TShedForm::shed_charts[x]->View3DOptions->Tilt - 1;
  }
  else
    ShedTimer->Enabled = false;
}

//---------------------------------------------------------------------------

void __fastcall TShedForm::ShedPagesChange(TObject *)
{
  ShedTimer->Enabled = Visible && ShedPages->ActivePage->PageIndex && ParamForm->Config.rotation;
}

//---------------------------------------------------------------------------

void __fastcall TShedForm::FormShow(TObject *)
{
  ShedPagesChange(NULL);
}

//---------------------------------------------------------------------------

void __fastcall TShedForm::FormCloseQuery(TObject *, bool &CanClose)
{
  ShedTimer->Enabled = false;
}

//---------------------------------------------------------------------------

void __fastcall TShedForm::RotationClick(TObject *Sender)
{
  bool x = !Rotation->Checked;
  Rotation->Checked = x;
  ShedTimer->Enabled = ParamForm->Config.rotation = x;
}
//---------------------------------------------------------------------------

void __fastcall TShedForm::QuickerClick(TObject *Sender)
{
  ParamForm->Config.rot_speed -= ParamForm->Config.rot_speed/10;
  ShedTimer->Interval = ParamForm->Config.rot_speed;
}

//---------------------------------------------------------------------------

void __fastcall TShedForm::SlowerClick(TObject *Sender)
{
  ParamForm->Config.rot_speed += ParamForm->Config.rot_speed >= 10 ? ParamForm->Config.rot_speed/10 : 1;
  ShedTimer->Interval = ParamForm->Config.rot_speed;
}

//---------------------------------------------------------------------------

