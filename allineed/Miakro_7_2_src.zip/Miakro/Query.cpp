#include <vcl\vcl.h>
#pragma hdrstop

#include "Params.h"
#include "Query.h"
#include <math.h>
#undef abs

//---------------------------------------------------------------------------

#pragma link "CSPIN"
#pragma resource "*.dfm"

TQueryForm *QueryForm;

static const char * const captions[MAX_QUERY_MODE] =
{
	"�����",
	"���������� ����� ��������",
	"������� ���������",
	"��������",
	"����������",
	"��������� ������"
};

//---------------------------------------------------------------------------

static int __stdcall Sorter(long a,long b,long) // ������� - ������ �����������. ����� - ��� ����������
{
	int res;
	enum { NUMBER,AGE_DIFF,RELAT,HETER };
	if (!(res = ((TListItem *) a)->SubItems->Strings[RELAT].ToInt() - ((TListItem *) b)->SubItems->Strings[RELAT].ToInt())) // ������ ������
	{
		int x = abs(((TListItem *) a)->SubItems->Strings[AGE_DIFF].ToInt());
		int y = abs(((TListItem *) b)->SubItems->Strings[AGE_DIFF].ToInt());
		return x - y
		|| ((TListItem *) a)->SubItems->Strings[HETER].AnsiCompareIC(((TListItem *) b)->SubItems->Strings[HETER]) // ���������� �����
		|| ((TListItem *) b)->SubItems->Strings[NUMBER].ToInt() - ((TListItem *) a)->SubItems->Strings[NUMBER].ToInt()
		|| ((TListItem *) a)->Caption.AnsiCompareIC(((TListItem *) b)->Caption); // ���������� �����
	}
	return res;
}

//---------------------------------------------------------------------------

__fastcall TQueryForm::TQueryForm(TComponent* Owner) 	: TForm(Owner)
{
	notify = 0;
  rabbits_in_group = 0;
}

//---------------------------------------------------------------------------

void __fastcall TQueryForm::FormShow(TObject *)
{
	notify++;
	When->Date = today;
	cookie_absday = (int) When->Date;
	Caption = captions[mode];
	bool x = mode == QM_OKROL;
	WhenLabel->Visible = x;
	WhenRelLabel->Visible = x;
	WhenDateLabel->Visible = x;
	WhenRel->Visible = x;
	When->Visible = x;
	Notes->Visible = true;
	NotesLabel->Visible = true;
	WhenRel->Value = (int) today - (int) When->Date;
	DeltaLabel->Visible = false;
	Delta->Visible = false;
	Notes->Visible = false;
	NotesLabel->Visible = false;
  Overall->Value = rabbits_in_group;
  Delta->Value = 0;
  switch (mode)
	{
    case QM_OTSBOYS:
      Overall->Value = rabbits_in_group > 1 ? rabbits_in_group / 2 : 1;
      Delta->Value = rabbits_in_group - Overall->Value;
      break;
    case QM_SPIS:
      break;
    case QM_BUTCHER:
      break;
    case QM_SPLIT_GROUP:
      break;
    case QM_OKROL:
    	Overall->Value = 9;
			break;
		case QM_DEATH:
      Delta->Value = 0;
			DeltaLabel->Visible = true;
      Delta->Visible = true;
	}
	notify--;
}

//---------------------------------------------------------------------------

void __fastcall TQueryForm::WhenChange(TObject *Sender)
{
	if (notify) return;
	if ((int) When->Date > (int) today)
	{
		notify++;
		MessageBox(NULL,"���� �� ����� ���� � �������!","������",MB_APPLMODAL|MB_ICONWARNING|MB_OK);
		WhenRel->Value = 0;
		When->Date = (int) today;
		notify--;
	}
	cookie_absday = (int) When->Date;
	if (Sender)
	{
		notify++;
		WhenRel->Value = int(today - cookie_absday);
		notify--;
	}
	return;
}

//---------------------------------------------------------------------------

void __fastcall TQueryForm::WhenRelChange(TObject *)
{
	if (notify) return;
	try
	{
		int x = WhenRel->Value;
		if (x < 0) throw(NULL);
		notify++;
		When->Date = int(today - x);
		notify--;
		WhenChange(NULL);
	}
	catch (...) { MessageBox(NULL,"�������� �������� �����!","������",MB_APPLMODAL|MB_ICONWARNING|MB_OK); }

}

//---------------------------------------------------------------------------


void __fastcall TQueryForm::WhenDblClick(TObject *Sender)
{
	When->Visible = false;
	WhenRel->Visible = true;
}

//---------------------------------------------------------------------------

void __fastcall TQueryForm::DeltaChange(TObject *)
{
  if (notify) return;
  notify++;
  Overall->Value = rabbits_in_group + Delta->Value;
  notify--;
}

//---------------------------------------------------------------------------

void __fastcall TQueryForm::OverallChange(TObject *)
{
  if (notify) return;
  notify++;
  Delta->Value = Overall->Value - rabbits_in_group;
  notify--;
}

//---------------------------------------------------------------------------

