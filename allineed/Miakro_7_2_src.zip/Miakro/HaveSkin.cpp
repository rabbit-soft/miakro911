#include <vcl.h>
#pragma hdrstop

#include "HaveSkin.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"
THaveSkinForm *HaveSkinForm;

//---------------------------------------------------------------------------

__fastcall THaveSkinForm::THaveSkinForm(TComponent* Owner) : TForm(Owner)
{
}

//---------------------------------------------------------------------------
