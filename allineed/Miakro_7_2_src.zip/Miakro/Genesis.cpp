#include <vcl\vcl.h>
#pragma hdrstop

#include "Genesis.h"
#include "Rabbit.h"
#include "PassportForm.h"

//---------------------------------------------------------------------------

#pragma resource "*.dfm"

TGenForm *GenForm;

//---------------------------------------------------------------------------

__fastcall TGenForm::TGenForm(TComponent* Owner) : TForm(Owner)
{
}

//---------------------------------------------------------------------------

void __fastcall TGenForm::Button1Click(TObject *)
{
	Excl->Clear();
}

//---------------------------------------------------------------------------

void __fastcall TGenForm::OkClick(TObject *)
{
	Rabbit *r = Passport->SharePasRabbit();
	if (r->GetSex() == FEMALE)
	{
		switch (Passport->WhosGens->ItemIndex)
		{
			case THEM:
				r = (Rabbit *) Passport->Family->Selected->Data;
		}
	}
	if (!Process(r,Incl->Lines,true) || !Process(r,Excl->Lines,false))
		ModalResult = mrAbort;
}

//---------------------------------------------------------------------------

void __fastcall TGenForm::FormCloseQuery(TObject *, bool &CanClose)
{
	if (ModalResult == mrAbort)
		CanClose = false;
}

//---------------------------------------------------------------------------

bool __fastcall TGenForm::Process(Rabbit *r,TStrings *ss,bool incl)
{
	short len,pos,max = ss->Count;
	int a,b,i;
	AnsiString delims("., ");
	try
	{
		for (i = 0; i < max; i++)
		{
			AnsiString s = ss->Strings[i].Trim();
			if (!(len = s.Length())) continue;
			pos = 1;
			while (pos <= len)
			{
				if (s.IsDelimiter(delims,pos))
				{
					pos++;
					continue;
				}
				if ((a = ExtractNumber(s,pos,len)) <= 0 || a > 65535) throw(long(a));
				if (pos > len)
				{
					Mix(r,a,incl);
					break;
				}
				if (s[pos] == '-')
				{
					if (pos >= len) throw(i + 1);
					if ((b = ExtractNumber(s,++pos,len)) <= 0 || b > 65535) throw(long(b));
					if (b < a)
					{
						int c = a;
						a = b;
						b = c;
					}
					while (a <= b)
						Mix(r,a++,incl);
				}
			}
		}
		return true;
	}
	catch (int x) { MessageBox(NULL,(AnsiString("������ � ������ ") + x).c_str(),incl ? "���������" : "����������",MB_APPLMODAL|MB_ICONWARNING|MB_OK); }
	catch (long dig) { MessageBox(NULL,(AnsiString("�������� ����� ") + (int) dig).c_str(),incl ? "���������" : "����������",MB_APPLMODAL|MB_ICONWARNING|MB_OK); }
	catch (...) { MessageBox(NULL,"���������� ������",incl ? "���������" : "����������",MB_APPLMODAL|MB_ICONWARNING|MB_OK);	}
	return false;
}

//---------------------------------------------------------------------------

void __fastcall TGenForm::Mix(Rabbit *r,unsigned short a,bool incl)
{
	if (incl)
		r->AddGenNumber(a);
	else
		r->GetGenesis()->Remove((void *) a);
}
//---------------------------------------------------------------------------

int __fastcall TGenForm::ExtractNumber(AnsiString s,short& pos,short len)
{
	int x,res = 0;
	for (x = pos; pos <= len && isdigit(s[pos]); pos++);
	if (pos > x)
		res = s.SubString(x,pos - x).ToInt();
	return res;
}

//---------------------------------------------------------------------------

