#include <vcl\vcl.h>
#pragma hdrstop

#include "Miakro.h"
#include "BuildPassport.h"
#include "Builds.h"
#include "Rabbit.h"

#pragma link "CSPIN"
#pragma resource "*.dfm"

//---------------------------------------------------------------------------

TBuildPas *BuildPas;

//---------------------------------------------------------------------------

__fastcall TBuildPas::TBuildPas(TComponent* Owner) : TForm(Owner)
{
	pas_minifarm = NULL;
	notify = 0;
	rabs[0] = new TList; // ������ ������� ListRab
	rabs[1] = new TList;
}

//---------------------------------------------------------------------------

MiniFarm * __fastcall TBuildPas::OwnPasMiniFarm()
{
	MiniFarm *mf = pas_minifarm;
	pas_minifarm = NULL;
	return mf;
}

//---------------------------------------------------------------------------

void __fastcall TBuildPas::FormShow(TObject *)
{
	notify++;
	DeleteRabs(0);
	DeleteRabs(1);
	if (pas_minifarm)
	{
		delete pas_minifarm;
		pas_minifarm = NULL;
	}
	switch (mode)
	{
		case NEW_ENTRY:
			BuildPas->Caption = "������� ����� ���������";
			old_number = BuildWin->FindVacantNumber();
			FarmNumber->Caption = (int) old_number;
			GetNumber->Value = max((int) old_number,(int) StartNumber->Value);
			pas_minifarm = new MiniFarm();
			pas_minifarm->SetId(old_number);
			pas_minifarm->CreateTier();
			AddressLabel->Caption = pas_minifarm->GetFullAddress(true);
			break;
		case EDIT_ENTRY:
			old_number = BuildWin->cur_minifarm->GetId();
			BuildPas->Caption = "������� ���������";
			pas_minifarm = new MiniFarm(*BuildWin->cur_minifarm);
			AddressLabel->Caption = pas_minifarm->GetFullAddress();
	}
	Tier *ti;
	GetNumber->Value = old_number;
	FarmNumber->Caption = (int) old_number;
	bool is = !PopulationWin->rabbits->HowManyRabbits(pas_minifarm->GetId());
	TierNum->Visible = is;
	GetNumber->Visible = is;
	NumberOk->Visible = is;
	StartCountLabel->Visible = is;
	StartNumber->Visible = is;
	TierNum->ItemIndex = (ti = pas_minifarm->GetTier(true)) != NULL;
	LowerTierGroup->Visible = ti != NULL;
	if (ti)
	{
		LowerRepair->Checked = ti->GetRepair();
		LowerRepair->Enabled = !ti->IntegralBusy();
		LowerTier->ItemIndex = ti->GetType() - 1;
		LowerAB->Checked = ti->GetDelim(0);
		LowerBC->Checked = ti->GetDelim(1);
		LowerCD->Checked = ti->GetDelim(2);
		LowerDelim->Checked = ti->GetDelim(0);
		LowerNotes->Text = ti->GetNotes();
		LowerNest->Checked = ti->IsNestAnywhere();
		LowerNestB->Checked = ti->GetNest(1);
		LowerHeater->Checked = ti->IsHeaterAnywhere();
		LowerHeaterOn->Checked = ti->IsHeaterOnAnywhere();
		LowerHeaterB->Checked = ti->GetHeater(1);
		LowerHeaterOnB->Checked = ti->GetHeaterOn(1);
		LowerJurtaLink->ItemIndex = ti->GetJurtaLink();
		LowerVisibility(ti);
	}
	ti = pas_minifarm->GetTier();
	UpperTier->ItemIndex = ti->GetType() - 1;
	UpperRepair->Checked = ti->GetRepair();
	UpperRepair->Enabled = !ti->IntegralBusy();
	UpperAB->Checked = ti->GetDelim(0);
	UpperBC->Checked = ti->GetDelim(1);
	UpperCD->Checked = ti->GetDelim(2);
	UpperDelim->Checked = ti->GetDelim(0);
	UpperNotes->Text = ti->GetNotes();
	UpperNest->Checked = ti->IsNestAnywhere();
	UpperNestB->Checked = ti->GetNest(1);
	UpperHeater->Checked = ti->IsHeaterAnywhere();
	UpperHeaterOn->Checked = ti->IsHeaterOnAnywhere();
	UpperHeaterB->Checked = ti->GetHeater(1);
	UpperHeaterOnB->Checked = ti->GetHeaterOn(1);
	UpperJurtaLink->ItemIndex = ti->GetJurtaLink();
	UpperVisibility(ti);
	pas_minifarm->Render(ViewFarm);
	notify--;
}

//---------------------------------------------------------------------------

void __fastcall TBuildPas::TierChange(TObject *Sender)
{
	if (notify) return;
	bool lw = ((TComponent *) Sender)->Tag != 0;
	Tier *ti = pas_minifarm->GetTier(lw);
	TIER type = TIER (max(0,((TComboBox *) Sender)->ItemIndex) + 1);
	if (ti)
  {
    if (ti->GetType() == type) return;
    if (ti->IntegralBusy())
    {
      if (Application->MessageBox("�� ������������� ������ �������� ��� ���������� �����?","������",MB_APPLMODAL|MB_ICONQUESTION|MB_YESNO|MB_DEFBUTTON2) == IDNO)
      {
        notify++;
        ((TComboBox *) Sender)->ItemIndex = ti->GetType() - 1;
        notify--;
        return;
      }
      DeleteRabs(lw);
      for (char i = 0; i < ti->HowManyAreas(); i++)
        rabs[lw]->Add(ti->FindWhoLivesHere(i));
    }
  }
	if ((char ) type >= MAX_TIER_TYPE)
	{
		MessageBox(NULL,"#1 ���������� ��� �����!","����!!!",MB_APPLMODAL|MB_ICONWARNING|MB_OK);
		notify++;
		((TComboBox *) Sender)->ItemIndex = 0;
		notify--;
		return;
	}
	ti = pas_minifarm->CreateTier(type,lw);
	notify++;
  bool x;
	if (lw)
	{
		LowerVisibility(ti);
		LowerTier->Enabled = true;
		LowerTier->ItemIndex = ti->GetType() - 1;
		LowerAB->Checked = ti->GetDelim(0);
		LowerDelim->Checked = ti->GetDelim(0);
		LowerBC->Checked = ti->GetDelim(1);
		LowerCD->Checked = ti->GetDelim(2);
		LowerNotes->Text = ti->GetNotes();
		LowerNest->Checked = ti->GetNest();
		LowerNestB->Checked = ti->GetNest(1);
		LowerHeater->Checked = x = ti->GetHeater();
    LowerHeaterOn->Visible = x;
		LowerHeaterB->Checked = x = ti->GetHeater(1);
    LowerHeaterOnB->Visible = x;
		LowerJurtaLink->ItemIndex = ti->GetJurtaLink();
	}
	else
	{
		UpperVisibility(ti);
		UpperTier->ItemIndex = ti->GetType() - 1;
		UpperAB->Checked = ti->GetDelim(0);
		UpperDelim->Checked = ti->GetDelim(0);
		UpperBC->Checked = ti->GetDelim(1);
		UpperCD->Checked = ti->GetDelim(2);
		UpperNotes->Text = ti->GetNotes();
		UpperNest->Checked = ti->GetNest();
		UpperNestB->Checked = ti->GetNest(1);
		UpperHeater->Checked = x = ti->GetHeater();
    UpperHeaterOn->Visible = x;
		UpperHeaterB->Checked = x = ti->GetHeater(1);
    UpperHeaterOnB->Visible = x;
		UpperJurtaLink->ItemIndex = ti->GetJurtaLink();
	}
	notify--;
	pas_minifarm->Render(ViewFarm);
}

//---------------------------------------------------------------------------

void __fastcall TBuildPas::MakeBusyLabel(TLabel *label,Tier *ti)
{
	char buf[80];
	bool x;
	int i,max = ti->HowManyAreas(),f = ti->HowManyFreeAreas();
	ostrstream s(buf,sizeof(buf));
	if (x = ti->IntegralBusy())
	{
		s << "������";
		if (max > 1)
		{
			s << ": ";
			for (i = 0; i < max; i++)
				if (ti->IsBusy(i))
					s << char(i + '�');
		}
	}
	if (f)
	{
		s << (x ? "; �" : "�") << "�������";
		if (max > 1)
		{
			s << ": ";
			for (i = 0; i < max; i++)
				if (!ti->IsBusy(i))
					s << char(i + '�');
		}
	}
	s << ends;
	label->Caption = buf;
}

//---------------------------------------------------------------------------

void __fastcall TBuildPas::UpperVisibility(Tier *ti)
{
	bool x;
	TIER t = ti->GetType();
	MakeBusyLabel(UpBusyLabel,ti);
	UpperHeater->Visible = x = ti->MayHaveHeater() || ti->GetType() == T_JURTA;
  UpperHeaterOn->Visible = x && UpperHeater->Checked;
	UpperNest->Visible = x;
	UpperDelimGroup->Visible = t == T_QUARTA;
	UpperDelim->Visible = t == T_BARIN;
	UpperHeaterB->Visible = x = t == T_DFEMALE;
	UpperNestB->Visible = x;
  UpperHeaterOnB->Visible = x && UpperHeaterB->Checked;
	UpperNest->Caption = "���������";
	UpperHeater->Caption = "������";
	UpperHeaterOn->Caption = "���.";
	if (x)
	{
		UpperNest->Caption = UpperNest->Caption + "-�";
		UpperHeater->Caption = UpperHeater->Caption + "-�";
		UpperHeaterOn->Caption = UpperHeaterOn->Caption + "-�";
	}
	UpperJurtaLink->Visible = t == T_JURTA;
}

//---------------------------------------------------------------------------

void __fastcall TBuildPas::LowerVisibility(Tier *ti)
{
	TIER t = ti->GetType();
	bool x;
	MakeBusyLabel(LowBusyLabel,ti);
	LowerHeater->Visible = x = ti->MayHaveHeater();
  LowerHeaterOn->Visible = x && LowerHeater->Checked;
	LowerNest->Visible = x;
	LowerDelimGroup->Visible = t == T_QUARTA;
	LowerDelim->Visible = t == T_BARIN;
	LowerHeaterB->Visible = x = t == T_DFEMALE;
  LowerHeaterOnB->Visible = x && LowerHeaterB->Checked;
	LowerNestB->Visible = x;
	LowerNest->Caption = "���������";
	LowerHeater->Caption = "������";
	LowerHeaterOn->Caption = "���.";
	if (x)
	{
		LowerNest->Caption = LowerNest->Caption + "-�";
		LowerHeater->Caption = LowerHeater->Caption + "-�";
		LowerHeaterOn->Caption = LowerHeaterOn->Caption + "-�";
	}
	LowerJurtaLink->Visible = t == T_JURTA;
}

//---------------------------------------------------------------------------

void __fastcall TBuildPas::TierNumClick(TObject *) // �����������/������������
{
	if (notify) return;
	bool i = TierNum->ItemIndex > 0;
	UpperTierGroup->Caption = i ? "������� ����" : "��������";
	LowerTierGroup->Visible = i;
	if (i)
		TierChange(LowerTier); 						// ������� ������ ����
	else
		pas_minifarm->DeleteLowerTier();  // ������� ������ ����
	pas_minifarm->Render(ViewFarm);
}

//---------------------------------------------------------------------------

void __fastcall TBuildPas::UpperRepairClick(TObject *)
{
	if (notify) return;
	pas_minifarm->GetTier()->SetRepair(UpperRepair->Checked);
}

//---------------------------------------------------------------------------

void __fastcall TBuildPas::LowerNotesChange(TObject *)
{
	if (notify) return;
	if (pas_minifarm->GetTier(true)->GetNotes())
		pas_minifarm->GetTier(true)->DeleteNotes(); // ������ �������. ������� ����� ������ ��� mrOk
}

//---------------------------------------------------------------------------

void __fastcall TBuildPas::UpperNotesChange(TObject *)
{
	if (notify) return;
	if (pas_minifarm->GetTier()->GetNotes())
		pas_minifarm->GetTier()->DeleteNotes(); // ������ �������. ������� ����� ������ ��� mrOk
}

//---------------------------------------------------------------------------

void __fastcall TBuildPas::DelimClick(TObject *Sender)
{
	enum { ORD_MASK = 3,LOWER_MASK };

	if (notify) return;
	char tag = ((TComponent *) Sender)->Tag;
	bool lw,x;
	Tier *ti = pas_minifarm->GetTier(lw = tag & LOWER_MASK);
	if (!ti->SetDelim(tag & ORD_MASK,x = ((TCheckBox *) Sender)->Checked))
	{
		notify++;
		((TCheckBox *) Sender)->Checked = !x;
		notify--;
	}
	MakeBusyLabel(lw ? LowBusyLabel : UpBusyLabel,ti);
	pas_minifarm->Render(ViewFarm);
}

//---------------------------------------------------------------------------

void __fastcall TBuildPas::HeatNestClick(TObject *Sender)
{
	static const char uplow_mask = 1;
	static const char ab_mask = 2;
	static const char heat_nest_mask = 4;
	if (notify) return;
	char tag = ((TComponent *) Sender)->Tag;
	bool x = ((TCheckBox *) Sender)->Checked;
	bool area = tag & ab_mask;
  bool low = (tag & uplow_mask) != 0;
	Tier *ti = pas_minifarm->GetTier(low);
	if (tag & heat_nest_mask)
  {
		ti->SetHeater(x,area);
    if (low)
    {
      if (area)
        LowerHeaterOnB->Visible = x;
      else
        LowerHeaterOn->Visible = x;
    }
    else
    {
      if (area)
        UpperHeaterOnB->Visible = x;
      else
        UpperHeaterOn->Visible = x;
    }
  }
	else
		ti->SetNest(x,area);
}

//---------------------------------------------------------------------------

void __fastcall TBuildPas::LowerJurtaLinkClick(TObject *)
{
	if (notify) return;
	pas_minifarm->GetTier(true)->SetJurtaLink(LowerJurtaLink->ItemIndex);
	pas_minifarm->Render(ViewFarm);
}

//---------------------------------------------------------------------------

void __fastcall TBuildPas::UpperJurtaLinkClick(TObject *)
{
	if (notify) return;
	pas_minifarm->GetTier()->SetJurtaLink(UpperJurtaLink->ItemIndex);
	pas_minifarm->Render(ViewFarm);
}

//---------------------------------------------------------------------------

void __fastcall TBuildPas::UpperDelimClick(TObject *Sender)
{
	if (notify) return;
	bool x;
	Tier *ti = pas_minifarm->GetTier();
	if (!ti->SetDelim(0,x = UpperDelim->Checked))
	{
		notify++;
		((TCheckBox *) Sender)->Checked = !x;
		notify--;
	}
	MakeBusyLabel(UpBusyLabel,ti);
	pas_minifarm->Render(ViewFarm);
}

//---------------------------------------------------------------------------

void __fastcall TBuildPas::LowerDelimClick(TObject *Sender)
{
	if (notify) return;
	bool x;
	Tier *ti = pas_minifarm->GetTier(true);
	if (!ti->SetDelim(0,x = LowerDelim->Checked))
	{
		notify++;
		((TCheckBox *) Sender)->Checked = !x;
		notify--;
	}
	MakeBusyLabel(LowBusyLabel,ti);
  pas_minifarm->Render(ViewFarm);
}

//---------------------------------------------------------------------------

void __fastcall TBuildPas::LowerRepairClick(TObject *)
{
	if (notify) return;
	Tier *ti = pas_minifarm->GetTier(true);
	if (ti)
		ti->SetRepair(LowerRepair->Checked);
}

//---------------------------------------------------------------------------

void __fastcall TBuildPas::UpperHeaterOnClick(TObject *Sender)
{
	char x = ((TComponent *) Sender)->Tag;
  pas_minifarm->GetTier((x & 2) != 0)->SetHeaterOn(((TCheckBox *) Sender)->Checked,x & 1);
}

//---------------------------------------------------------------------------

void __fastcall TBuildPas::DeleteRabs(char i)
{
	for (int j = 0; j < rabs[i]->Count; delete (ListRab *) rabs[i]->Items[j++]);
	rabs[i]->Clear();
}

//---------------------------------------------------------------------------

void __fastcall TBuildPas::GetNumberChange(TObject *)
{
	if (notify) return;
	bool bad = GetNumber->Value != old_number && BuildWin->FindFarm(GetNumber->Value);
	NumberOk->Caption = bad ? "�� �������" : "�������";
	if (!bad)
	{
		pas_minifarm->SetId(GetNumber->Value);
		FarmNumber->Caption = (int) GetNumber->Value;
	}
}

//---------------------------------------------------------------------------

void __fastcall TBuildPas::StartNumberChange(TObject *)
{
	if (StartNumber->Value > GetNumber->Value)
		GetNumber->Value = StartNumber->Value;
}

//---------------------------------------------------------------------------

__fastcall TBuildPas::~TBuildPas()
{
	notify++;
	DeleteRabs(0);
	DeleteRabs(1);
	delete rabs[0];
	delete rabs[1];
}

