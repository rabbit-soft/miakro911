#ifndef PlemPassportH
#define PlemPassportH

//----------------------------------------------------------------------------

#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\QuickRpt.hpp>
#include <vcl\QRCtrls.hpp>
#include <Qrctrls.hpp>
#include <Db.hpp>
#include <DBTables.hpp>
#include <ExtCtrls.hpp>

class Rabbit;

//----------------------------------------------------------------------------

class GrandParent
{
  private:
    TQRLabel *no;
    TQRLabel *x_class;
    TQRLabel *name;
    TQRLabel *age;
    TQRLabel *weight;
    TQRLabel *l_class;
    TQRLabel *l_name;
    TQRLabel *l_age;
    TQRLabel *l_weight;
  public:
    __fastcall GrandParent(TQRLabel *n,TQRLabel *cl,TQRLabel *nam,TQRLabel *ag,TQRLabel *w,TQRLabel *l_cl,TQRLabel *l_nam,TQRLabel *l_ag,TQRLabel *l_w) { no = n; x_class = cl; name = nam; age = ag; weight = w; l_class = l_cl; l_name = l_nam; l_age = l_ag; l_weight = l_w;}
    virtual void __fastcall Render(Rabbit *r);
};

//----------------------------------------------------------------------------

class Parenter : public GrandParent
{
  private:
    TQRLabel *classify;
    TQRLabel *b_body;
    TQRLabel *b_hair;
    TQRLabel *b_color;
    TQRLabel *b_weight;
    TQRLabel *l_body;
    TQRLabel *l_hair;
    TQRLabel *l_color;
    TQRLabel *l_weight;
  public:
    __fastcall Parenter(TQRLabel *n,TQRLabel *cl,TQRLabel *nam,TQRLabel *ag,TQRLabel *w,TQRLabel *l_cl,TQRLabel *l_nam,TQRLabel *l_ag,TQRLabel *l_w,TQRLabel *bod,TQRLabel *hai,TQRLabel *col,TQRLabel *wei,TQRLabel *l_bod,TQRLabel *l_hai,TQRLabel *l_col,TQRLabel *l_wei,TQRLabel *cls) : GrandParent(n,cl,nam,ag,w,l_cl,l_nam,l_ag,l_w) { b_body = bod; b_hair = hai; b_color = col; b_weight = wei; l_body = l_bod; l_hair = l_hai; l_color = l_col; l_weight = l_wei; classify = cls; }
    void __fastcall Render(Rabbit *r);
};

//----------------------------------------------------------------------------

class SvidRab
{
  private:
    Parenter    *parent;
    GrandParent *grandfather;
    GrandParent *grandmother;
  public:
    __fastcall SvidRab(Parenter *p,GrandParent *f,GrandParent *m) { parent = p; grandfather = f; grandmother = m; }
		__fastcall ~SvidRab() { delete parent; delete grandfather; delete grandmother; }
		void __fastcall Render(Rabbit *r,Rabbit *f,Rabbit *m) { parent->Render(r); grandfather->Render(f); grandmother->Render(m); }
};

//----------------------------------------------------------------------------

class TPlemReport : public TQuickRep
{
__published:
  TQRStringsBand *Lines;
  TQRBand *Title;
  TQRBand *Header;
  TQRLabel *SvidLabel;
  TQRLabel *HeadLabel;
  TQRBand *QRBand3;
  TQRSysData *QRSysData2;
  TQRSysData *QRSysData1;
  TQRSysData *QRSysData3;
  TQRLabel *J1;
  TQRLabel *N1;
  TQRLabel *N2;
  TQRLabel *J2;
  TQRLabel *N4;
  TQRLabel *J4;
  TQRLabel *J3;
  TQRLabel *N3;
  TQRLabel *J5;
  TQRLabel *N5;
  TQRLabel *RabLabel;
  TQRLabel *Breed;
  TQRLabel *Dtpl;
  TQRLabel *Ag;
  TQRLabel *MainWeight;
  TQRLabel *Birthpl;
  TQRLabel *BirthPlace;
  TQRLabel *BirthDay;
  TQRLabel *Age;
  TQRLabel *Weight;
  TQRLabel *GenLab;
  TQRLabel *Genesis;
  TQRLabel *MainName;
  TQRLabel *MainAdr;
  TQRLabel *Name;
  TQRLabel *Address;
  TQRLabel *OkrolNum;
  TQRLabel *OverallRab;
  TQRLabel *OverallRabbits;
  TQRLabel *OnWeight;
  TQRLabel *OnBody;
  TQRLabel *OnHair;
  TQRLabel *OnColor;
  TQRLabel *B_Weight;
  TQRLabel *Body;
  TQRLabel *Thickness;
  TQRLabel *Color;
  TQRLabel *MainClassify;
  TQRLabel *Mother;
  TQRLabel *Father;
  TQRShape *QRShape1;
  TQRShape *QRShape2;
  TQRShape *QRShape3;
  TQRShape *QRShape4;
  TQRShape *QRShape5;
  TQRLabel *MGM;
  TQRLabel *FGG;
  TQRLabel *FGM;
  TQRLabel *FFF;
  TQRLabel *N_MM;
  TQRLabel *MM_Name;
  TQRLabel *C_MM;
  TQRLabel *MM_Class;
  TQRLabel *A_M;
  TQRLabel *M_Age;
  TQRLabel *W_M;
  TQRLabel *MX_Weight;
  TQRLabel *M_LB;
  TQRLabel *M_LH;
  TQRLabel *M_LC;
  TQRLabel *M_Weight;
  TQRLabel *M_Body;
  TQRLabel *M_Hair;
  TQRLabel *M_Color;
  TQRLabel *M_Classify;
  TQRLabel *N_F;
  TQRLabel *F_Name;
  TQRLabel *C_F;
  TQRLabel *F_Class;
  TQRLabel *A_F;
  TQRLabel *F_Age;
  TQRLabel *W_F;
  TQRLabel *FX_Weight;
  TQRLabel *F_LW;
  TQRLabel *F_LB;
  TQRLabel *F_LH;
  TQRLabel *F_LC;
  TQRLabel *F_Weight;
  TQRLabel *F_Body;
  TQRLabel *F_Hair;
  TQRLabel *F_Color;
  TQRLabel *F_Classify;
  TQRLabel *C_M;
  TQRLabel *M_Class;
  TQRLabel *N_M;
  TQRLabel *M_Name;
  TQRLabel *A_MM;
  TQRLabel *MX_Age;
  TQRLabel *W_MM;
  TQRLabel *MM_Weight;
  TQRLabel *N_MF;
  TQRLabel *MF_Name;
  TQRLabel *C_MF;
  TQRLabel *MF_Class;
  TQRLabel *A_MF;
  TQRLabel *W_MF;
  TQRLabel *MF_Age;
  TQRLabel *MF_Weight;
  TQRShape *QRShape7;
  TQRLabel *C_FM;
  TQRLabel *FM_Class;
  TQRLabel *C_FF;
  TQRLabel *N_FF;
  TQRLabel *FF_Class;
  TQRLabel *FF_Name;
  TQRLabel *A_FF;
  TQRLabel *W_FF;
  TQRLabel *FF_Age;
  TQRLabel *FF_Weight;
  TQRLabel *M_No;
  TQRLabel *F_No;
  TQRLabel *MM_No;
  TQRLabel *MF_No;
  TQRLabel *FF_No;
  TQRLabel *FM_No;
  TQRLabel *W_FM;
  TQRLabel *FM_Weight;
  TQRLabel *A_FM;
  TQRLabel *FM_Age;
  TQRLabel *FM_Name;
  TQRLabel *M_LW;
  TQRLabel *N_FM;
  TQRShape *QRShape6;
  TQRShape *QRShape8;
  TQRMemo *Memo;
  void __fastcall PlemReportBeforePrint(TCustomQuickRep *Sender,bool &PrintReport);
private:
  SvidRab *father;
  SvidRab *mother;
public:
   static Rabbit *cookie;
   __fastcall TPlemReport(TComponent* Owner);
	 __fastcall ~TPlemReport();
};

//----------------------------------------------------------------------------

extern TPlemReport *PlemReport;

//----------------------------------------------------------------------------
#endif