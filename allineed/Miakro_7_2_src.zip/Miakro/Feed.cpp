#include <vcl.h>
#pragma hdrstop

#include "Feed.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"
TFeedForm *FeedForm;

//---------------------------------------------------------------------------

__fastcall TFeedForm::TFeedForm(TComponent* Owner) : TForm(Owner)
{
}

//---------------------------------------------------------------------------
