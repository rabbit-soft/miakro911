#include <vcl.h>
#pragma hdrstop

#include "RepRabbit.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"
TRepRabForm *RepRabForm;

//---------------------------------------------------------------------------

__fastcall TRepRabForm::TRepRabForm(TComponent* Owner) : TForm(Owner)
{
}

//---------------------------------------------------------------------------

