//---------------------------------------------------------------------------
#ifndef GenesisH
#define GenesisH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>

class Rabbit;

//---------------------------------------------------------------------------

class TGenForm : public TForm
{
__published:
	TGroupBox *GroupBox1;
	TGroupBox *GroupBox2;
	TButton *Ok;
	TButton *Button2;
	TMemo *Incl;
	TMemo *Excl;
	TButton *Button1;
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall OkClick(TObject *Sender);
	void __fastcall FormCloseQuery(TObject *Sender, bool &CanClose);
private:
	bool __fastcall Process(Rabbit *r,TStrings *ss,bool incl);
	void __fastcall Mix(Rabbit *r,unsigned short a,bool incl);
	int  __fastcall ExtractNumber(AnsiString s,short& pos,short len);
public:
	__fastcall TGenForm(TComponent* Owner);
};

//---------------------------------------------------------------------------

extern TGenForm *GenForm;

//---------------------------------------------------------------------------
#endif
