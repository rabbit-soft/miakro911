#include <vcl\vcl.h>
#pragma hdrstop

#include "Breed.h"
#include "Sorting.h"

//---------------------------------------------------------------------------

#pragma resource "*.dfm"

#define LIST_STEP 3

TBreedForm *BreedForm;

enum { B_BREED,B_SBREED,B_GROUP,B_MAXCOLS };

//---------------------------------------------------------------------------

__fastcall TBreedForm::TBreedForm(TComponent* Owner) : TForm(Owner)
{
	notify = edited = 0;
	cookie = ~0;
	BreedView->Tag = (int) new Srt(BreedView);
	breed_list = new StringList;
	Clear(); // ����������� ������ �������
}

//---------------------------------------------------------------------------

__fastcall TBreedForm::~TBreedForm()
{
	notify++;
	delete breed_list;
	delete (Srt *) BreedView->Tag;
}

//---------------------------------------------------------------------------

void __fastcall TBreedForm::Render()
{
	TListItem *li;
	notify++;
	BreedView->Items->BeginUpdate();
	BreedView->Items->Clear();
	for (int i = 0,max = breed_list->Count; i < max; )
	{
		li = BreedView->Items->Add();
		li->ImageIndex = -2;
		li->Data = (void *) i;
		li->Caption = breed_list->GetString(i++);
		li->SubItems->Add(breed_list->GetString(i++));
		li->SubItems->Add(breed_list->GetString(i++));
	}
	((Srt *) BreedView->Tag)->Process();
	BreedView->Items->EndUpdate();
	notify--;
	Remember->Enabled = false;
	Assign->Enabled = false;
}

//---------------------------------------------------------------------------

void __fastcall TBreedForm::FormShow(TObject *)
{
	Remember->Enabled = false;
	Assign->Enabled = false;
	edited = 0;
	TListItem *li;
	int x;
	for (int i = 0; i < BreedView->Items->Count; i++)
	{
		li = BreedView->Items->Item[i];
		x = PopulationWin->rabbits->HowManyRabbitsWithThisBreed(breed_list->FindString(li->Caption) / BREED_STEP);
		if (li->SubItems->Count < 3)
			li->SubItems->Add(x);
		else
			li->SubItems->Strings[2] = x;
	}
}

//---------------------------------------------------------------------------

void __fastcall TBreedForm::RememberClick(TObject *)
{
	Remember->Enabled = false;
	if (edited)
	{
		for (int i = 0; i++ < LIST_STEP; breed_list->DeleteString(edited));
		edited = 0;
	}
	else if (breed_list->FindString(BreedFull->Text) != ~0 || breed_list->FindString(BreedShort->Text) != ~0)
	{
		MessageBox(NULL,"�������� ������ ��� ��������, ���� �� �������!","�������",MB_APPLMODAL|MB_ICONEXCLAMATION|MB_OK);
		return;
	}
	breed_list->AddString(BreedFull->Text);
	breed_list->AddString(BreedShort->Text);
	breed_list->AddString(BreedGroupUD->Position);
	notify++;
	BreedFull->Clear();
	BreedShort->Clear();
	notify--;
	Render();
}

//---------------------------------------------------------------------------


void __fastcall TBreedForm::BreedShortChange(TObject *)
{
	Remember->Enabled = !BreedFull->Text.IsEmpty() && !BreedShort->Text.IsEmpty() && BreedGroupUD->Position;
}

//---------------------------------------------------------------------------

void __fastcall TBreedForm::BreedViewDblClick(TObject *)
{
	TListItem *li = BreedView->Selected;
	if (!li) return;
	int i = (int) li->Data;
	int x = atoi(breed_list->GetString(i + 2));
	if (!x) return; 																// ������ �� �������������
	edited = i;
	notify++;
	BreedFull->Text = breed_list->GetString(i++);
	BreedShort->Text = breed_list->GetString(i++);
	BreedGroupUD->Position = x;
	notify--;
}

//---------------------------------------------------------------------------

void __fastcall TBreedForm::BreedViewColumnClick(TObject *Sender,TListColumn *Column)
{
	((Srt *) ((TComponent *) Sender)->Tag)->Process(Column);
}

//---------------------------------------------------------------------------

void __fastcall TBreedForm::BreedViewClick(TObject *)
{
	TListItem *li = BreedView->Selected;
	Assign->Enabled = (cookie = li ? (int) li->Data / LIST_STEP : ~0) >= 0;
}

//---------------------------------------------------------------------------

void	__fastcall TBreedForm::Clear()
{
	breed_list->ClearStrings();
	breed_list->AddString("������");
	breed_list->AddString("---");
	breed_list->AddString("0");
	BreedView->Items->Clear();
	Render();
}

//---------------------------------------------------------------------------

bool __fastcall TBreedForm::DiffGroups(unsigned short a,unsigned short b)
{
	return a && b && a != b && strcmp(breed_list->GetString(a * BREED_STEP + COLOR_BIAS),breed_list->GetString(b * BREED_STEP + COLOR_BIAS)) != 0;
}

//---------------------------------------------------------------------------

void __fastcall TBreedForm::DeleteClick(TObject *)
{
	TListItem *li = BreedView->Selected;
	if (!li) return;
	if (!li->Caption.AnsiCompareIC(AnsiString("������")))
	{
		MessageBox(NULL,"\"������\" ������� ������!","��������",MB_APPLMODAL|MB_ICONEXCLAMATION|MB_OK);
		return;
	}
	unsigned char bi,bx;
	if (PopulationWin->rabbits->HowManyRabbitsWithThisBreed(bi = (bx = breed_list->FindString(li->Caption)) / BREED_STEP))
	{
		MessageBox(NULL,"������ ������� ������, ���������\n�� ����� ���� ������� ����� ������!","��������",MB_APPLMODAL|MB_ICONEXCLAMATION|MB_OK);
		return;
	}
	PopulationWin->rabbits->DeleteBreed(bi);
	for (bi = 3; bi--; breed_list->DeleteString(bx));
	delete li;
}

//---------------------------------------------------------------------------

void __fastcall TBreedForm::FormClose(TObject *,TCloseAction &Action)
{
  BreedView->Selected = NULL;
}

//---------------------------------------------------------------------------

int __fastcall TBreedForm::FindBreed(const char *p)
{
  for (int i = 0; i < breed_list->Count; i++)
    if (!russtricmp(p,breed_list->GetString(i++)) || !russtricmp(p,breed_list->GetString(i++)))
      return i / BREED_STEP;
  return -1;
}
