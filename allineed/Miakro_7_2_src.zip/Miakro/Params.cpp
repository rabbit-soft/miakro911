#include <vcl\vcl.h>
#pragma hdrstop

#include "Miakro.h"
#include "Params.h"
#include "ReportWin.h"
#include "MoneyForm.h"
#include "Zones.h"
#include "Graph.h"
#include "Young.h"
#include "FeedGraph.h"
#include "Shed.h"
#include "PlemPassport.h"

//---------------------------------------------------------------------------

#pragma link "CSPIN"
#pragma link "CGAUGES"
#pragma resource "*.dfm"

#define APRIL 	 4
#define OCTOBER 10
#define SPEC_MASK (1 << 15) // ����� �� ������� ��� ����������

TParamForm *ParamForm;
TCheckBox *TParamForm::check_boxes[MAX_CHECK_BOXES];

enum { TO_ADDR,TO_WHEN,TO_FILE,TO_NOTES };
enum { FROM_WHEN,FROM_WHOM,FROM_NOTES };

#define MAX_SER 500

//---------------------------------------------------------------------------

const char * const TParamForm::tier_names[][2] =
{
	{ "",							"" 		 },
	{ "����������",		"����" },
	{ "�������������","2���" },
	{ "�����������",  "����" },
	{ "����",         "����" },
	{ "������",       "����" },
	{ "������",				"����" },
	{ "�����",				"����" },
	{ "������",				"����" }
};

//---------------------------------------------------------------------------

const char * const TParamForm::build_status_names[][2] =
{
	{ "��������",	"����" },
	{ "������",  	"���"  },
	{ "������",   "���"  }
};

//---------------------------------------------------------------------------
const char * const TParamForm::b_names[][2] =
{
	{ "�����",	"�" },
	{ "����",  	"�" },
	{ "���",  	"�" },
	{ "�������","�" }
};

//---------------------------------------------------------------------------

const char * const TParamForm::area_names[][2] =
{
	{ "���������",	"��" 	},
	{ "�����",  		"���" },
	{ "�.�����",  	"���" },
	{ "�.�����",  	"���" },
	{ "�����������","���" },
	{ "������",     "���" }
};

//---------------------------------------------------------------------------

const char * const TParamForm::status_names[MAX_SEX][MAX_STATUS][3] =
{
	{
		{ "����������",   "???", ""		}, // ��� ��������� �����
		{ "���������",    "���", "��"	}, // ���� � �������, ������ ����
		{ "���������",    "���", "��" }, // ���� � �������, ������ ���
	},
	{
		{ "�������",      "���", "�"	}, // father - ������ ���������
		{ "��������",     "���", "�"  },
		{ "�������������","���", "�"	},
	},
	{
		{ "�������",      "���", "�" 	},
		{ "�������",      "���", "�" 	},
		{ "�����������",  "���", "�" 	},
		{ "�������",      "���", "��"	},
	}
};

const char * const TParamForm::zone_names[MAX_KNOWN_ZONES][2] =
{
	{ "�������","---" },
};

//---------------------------------------------------------------------------

const char *TParamForm::job_names[MAX_JOBS][2] =
{
	{ "�������",				   	"����" },
	{ "C������",			     	"��" 	 },
	{ "������",					   	"����" },
	{ "���",						   	"���"  },
	{ "�����. ������",	 		"����" },
	{ "���. ������/������",	"����" },
	{ "������� �������",	 	"����" },
	{ "�������� ������",   	"����" },
	{ "�������������",     	"����" },
	{ "������� �����",     	"����" },
	{ "������� ���������", 	"����" },
	{ "������� ���������", 	"����" },
	{ "����������",        	"����" },
	{ "������� ���������", 	"����" },
	{ "������. ���������",	"���a" },
	{ "������ ������",      "����" },
	{	"��������� ��������",	"����" },
	{	"��������",        		"����" },
	{	"����������",      		"����" },
	{ "��������� � ����",		"���"  },
  { "�����������",        "���"  }
};

//---------------------------------------------------------------------------

const char *TParamForm::spec[MAX_SPEC][2] =
{
	{ "������������ ","c�-" 	},
	{ "�� ����������","�/��" 	},
};

//---------------------------------------------------------------------------

__fastcall TParamForm::TParamForm(TComponent* Owner) : TForm(Owner)
{
	notify = 0;
	TOpenOptions OpOp;
	OpOp << ofNoChangeDir;
	SaveDialog->Options = OpOp;
	OpenDialog->Options = OpOp;
  wl = new WeighterList;
  wl->Add(new Weighter(C0,B0,L0A,R0,L0B));
  wl->Add(new Weighter(C1,B1,L1A,R1,L1B));
  wl->Add(new Weighter(C2,B2,L2A,R2,L2B));
  wl->Add(new Weighter(C3,B3,L3A,R3,L3B));
  wl->Add(new Weighter(C4,B4,L4A,R4,L4B));
  wl->Add(new Weighter(C5,B5,L5A,R5,L5B));
  wl->Add(new Weighter(C6,B6,L6A,R6,L6B));
  wl->Add(new Weighter(C7,B7,L7A,R7,L7B));
  wl->Render();
  locked = false;
	check_boxes[0] 	= P_Okrols;
	check_boxes[1] 	= P_Counts;
	check_boxes[2] 	= P_Vudvor;
	check_boxes[3] 	= P_Kuks;
	check_boxes[4] 	= P_Vyazka;
	check_boxes[5] 	= P_Sluchka;
	check_boxes[6] 	= P_Rassadka;
	check_boxes[7] 	= P_OtsBoys;
	check_boxes[8] 	= P_Gnezd;
	check_boxes[9] 	= P_OtsGirls;
	check_boxes[10] = P_Predokr;
	check_boxes[11] = P_RasslBoys;
	check_boxes[12] = P_MoveRabbits;
	check_boxes[13] = P_MoveIn;
	check_boxes[14] = P_CleanKuku;
	check_boxes[15] = P_Vacc;
	check_boxes[16] = P_Jurta;
	check_boxes[17] = P_Weight;
	Works->RowCount = MAX_JOBS + 1;
	Works->Options << goEditing;
	Works->Cells[0][0] = "�����";
	Works->Cells[1][0] = "������ ��������";
	Works->Cells[2][0] = "������� ��������";
	RestoreNamesClick(NULL);
}

//---------------------------------------------------------------------------

__fastcall TParamForm::~TParamForm()
{
  notify++;
  delete wl;
}

//---------------------------------------------------------------------------

void __fastcall TParamForm::Cfg2View()
{
	notify++;
	if (!Config.averfeed)
		Config.averfeed = 107;
	if (ResCopies->MinValue > Config.rescopies)
		Config.rescopies = ResCopies->Value;       // �������� ��� �������� ������ ������ �����
	else
		ResCopies->Value = Config.rescopies;
	ThisFarm->Text = PopulationWin->ThisFarm;
	FarmId->Text = PopulationWin->FarmId;
	PervoNest->Value 	=   Config.pervonest; // ����������� ����������� ��������� � ���������
	KukuNest->Value 	=   Config.kukunest;
	MotherNest->Value =   Config.mothernest;
	Heater->Value 		=   Config.heater;
	Okrol->Value 			=   Config.okrol;
	Kuk->Value 				=   Config.kuk;
	Pravka_1->Value 	=   Config.pravka_1;
	Count_2->Value 		=   Config.count_2;
	Count_3->Value 		=   Config.count_3;
	EndKuku->Value 		=   Config.endkuku;
	Vacc->Value 			=   Config.vacc;
	Vudvorenie->Value =   Config.vudvorenie;
	CountSuckers->Value  = Config.countsuckers;
	VyazkaMother->Value  = Config.vyazkamother;
	VyazkaPervo->Value 	 = Config.vyazkapervo;
	OtsRassMother->Value = Config.otsad_boys_mother;
	OtsRassPervo->Value  = Config.otsad_boys_pervo;
	RasselBoys->Value 	 = Config.rasselboys;
	KillFemales->Value 	 = Config.killfemales;
	MaxAgeDiff->Value 	 = Config.max_age_diff;
	if (ImmedAgeDiff->MinValue > Config.imm_age_diff)
		Config.imm_age_diff = ImmedAgeDiff->Value;       // �������� ��� �������� ������ ������ �����
	else
		ImmedAgeDiff->Value =   Config.imm_age_diff;
	MakeBrides->Value 		=  Config.make_brides;
	KeepLoss->Value 			= Config.lost_days;
	AutoArchive->Checked  = Config.auto_arc;
	AverFeed->Value 			= Config.averfeed;
	NoKuk->Checked 				= Config.no_kuk;
	NoJurtaKuk->Checked 	= Config.no_jurta_kuk;
	if (Config.shed_scale >= ShedScale->Min)
	{
		ShedScale->Position = Config.shed_scale;
    Percentage->Caption = String((int) Config.shed_scale) + '%';
  }
  HolostPunish->Value = Config.holost_punish;
  ImmHeater->ItemIndex = Config.imm_heater;
  NoGenMix->Checked = Config.no_gen_mix;
	SluchkaFilter->ItemIndex = Config.sluchka_filter;
	if (!Config.from_heater || old_file_version)
		Config.from_heater = CalcHeaterDate(false);
	HeaterFrom->Date = (int) Config.from_heater;
	HeaterFrom->Checked = old_file_version || Config.h_from_checked;
	if (!Config.till_heater || old_file_version)
		Config.till_heater = CalcHeaterDate(true);
	HeaterTill->Date = (int) Config.till_heater;
	HeaterTill->Checked = old_file_version || Config.h_till_checked;
	SectionsIgnore->Checked = Config.sec_ignore;
	AutoKuk->Checked = Config.auto_kuk;
	JurtaSync->Checked = Config.jurta_sync;
	ArcTime->Value = Config.arctime;
	PopulationWin->notify++;
	PopulationWin->TabAbbr->Checked 	 			 = Config.tab_abbr;
	PopulationWin->DoubleSurnames->Checked 	 = Config.double_sur;
	PopulationWin->ShowTierTypes->Checked 	 = Config.show_tier_types;
	PopulationWin->ShowAreaTypes->Checked 	 = Config.show_area_types;
	PopulationWin->Heterosis->Checked 			 = Config.heterosis;
	PopulationWin->Inbreeding->Checked 			 = Config.inbreeding;
	PopulationWin->ShowNumbers->Checked 		 = Config.show_numbers;
	PopulationWin->NumberBeforeName->Checked = Config.number_before_name;
	Config.today = today;
	PopulationWin->notify--;
	TransForm->notify++;
	TransForm->From->Date = int (Config.from ? Config.from : (Config.from  = today));
	TransForm->Till->Date = int (Config.till ? Config.till : (Config.till = today + 1));
	TransForm->From->Checked = Config.use_from;
	TransForm->Till->Checked = Config.use_till;
	TransForm->notify--;
	GraphForm->notify++;
	GraphForm->MaleTrack->Position =  Config.killboys;
	GraphForm->MaleLabel->Caption = (int) Config.killboys;
	GraphForm->FemaleTrack->Position =  Config.killbrides;;
	GraphForm->FemaleLabel->Caption = (int) Config.killbrides;
	GraphForm->ManualAvto->ItemIndex = Config.automode;
	GraphForm->notify--;
	TransForm->notify++;
	TransForm->MothersWithBabies->Checked = Config.sell_mothers_with_babies;
	TransForm->notify--;
	unsigned long mask = 1;
	for (int i = 0; i < MAX_CHECK_BOXES; i++,mask <<= 1)
		if (check_boxes[i])
			check_boxes[i]->Checked = (bool) (Config.zoo_bits & mask);
	JobGrouping->Checked = Config.job_grouping;
	ShowPartnerNames->Checked = Config.name_show;
  IgnoreLastFuck->Checked = Config.ignore_last_fuck;
	Limit->Checked = Config.partners_limit;
	LimitFuckers->Value = Config.limit_value;
  FeedGraphForm->UseSpec->Checked = Config.use_feed_spec;
	CorrectDayLabels();
  if (!Config.rot_speed)
    Config.rot_speed = 200;
  ShedForm->ShedTimer->Interval = Config.rot_speed;
  ShedForm->Rotation->Checked = Config.rotation;
	notify--;
}

//---------------------------------------------------------------------------

void __fastcall TParamForm::CfgChange(TObject *)
{
	if (notify) return;
	View2Cfg();
}

//---------------------------------------------------------------------------

void __fastcall TParamForm::View2Cfg()
{
	if ((Config.rescopies = ResCopies->Value) < ResCopies->MinValue)
	{
		notify++;
		ResCopies->Value = Config.rescopies = ResCopies->MinValue; // ������������
		notify--;
	}
	if (!ThisFarm->Text.Trim().IsEmpty())
		PopulationWin->ThisFarm = ThisFarm->Text.c_str();
	if (!FarmId->Text.Trim().IsEmpty())
		PopulationWin->FarmId = FarmId->Text;
	Config.pervonest 		= PervoNest->Value;
	Config.kukunest 		= KukuNest->Value;
	Config.mothernest 	= MotherNest->Value;
	Config.heater 			= Heater->Value;
	Config.okrol 				= Okrol->Value;
	Config.kuk 					= Kuk->Value;
	Config.pravka_1 		= Pravka_1->Value;
	Config.count_2 			= Count_2->Value;
	Config.count_3 			= Count_3->Value;
	Config.endkuku 			= EndKuku->Value;
	Config.vacc 				= Vacc->Value;
	Config.vudvorenie 	= Vudvorenie->Value;
	Config.countsuckers = CountSuckers->Value;
	Config.vyazkamother = VyazkaMother->Value;
	Config.vyazkapervo 	= VyazkaPervo->Value;
	Config.otsad_boys_mother = OtsRassMother->Value;
	Config.otsad_boys_pervo	= OtsRassPervo->Value;
	Config.rasselboys 			= RasselBoys->Value;
	Config.killfemales 			= KillFemales->Value;
	Config.max_age_diff 		= MaxAgeDiff->Value;
	Config.imm_age_diff 		= ImmedAgeDiff->Value;
	Config.sluchka_filter 	= SluchkaFilter->ItemIndex;
	Config.from_heater 			= (int) HeaterFrom->Date;
	Config.h_from_checked		= HeaterFrom->Checked;
	Config.till_heater 			= (int) HeaterTill->Date;
	Config.h_till_checked		= HeaterTill->Checked;
	Config.automode 		= GraphForm->ManualAvto->ItemIndex;
	Config.killboys 		= GraphForm->MaleTrack->Position;
	Config.killbrides 	= GraphForm->FemaleTrack->Position;
	Config.make_brides 	= MakeBrides->Value;
	Config.lost_days		= KeepLoss->Value;
	Config.auto_arc     = AutoArchive->Checked;
	Config.averfeed 		= AverFeed->Value;
	Config.no_kuk 	    = NoKuk->Checked;
	Config.no_jurta_kuk = NoJurtaKuk->Checked;
	Config.shed_scale   = ShedScale->Position;
	Percentage->Caption = String((int) Config.shed_scale) + '%';
	Config.no_gen_mix   = NoGenMix->Checked;
	Config.holost_punish = HolostPunish->Value;
	Config.imm_heater    = ImmHeater->ItemIndex;
	Config.use_from 	 	= TransForm->From->Checked;
	Config.use_till 		= TransForm->Till->Checked;
	Config.from 				=	(int) TransForm->From->Date;
	Config.till 				= (int) TransForm->Till->Date;
	Config.today				= today;
	Config.sec_ignore 	= SectionsIgnore->Checked;
	Config.auto_kuk 		= AutoKuk->Checked;
	Config.jurta_sync   = JurtaSync->Checked;
	Config.arctime 			= ArcTime->Value;
	Config.sell_mothers_with_babies = TransForm->MothersWithBabies->Checked;
	unsigned long mask = 1;
	for (int i = 0; i < MAX_CHECK_BOXES; i++,mask <<= 1)
		if (check_boxes[i])
		{
			if (check_boxes[i]->Checked)
				Config.zoo_bits |= mask;
			else
				Config.zoo_bits &= ~mask;
		}
	Config.job_grouping = JobGrouping->Checked;
	Config.name_show = ShowPartnerNames->Checked;
	Config.ignore_last_fuck = IgnoreLastFuck->Checked;
	Config.partners_limit = Limit->Checked;
	Config.limit_value = LimitFuckers->Value;
	Config.use_feed_spec = FeedGraphForm->UseSpec->Checked;
	CorrectDayLabels();
	Config.gen_tree_width = PopulationWin->GenTreePanel->Width;
	Config.young_gen_tree_width = YoungForm->GenTreePanel->Width;
	PopulationWin->RefreshStatus();
}

//---------------------------------------------------------------------------

bool __fastcall TParamForm::CalcMode(ABBR mode) const
{
	switch (mode)
	{
		case AS_TAB:
			return Config.tab_abbr;
		case AS_SHORT:
			return true;
		default:
			return false;
	}
}

//---------------------------------------------------------------------------

String __fastcall TParamForm::GetZoneName(unsigned short zone,ABBR mode,bool away) const
{
	if (zone)
	{
		StringList *sl = ZoneForm->GetZoneList();
		int i,max = sl->Count;
		for (i = 0; i < max; i++)
			if (zone == (unsigned short) atoi(sl->GetString(i)))
			{
				const char *p,*px;
				if (p = strchr(px = sl->GetString(i + CalcMode(mode)),':'))
					return ++p;
				else
					return px;
			}
		PopulationWin->Terminator("#P0: ��������� ���������� � �����!");
	}
  else if (away)
		return PopulationWin->ThisFarm;
	return TParamForm::zone_names[zone][CalcMode(mode)];
}

//---------------------------------------------------------------------------

const char * __fastcall TParamForm::GetJobName(JOB x,ABBR mode)  const
{
	static char buf[100];
	return strcpy(buf,Works->Cells[CalcMode(mode) + 1][(char) x + 1].c_str());
}

//---------------------------------------------------------------------------
 
bool __fastcall TParamForm::TestHeater()
{
	try
	{
		int f = HeaterFrom->Date;
		int t = HeaterTill->Date;
		if (f > t) throw(NULL);
		Config.from_heater = f;
		Config.till_heater = t;
		return true;
	}
	catch (...) { MessageBox(NULL,"��������� ���� ��������� ������!","����������",MB_APPLMODAL|MB_ICONEXCLAMATION|MB_OK); }
	return false;
}

//---------------------------------------------------------------------------

bool __fastcall TParamForm::IsCold(unsigned short date) const
{
	return (Config.h_from_checked || Config.h_till_checked)
		&&	(!Config.h_from_checked || date >= Config.from_heater)
		&& 	(!Config.h_till_checked || date <= Config.till_heater);
}

//---------------------------------------------------------------------------

const char * __fastcall TParamForm::GetStatusName(const Rabbit *r,ABBR mode) const
{
	bool sh;
	const char *p = TParamForm::status_names[r->GetSex()][r->GetStatus()][sh = CalcMode(mode)];
	if (sh || r->GetGroup() == 1)	return p;
	const char *px;
	char len;
	for (px = p + (len = strlen(p)); !isconsonant(*--px); len--);
	static char buf[20];
	strcpy(strncpy(buf,p,len) + len,TParamForm::status_names[r->GetSex()][r->GetStatus()][2]);
	return buf;
}

//---------------------------------------------------------------------------

const char * __fastcall TParamForm::GetBreedName(unsigned char breed,ABBR mode) const
{
	if (breed == VOID_BREED) return MULTIBREED;
  int x = breed * BREED_STEP + CalcMode(mode);
  const StringList *sl = BreedForm->GetBreedList();
  return x < sl->Count ? sl->GetString(x) : "???";
}

//---------------------------------------------------------------------------


void __fastcall TParamForm::FormClose(TObject *, TCloseAction &Action)
{
	PopulationWin->notify++;
	PopulationWin->ParamWin->Checked = false;
	PopulationWin->notify--;
}

//---------------------------------------------------------------------------


void __fastcall TParamForm::HeaterChange(TObject *)
{
	TestHeater();
}

//---------------------------------------------------------------------------

void __fastcall TParamForm::InverseClick(TObject *)
{
	if (notify) return;
	Config.zoo_bits ^= ~SPEC_MASK;
	Cfg2View();
}

//---------------------------------------------------------------------------

void __fastcall TParamForm::PermitAllClick(TObject *)
{
	if (notify) return;
	Config.zoo_bits |= ~SPEC_MASK;
	Cfg2View();
}

//---------------------------------------------------------------------------

void __fastcall TParamForm::AutoKukClick(TObject *)
{
	CfgChange(NULL);
	YoungForm->Render();
}

//---------------------------------------------------------------------------

int  __fastcall TParamForm::CalcHeaterDate(bool till)
{
	unsigned short day,month,year;
	Now().DecodeDate(&year,&month,&day);
	if (till)
	{
		if (month >= APRIL)
			year++;
	}
	else if (month < APRIL)
		year--;
	TDateTime Dt(year,till ? APRIL : OCTOBER,1);
	return (int) Dt;
}

//---------------------------------------------------------------------------

TStream& operator >> (TStream& s,TParamForm *pf)
{
	bool x = old_file_version || version_2_0 || version_2_2 || version_3_0 || version_3_1 || version_3_9 || version_4_2 || version_4_3 || version_5_0 || version_5_1;
	if (x || version_6_1)
	{
		memset(&pf->Config,0,sizeof(pf->Config));
		s.ReadBuffer(&pf->Config,sizeof(pf->Config) - 100);
	}
	else
		s.ReadBuffer(&pf->Config,sizeof(pf->Config));
	if (!x)
		s >> pf->NewConf;
	if (!old_file_version)
		pf->LoadWorks(s);
	return s;
}

//---------------------------------------------------------------------------

TStream& operator << (TStream& s,TParamForm *pf)
{
	s.WriteBuffer(&pf->Config,sizeof(pf->Config));
  s << pf->NewConf;
  pf->SaveWorks(s);
  return s;
}

//---------------------------------------------------------------------------

void __fastcall TParamForm::LoadWorks(TStream& s)
{
	char max;
	s.ReadBuffer(&max,1);
	for (char i = 0; i < max; i++)
		for (char j = 0; j < 2; Works->Cells[++j][i + 1] = GetStr(s));
}

//---------------------------------------------------------------------------

void __fastcall TParamForm::SaveWorks(TStream& s)
{
	char mj = MAX_JOBS;
	s.WriteBuffer(&mj,1);
	for (char i = 0; i < MAX_JOBS; i++)
		for (char j = 0; j < 2; PutStr(s,Works->Cells[++j][i + 1].c_str()));
}

//---------------------------------------------------------------------------


void __fastcall TParamForm::CorrectDayLabels()
{
	AnsiString D('�');
	Day_1->Caption = D + day_decl[Decler(Config.max_age_diff)];
	Day_2->Caption = D + day_decl[Decler(Config.imm_age_diff)];
	Day_3->Caption = D + day_decl[Decler(Config.arctime)];
	Day_4->Caption = D + day_decl[Decler(Config.lost_days)];
}

//---------------------------------------------------------------------------

TStream& __fastcall operator >> (TStream& s,WeighterList *wl)
{
  ParamForm->notify++;
	unsigned char x;
	s.ReadBuffer(&x,1);
	for (unsigned char i = 0; i < x; s >> wl->GetWeighter(i++));
	unsigned short y;
	s.ReadBuffer(&x,1);
	ParamForm->C_end->Checked = (bool) x;
  s.ReadBuffer(&y,sizeof(y));
  ParamForm->End->Position = y;
  ParamForm->notify--;
  wl->Render();
  return s;
}

//---------------------------------------------------------------------------

TStream& __fastcall operator << (TStream& s,WeighterList *wl)
{
  char x = wl->Count;
	s.WriteBuffer(&x,1);
  for (char i = 0; i < x; s << wl->GetWeighter(i++));
	x = (char) ParamForm->C_end->Checked;
	s.WriteBuffer(&x,1);
  unsigned short y = ParamForm->End->Position;
  s.WriteBuffer(&y,sizeof(y));
  return s;
}

//---------------------------------------------------------------------------

TStream& __fastcall operator >> (TStream& s,Weighter *w)
{
  unsigned short x;
	bool a;
	s.ReadBuffer(&a,1);
	w->on->Checked = a;
	s.ReadBuffer(&x,sizeof(x));
	w->start->Position = x;
	s.ReadBuffer(&x,sizeof(x));
	w->interval->Position = x;
	return s;
}

//---------------------------------------------------------------------------

TStream& __fastcall operator << (TStream& s,Weighter *w)
{
	bool z = w->on->Checked;
	s.WriteBuffer(&z,1);
	unsigned short x = w->start->Position;
	s.WriteBuffer(&x,sizeof(x));
  x = w->interval->Position;
  s.WriteBuffer(&x,sizeof(x));
  return s;
}

//---------------------------------------------------------------------------

void __fastcall TParamForm::RestoreNamesClick(TObject *)
{
	for (int i = 0; i < MAX_JOBS; i++)
	{
		Works->Cells[0][i + 1] = job_names[i][0];
		for (int j = 0; j < 2; j++)
			Works->Cells[j + 1][i + 1] = job_names[i][j];
	}
}

//---------------------------------------------------------------------------

void __fastcall TParamForm::RecalcWeight(TObject *Sender)
{
  const long my_object_mask = 0x8000;
  unsigned long tag = ((TComponent *) Sender)->Tag;

  if (notify || !(tag & my_object_mask)) return;
  wl->Render();
}

//---------------------------------------------------------------------------

void __fastcall WeighterList::Render() const
{
  ParamForm->notify++;
  ParamForm->Graph->Series[0]->Clear();
  for (int i = 0; i < Count; i++)
    GetWeighter(i)->Render(FindNextStart(i));
  ParamForm->End->Enabled = ParamForm->C_end->Checked;
  ParamForm->EndLabel->Caption = ParamForm->End->Position;
  ParamForm->EndLabel->Enabled = ParamForm->C_end->Checked;;
  ParamForm->notify--;
}

//---------------------------------------------------------------------------

int __fastcall WeighterList::FindNextStart(int i)
{
  int x;
  while (++i < Count)
    if (x = GetWeighter(i)->GetStart())
      return x;
  return ParamForm->C_end->Checked ? ParamForm->End->Position : 0;
}

//---------------------------------------------------------------------------

void __fastcall Weighter::Render(int end) const
{
  const char h[14] = { 1,2,3,4,5,6,7,6,5,4,3,2 };
  bool active = on->Checked;
  start->Enabled = active;
  interval->Enabled = active;
  start_l->Enabled = active;
  interval_l->Enabled = active;
  start_l->Caption = start->Position;
  interval_l->Caption = interval->Position;
  if (!active) return;
  String A;
  if (!end)
    end = start->Position + MAX_SER;
  for (int c = 0,i = start->Position; i < end; i += interval->Position)
    ParamForm->Graph->Series[0]->AddXY(i,h[c++ % (sizeof(h) - 1)],A,clTeeColor);
}

//---------------------------------------------------------------------------

__fastcall NewConfig::NewConfig()
{
  memset(reserved,0,sizeof(reserved));
  next_svid = ParamForm->SvidNum;
  svid_remarks = ParamForm->Remarks->Lines;
  svid_head = ParamForm->SvidHead;
  svid_farm = ParamForm->SvidFarm;
  sub[0] = new Subscriber(ParamForm->CB1,ParamForm->J1,ParamForm->N1,PlemReport->J1,PlemReport->N1);
  sub[1] = new Subscriber(ParamForm->CB2,ParamForm->J2,ParamForm->N2,PlemReport->J2,PlemReport->N2);
  sub[2] = new Subscriber(ParamForm->CB3,ParamForm->J3,ParamForm->N3,PlemReport->J3,PlemReport->N3);
  sub[3] = new Subscriber(ParamForm->CB4,ParamForm->J4,ParamForm->N4,PlemReport->J4,PlemReport->N4);
  sub[4] = new Subscriber(ParamForm->CB5,ParamForm->J5,ParamForm->N5,PlemReport->J5,PlemReport->N5);
}

//---------------------------------------------------------------------------

TStream& __fastcall operator >> (TStream& s,Subscriber *su)
{
	bool x;
	s.ReadBuffer(&x,1);
	su->on->Checked = x;
	su->job->Text = GetBufStr(s);
  su->name->Text = GetBufStr(s);
  return s;
}

//---------------------------------------------------------------------------

TStream& __fastcall operator << (TStream& s,Subscriber *su)
{
	bool x = su->on->Checked;
	s.WriteBuffer(&x,1);
	PutStr(s,su->job->Text);
	PutStr(s,su->name->Text);
  return s;
}

//---------------------------------------------------------------------------

TStream& __fastcall operator >> (TStream& s,NewConfig& Nc)
{
  int x;
  s.ReadBuffer(&x,sizeof(x));
  Nc.next_svid->Value = x;
  Nc.svid_remarks->Clear();
  for (s.ReadBuffer(&x,sizeof(x)); x--; Nc.svid_remarks->Add(GetBufStr(s)));
  Nc.svid_head->Text = GetBufStr(s);
  Nc.svid_farm->Text = GetBufStr(s);
  s.ReadBuffer(Nc.reserved,sizeof(Nc.reserved));
  for (char i = 0; i < MAX_SUBSCRIBE; s >> Nc.sub[i++]);
  return s;
}

//---------------------------------------------------------------------------

TStream& __fastcall operator << (TStream& s,const NewConfig& Nc)
{
  int x = Nc.next_svid->Value;
  s.WriteBuffer(&x,sizeof(x));
  x = Nc.svid_remarks->Count;
  s.WriteBuffer(&x,sizeof(x));
	for (int i = 0; i < x; PutStr(s,Nc.svid_remarks->Strings[i++]));
	PutStr(s,Nc.svid_head->Text);
	PutStr(s,Nc.svid_farm->Text);
	s.WriteBuffer(Nc.reserved,sizeof(Nc.reserved));
	for (char i = 0; i < MAX_SUBSCRIBE; s << Nc.sub[i++]);
	return s;
}

//---------------------------------------------------------------------------

void __fastcall NewConfig::Render()
{
  Subscriber *su;
  char i = MAX_SUBSCRIBE,j = MAX_SUBSCRIBE;
  while (--i >= 0)
  {
    su = sub[i];
    if (su->on->Checked)
      su->Render(sub[--j]);
  }
  while (--j >= 0)
    sub[j]->Clear();
}

//---------------------------------------------------------------------------

void __fastcall Subscriber::Render(const Subscriber *su) const
{
  su->l_job->Caption = job->Text;
  su->l_name->Caption = String("/ ") + name->Text + " /";
}
//---------------------------------------------------------------------------

void __fastcall TParamForm::SaveClick(TObject *)
{
  if (!SaveDialog->Execute()) return;
  try { Remarks->Lines->SaveToFile(SaveDialog->FileName); }
	catch (...) { MessageBox(NULL,"������ ������ ����� ����������!","������",MB_APPLMODAL|MB_ICONERROR|MB_OK); }
}

//---------------------------------------------------------------------------

void __fastcall TParamForm::OpenClick(TObject *)
{
  if (!OpenDialog->Execute()) return;
  try { Remarks->Lines->LoadFromFile(OpenDialog->FileName); }
	catch (...) { MessageBox(NULL,"������ �������� ����� ����������!","������",MB_APPLMODAL|MB_ICONERROR|MB_OK); }
}

//---------------------------------------------------------------------------



