#include <vcl\vcl.h>
#pragma hdrstop

#include "MoneyForm.h"
#include "Money.h"
#include "Params.h"
#include <sysutils.hpp>

//---------------------------------------------------------------------------

const char *skin_string[MAX_SKIN] = { "?","����","I","II","III","IV" };

//---------------------------------------------------------------------------

TStream& __fastcall operator << (TStream& s,const Trans *t)
{
	unsigned long l;
	unsigned short sh;
	bool bu;
	SKIN_TYPE sk;
	X_TYPE tx = t->GetType();
	s.WriteBuffer(&tx,sizeof(tx));
	PutStr(s,t->notes);
	s.WriteBuffer(&t->when,sizeof(t->when));
	s.WriteBuffer(&t->units,sizeof(t->units));
	switch (t->GetType())
	{
		case RABBITS:
			bu = t->IsSold();
			s.WriteBuffer(&bu,sizeof(bu));
			sh = t->GetAge();
			s.WriteBuffer(&sh,sizeof(sh));
			PutStr(s,t->GetName());
			sh = t->GetBreed();
			s.WriteBuffer(&sh,sizeof(sh));
			sh = t->GetWeight();
			s.WriteBuffer(&sh,sizeof(sh));
			PutStr(s,t->GetPartner());
			PriceOut(s,t->GetPrice());
			break;
		case SKIN:
			sh = t->GetAge();
			s.WriteBuffer(&sh,sizeof(sh));
			sh = t->GetMurderDate();
			s.WriteBuffer(&sh,sizeof(sh));
			bu = t->GetSex();
			s.WriteBuffer(&bu,sizeof(bu));
			sh = t->GetBreed();
			s.WriteBuffer(&sh,sizeof(sh));
			sk = t->GetSrt();
			s.WriteBuffer(&sk,sizeof(sk));
      PutStr(s,t->GetRabName());
      PutStr(s,t->GetAddress());
			break;
		case MEAT:
			sh = t->GetAge();
			s.WriteBuffer(&sh,sizeof(sh));
			sh = t->GetMurderDate();
			s.WriteBuffer(&sh,sizeof(sh));
			sh = t->GetBrutto();
			s.WriteBuffer(&sh,sizeof(sh));
			sh = t->GetNetto();
			s.WriteBuffer(&sh,sizeof(sh));
      PutStr(s,t->GetRabName());
      PutStr(s,t->GetAddress());
			break;
		case MEAT_SOLD:
			sh = t->GetAge();
			s.WriteBuffer(&sh,sizeof(sh));
			l = t->GetWeight();
			s.WriteBuffer(&l,sizeof(l));
			PutStr(s,t->GetPartner());
			PriceOut(s,t->GetPrice());
			break;
		case SKIN_SOLD:
			sh = t->GetAge();
			s.WriteBuffer(&sh,sizeof(sh));
			sk = t->GetSrt();
			s.WriteBuffer(&sk,sizeof(sk));
			PutStr(s,t->GetPartner());
			PriceOut(s,t->GetPrice());
			break;
		case OTHER:
			bu = t->IsSold();
			s.WriteBuffer(&bu,sizeof(bu));
		case FEED:                            // Other
			sh = t->GetAge();
			s.WriteBuffer(&sh,sizeof(sh));
			PutStr(s,t->GetName());
			l = t->GetWeight();
			s.WriteBuffer(&l,sizeof(l));
			PutStr(s,t->GetKind());
			PutStr(s,t->GetPartner());
			PriceOut(s,t->GetPrice());
      break;
		case USED_FEED:                       //  �����������
			sh = t->GetAge();
			s.WriteBuffer(&sh,sizeof(sh));
			PutStr(s,t->GetName());
			l = t->GetWeight();
			s.WriteBuffer(&l,sizeof(l));
			PutStr(s,t->GetKind());
      break;
		case OTSEV:                            // �����
			bu = t->IsSold();
			s.WriteBuffer(&bu,sizeof(bu));
			sh = t->GetAge();
			s.WriteBuffer(&sh,sizeof(sh));
			l = t->GetWeight();
			s.WriteBuffer(&l,sizeof(l));
			PutStr(s,t->GetPartner());
			PutStr(s,t->GetKind());
			PriceOut(s,t->GetPrice());
      break;
    default:
      PopulationWin->Terminator("����������� ��� ������� �������� (������)!");
	}
	return s;
}

//---------------------------------------------------------------------------

TStream& __fastcall operator << (TStream& s,const TransList *tl)
{
	long i = 0,count = tl->Count;
	for (s.WriteBuffer(&count,sizeof(count)); i < count; s << tl->GetTrans(i++));
	return s;
}

//---------------------------------------------------------------------------

TStream& __fastcall operator >> (TStream& s,TransList *tl)
{
	X_TYPE type;
	long count;
  memset(TransForm->needs_refresh,true,sizeof(TransForm->needs_refresh));
	tl->Clear();
	s.ReadBuffer(&count,sizeof(count));
	while (count--)
	{
		s.ReadBuffer(&type,1);
		switch (type)
		{
			case RABBITS:
				tl->Add(new Rabbits(s));
				break;
			case SKIN:
				tl->Add(new Skin(s));
				break;
			case MEAT:
				tl->Add(new Meat(s));
				break;
			case MEAT_SOLD:
				tl->Add(new MeatSold(s));
				break;
			case SKIN_SOLD:
				tl->Add(new SkinSold(s));
				break;
			case FEED:
				tl->Add(new Feed(s));
				break;
			case USED_FEED:
				tl->Add(new UsedFeed(s));
				break;
			case OTSEV:
				tl->Add(new Otsev(s));
				break;
      case OTHER:
				tl->Add(new Other(s));
        break;
			default:
        PopulationWin->Terminator("����������� ��� ������� �������� (��������)!");
		}
	}
	return s;
}

//---------------------------------------------------------------------------

void __fastcall TransList::Clear()
{
  if (owner)
  {
	  for (int i = Count; --i >= 0; Delete(i))
		  delete GetTrans(i);
  }
  else
    TList::Clear();    
}

//---------------------------------------------------------------------------

__fastcall Rabbits::Rabbits(const Rabbit *r,Currency pr,bool sld,bool diff_breeds,const char *sell_zone) : Trans(r)
{
	age = r->GetAge();
	sold = sld;
	name = strdup(r->GetFullName());
	breed = diff_breeds ? VOID_BREED : r->GetBreed();
	weight = r->GetWeight();
	partner = strdup(sell_zone ? sell_zone : ParamForm->GetZoneName(r->GetZone(),AS_TAB).c_str());
	price = pr;
}

//---------------------------------------------------------------------------

__fastcall Rabbits::Rabbits(TStream& s) : Trans(s)
{
	s.ReadBuffer(&sold,sizeof(sold));
	s.ReadBuffer(&age,sizeof(age));
	name = GetStr(s);
	s.ReadBuffer(&breed,sizeof(breed));
	s.ReadBuffer(&weight,sizeof(weight));
	partner = GetStr(s);
	PriceIn(s,price);
}

//---------------------------------------------------------------------------

void __fastcall Rabbits::ShowMe() const // ����� ������
{
	TListItem *li = TransForm->RabbitsSellBuyList->Items->Add();
	li->Data = (void *) this;
	li->Caption = DateToStr(when); 														// ����
	li->SubItems->Add(sold ? "�������" : "�������"); 					// ���
	li->SubItems->Add((int) units); 													// ����������
	li->SubItems->Add(name);  																// ���
	li->SubItems->Add(TransForm->Curr2Str(price));
	li->SubItems->Add(ParamForm->GetBreedName(breed,AS_TAB)); // ������
	li->SubItems->Add(partner);																// ����
	if (notes)
		li->SubItems->Add(NoBreak(notes));	      							// �������
}

//---------------------------------------------------------------------------

__fastcall Skin::Skin(const Rabbit *r) : Trans(r)
{
	age = r->GetAge();
	murder_date = today;
	breed = r->GetBreed();
	SetSex(r);
	srt = SK_UNKNOWN;
  name = strdup(r->GetFullName());
  address = r->GetAddressName() && *r->GetAddressName() ? strdup(r->GetAddressName()) : NULL;
}

//---------------------------------------------------------------------------

__fastcall Skin::Skin(TStream&s ) : Trans(s)
{
	s.ReadBuffer(&age,sizeof(age));
	s.ReadBuffer(&murder_date,sizeof(murder_date));
	s.ReadBuffer(&female,sizeof(female));
	s.ReadBuffer(&breed,sizeof(breed));
	s.ReadBuffer(&srt,sizeof(srt));
  if (old_file_version || version_2_0 || version_2_2 || version_3_0 || version_3_1 || version_3_9)
  {
    name = NULL;
    address = NULL;
  }
  else
  {
    name = GetStr(s);
    address = GetStr(s);
  }
}

//---------------------------------------------------------------------------

void __fastcall Skin::ShowMe() const  // ����� ����������� ������
{
	TListItem *li = TransForm->SkinList->Items->Add();
	li->ImageIndex = -2;
	li->Data = (void *) this;
	li->Caption = DateToStr(murder_date);											// ���� �����
	li->SubItems->Add(today - murder_date); 									// ����
	li->SubItems->Add(ParamForm->GetBreedName(breed,AS_TAB)); // ������
	li->SubItems->Add(skin_string[srt]);											// �����
	li->SubItems->Add(name ? name : " ");	 										// ���
	li->SubItems->Add(address ? address : " ");								// �����
	li->SubItems->Add(age);																		// �������
	if (notes)
		li->SubItems->Add(NoBreak(notes)); 											// �������
}

//---------------------------------------------------------------------------

__fastcall Meat::Meat(const Rabbit *r) : Trans(r)
{
	age = r->GetAge();
	murder_date = today;
	brutto = netto = 0;
  name = strdup(r->GetFullName());
  address = r->GetAddressName() && *r->GetAddressName() ? strdup(r->GetAddressName()) : NULL;
}

//---------------------------------------------------------------------------

__fastcall Meat::Meat(TStream& s) : Trans(s)
{
	s.ReadBuffer(&age,sizeof(age));
	s.ReadBuffer(&murder_date,sizeof(murder_date));
	s.ReadBuffer(&brutto,sizeof(brutto));
	s.ReadBuffer(&netto,sizeof(netto));
  if (old_file_version || version_2_0 || version_2_2 || version_3_0 || version_3_1 || version_3_9)
  {
    name = NULL;
    address = NULL;
  }
  else
  {
    name = GetStr(s);
    address = GetStr(s);
  }
}

//---------------------------------------------------------------------------

void __fastcall Meat::ShowMe() const // �������� ����������� �����
{
	TListItem *li = TransForm->BodyList->Items->Add();
	li->ImageIndex = -2;
	li->Data = (void *) this;
	li->Caption = DateToStr(murder_date);											// ���� �����
	li->SubItems->Add(today - murder_date); 									// ����
	li->SubItems->Add(brutto); 																// ������
	li->SubItems->Add(netto);																	// �����
	li->SubItems->Add(name ? name : " ");	 										// ���
	li->SubItems->Add(address ? address : " ");								// ���
	li->SubItems->Add(age);																		// �������
	if (notes)
		li->SubItems->Add(NoBreak(notes));  										// �������
}

//---------------------------------------------------------------------------

__fastcall MeatSold::MeatSold(const Meat *m,const char *prt,Currency pri,const char *notes) : Trans(notes) // �������� ��������� �����
{
	age 	 	= today;
	weight 	= m->GetNetto();
	partner = strdup(prt);
	price 	= pri;
}

//---------------------------------------------------------------------------

__fastcall MeatSold::MeatSold(TStream& s) : Trans(s)
{
	s.ReadBuffer(&age,sizeof(age));
	s.ReadBuffer(&weight,sizeof(weight));
	partner = GetStr(s);
	PriceIn(s,price);
}

//---------------------------------------------------------------------------

void __fastcall MeatSold::ShowMe() const  									// �������� ��������� �����
{
	TListItem *li = TransForm->SellMeetList->Items->Add();
	li->ImageIndex = -2;
	li->Data = (void *) this;
	li->Caption = DateToStr(age);        											// ���� �������
	li->SubItems->Add((int) units);          									// ���-��
	li->SubItems->Add((int) weight);													// ��� (long)
	li->SubItems->Add(TransForm->Curr2Str(price));
	li->SubItems->Add(TransForm->Curr2Str(price * (int) weight / 1000));	// ����� ���������
	li->SubItems->Add(partner);																						// ����������
	if (notes)
		li->SubItems->Add(NoBreak(notes)); 																	// �������
}

//---------------------------------------------------------------------------

__fastcall SkinSold::SkinSold(const Skin *sk,const char *par,Currency pr,const char *notes) : Trans(notes)
{
	age = today;
	srt = sk->GetSrt();
	partner = strdup(par);
	price = pr;
}

//---------------------------------------------------------------------------

__fastcall SkinSold::SkinSold(TStream& s) : Trans(s)
{
	s.ReadBuffer(&age,sizeof(age));
	s.ReadBuffer(&srt,sizeof(srt));
	partner = GetStr(s);
	PriceIn(s,price);
}

//---------------------------------------------------------------------------

void __fastcall SkinSold::ShowMe() const // �������� ��������� ������
{
	TListItem *li = TransForm->SkinSoldList->Items->Add();
	li->ImageIndex = -2;
	li->Data = (void *) this;
	li->Caption = DateToStr(age);		// ���� �������
	li->SubItems->Add((int) units);	// ����� ������
	li->SubItems->Add(TransForm->Curr2Str(price));
	li->SubItems->Add(partner);			// ����������
	if (notes)
		li->SubItems->Add(NoBreak(notes));
}

//---------------------------------------------------------------------------

__fastcall Feed::Feed(const char *nam,const char *kin,const char *prt,unsigned long w,Currency pr,const char *notes) : Trans(notes)
{
	age = 0;    		   											// ���� ����������
	name = strdup(nam); 										// �������� �����
	weight = w;        											// ���
	kind = strdup(kin ? kin : " "); 				// �������������
	partner = strdup(prt);								  // � ���� �������
	price = pr;         										// ���� �� ��
}

//---------------------------------------------------------------------------

__fastcall Feed::Feed(TStream& s) : Trans(s)
{
	s.ReadBuffer(&age,sizeof(age));
	name = GetStr(s);
	s.ReadBuffer(&weight,sizeof(weight));
	kind = GetStr(s);
	partner = GetStr(s);
	PriceIn(s,price);
}

//---------------------------------------------------------------------------

void __fastcall Feed::ShowMe() const
{
	TListItem *li = TransForm->FeedList->Items->Add();
	li->ImageIndex = -2;
	li->Data = (void *) this;
	li->Caption = DateToStr(when);						// ���� �������
	li->SubItems->Add(name);									// �������� �����
	li->SubItems->Add(kind ? kind : " ");			// ������������
	li->SubItems->Add((int) weight);					// ���
	li->SubItems->Add(TransForm->Curr2Str(price));
	li->SubItems->Add(TransForm->Curr2Str(price * (int) weight));	// ����� ���������
	li->SubItems->Add(partner);								// ����������
	if (notes)
		li->SubItems->Add(NoBreak(notes));     // �������
}

//---------------------------------------------------------------------------

__fastcall UsedFeed::UsedFeed(const char *nam,const char *kin,unsigned long w,const char *notes) : Trans(notes)
{
	age = 0;    		   											// ����� ��������
	name = strdup(nam); 										// �������� �����
	kind = strdup(kin ? kin : " "); 				// �������������
	weight = w;        											// ���
}

//---------------------------------------------------------------------------

__fastcall UsedFeed::UsedFeed(TStream& s) : Trans(s)
{
	s.ReadBuffer(&age,sizeof(age));
	name = GetStr(s);
	s.ReadBuffer(&weight,sizeof(weight));
	kind = GetStr(s);
}

//---------------------------------------------------------------------------

void __fastcall UsedFeed::ShowMe() const
{
	TListItem *li = TransForm->UsedFeedList->Items->Add();
	li->ImageIndex = -2;
	li->Data = (void *) this;
	li->Caption = DateToStr(when);						// ���� �������
	li->SubItems->Add(name);									// �������� �����
	li->SubItems->Add(kind ? kind : " ");			// ������������
	li->SubItems->Add((int) weight);					// ���
	if (notes)
		li->SubItems->Add(NoBreak(notes)); 	    // �������
}

//---------------------------------------------------------------------------

__fastcall Other::Other(bool sl,unsigned long units,const char *nam,const char *kin,const char *prt,unsigned long w,Currency pr,const char *notes) : Trans(notes,units)
{
	sold = sl;
	age = 0;
	name = strdup(nam);
	weight = w;
	kind = strdup (kin ? kin : " ");
	partner = strdup(prt);
	price = pr;
}

//---------------------------------------------------------------------------

__fastcall Other::Other(TStream& s) : Trans(s)
{
	s.ReadBuffer(&sold,sizeof(sold));
	s.ReadBuffer(&age,sizeof(age));
	name = GetStr(s);
	s.ReadBuffer(&weight,sizeof(weight));
	kind = GetStr(s);
	partner = GetStr(s);
	PriceIn(s,price);
}

//---------------------------------------------------------------------------

void __fastcall Other::ShowMe() const
{
	TListItem *li = TransForm->OtherList->Items->Add();
	li->ImageIndex = -2;
	li->Data = (void *) this;
	li->Caption = DateToStr(when);						// ���� �������
	li->SubItems->Add(sold ? "�������" : "�������");
	li->SubItems->Add(name);									// ��������
	li->SubItems->Add(kind ? kind : " ");			// ������������
	li->SubItems->Add((int) weight);					// ���/���-��
	li->SubItems->Add(TransForm->Curr2Str(price));
	li->SubItems->Add(TransForm->Curr2Str(price * (int) weight));	// ����� ���������
	li->SubItems->Add(partner);								// ����������
	if (notes)
		li->SubItems->Add(NoBreak(notes)); 			// �������
}

//---------------------------------------------------------------------------

__fastcall Otsev::Otsev(bool sl,const char *prt,const char *knd,unsigned long w,Currency pr,const char *notes) : Trans(notes)
{
	sold = sl;
	age = 0;
	weight = w;
	partner = strdup(prt);
  kind = strdup(knd);
	price = pr;
}

//---------------------------------------------------------------------------

__fastcall Otsev::Otsev(TStream& s) : Trans(s)
{
	s.ReadBuffer(&sold,sizeof(sold));
	s.ReadBuffer(&age,sizeof(age));
	s.ReadBuffer(&weight,sizeof(weight));
	partner = GetStr(s);
	kind = GetStr(s);
	PriceIn(s,price);
}

//---------------------------------------------------------------------------

void __fastcall Otsev::ShowMe() const
{
	TListItem *li = TransForm->OtsevList->Items->Add();
	li->ImageIndex = -2;
	li->Data = (void *) this;
	li->Caption = DateToStr(when);						                    // ���� �������
	li->SubItems->Add(sold ? "�������" : "������");
	li->SubItems->Add(GetKind());
	li->SubItems->Add((int) weight);					                    // ���
	li->SubItems->Add(sold ? TransForm->Curr2Str(price) : String(" "));
	li->SubItems->Add(sold ? TransForm->Curr2Str(price * (int) weight) : String(" ")); // ����� ���������
	li->SubItems->Add(sold ? partner : " ");	                    // ����������, ���� �������
	if (notes)
		li->SubItems->Add(NoBreak(notes));			                    // �������
}

//---------------------------------------------------------------------------

__fastcall Trans::Trans(const Rabbit *r)
{
  notes = r->GetNotes() && *r->GetNotes() ? strdup(r->GetNotes()) : NULL;
  when = today;
  units = r->GetGroup();
  TransForm->translist->modified = true;
}

//---------------------------------------------------------------------------

__fastcall Trans::Trans(TStream& s)
{
  notes = GetStr(s);
  s.ReadBuffer(&when,sizeof(when));
  s.ReadBuffer(&units,sizeof(units));
}

//---------------------------------------------------------------------------

__fastcall Trans::Trans(const char *nt,unsigned long u)
{
	try { when = (int) TransForm->TransDate->Date; }
	catch (...)
	{
		MessageBox(NULL,"���� ����������� �������! ������ ����������� ����!","���������",MB_APPLMODAL|MB_ICONEXCLAMATION|MB_OK);
		TransForm->TransDate->Date = (int) today;
	}
	notes = nt && *nt ? strdup(nt) : NULL;
	units = u;
	TransForm->translist->modified = true;
}
