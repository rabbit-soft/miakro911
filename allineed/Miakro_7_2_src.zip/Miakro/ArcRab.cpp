#include <vcl.h>
#pragma hdrstop

#include "ArcRab.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"
TArcRabForm *ArcRabForm;

//---------------------------------------------------------------------------

__fastcall TArcRabForm::TArcRabForm(TComponent* Owner) : TForm(Owner)
{
}

//---------------------------------------------------------------------------
