#ifndef AboutH
#define AboutH

//#define DEMO

//---------------------------------------------------------------------------

#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "CGAUGES.h"

extern const char last_used_file[];

//---------------------------------------------------------------------------

class TAboutForm : public TForm
{
__published:
  TLabel *VersLabel;
  TCGauge *Gauge;
  TLabel *DoLabel;
	TLabel *DataLabel;
private:
  float step,cur_gauge;
public:
  __fastcall TAboutForm(TComponent* Owner);
  void __fastcall Advance(int n = 1);
  void __fastcall Reset(const char *str = NULL,int pos = 0);
};

//---------------------------------------------------------------------------

extern PACKAGE TAboutForm *AboutForm;

//---------------------------------------------------------------------------

#endif
