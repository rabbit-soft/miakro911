//---------------------------------------------------------------------------
#ifndef OtsevRepH
#define OtsevRepH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Db.hpp>
#include <DBTables.hpp>
#include <ExtCtrls.hpp>
#include <Qrctrls.hpp>
#include <QuickRpt.hpp>
//---------------------------------------------------------------------------
class TOtsevRepForm : public TForm
{
__published:	// IDE-managed Components
  TQuickRep *Report;
  TQRBand *QRBand1;
  TQRLabel *Title;
  TQRBand *QRBand3;
  TQRSysData *QRSysData2;
  TQRSysData *QRSysData1;
  TQRSysData *QRSysData3;
  TQRSysData *QRSysData4;
  TQRBand *QRBand4;
  TQRLabel *Summary;
  TQRBand *QRBand2;
  TQRDBText *QRDBText1;
  TQRDBText *QRDBText2;
  TQRDBText *QRDBText3;
  TQRDBText *QRDBText5;
  TQRDBText *QRDBText6;
  TQRDBText *QRDBText10;
  TQRDBText *QRDBText11;
  TQRBand *QRBand5;
  TQRLabel *QRLabel1;
  TQRLabel *QRLabel2;
  TQRLabel *QRLabel3;
  TQRLabel *QRLabel5;
  TQRLabel *QRLabel6;
  TQRLabel *QRLabel9;
  TQRLabel *QRLabel10;
  TTable *Table;
  TDataSource *DataSource;
  TQRLabel *QRLabel4;
  TQRDBText *QRDBText4;
private:	// User declarations
public:		// User declarations
  __fastcall TOtsevRepForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TOtsevRepForm *OtsevRepForm;
//---------------------------------------------------------------------------
#endif
