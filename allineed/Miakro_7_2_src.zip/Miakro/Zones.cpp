#include <vcl\vcl.h>
#pragma hdrstop

#include "Miakro.h"
#include "Zones.h"

//---------------------------------------------------------------------------

#pragma resource "*.dfm"
TZoneForm *ZoneForm;

//---------------------------------------------------------------------------

__fastcall TZoneForm::TZoneForm(TComponent* Owner) : TForm(Owner)
{
	cookie = 0;
	edit_item - NULL;
	zone_list = new StringList;
}

//---------------------------------------------------------------------------

const char * __fastcall TZoneForm::CutStart(const char *p)
{
	return (strchr(p,':') + 1);
}

//---------------------------------------------------------------------------

void __fastcall TZoneForm::Render()
{
	int i,max = zone_list->Count;
	const char *p;
	TListItem *li;
	TWaitCursor Wait;
	ZoneView->Items->BeginUpdate();
	ZoneView->Items->Clear();
	for (i = 0; i < max; i++)
	{
		li = ZoneView->Items->Add();
		li->ImageIndex = -2;
		li->Data = (void *) i;
		li->Caption = CutStart(p = zone_list->GetString(i));
		li->SubItems->Add(zone_list->GetString(++i));
		li->SubItems->Add(atoi(p));
	}
	ZoneView->Items->EndUpdate();
}

//---------------------------------------------------------------------------

void __fastcall TZoneForm::FullNameChange(TObject *Sender)
{
	TestDone();
}

//---------------------------------------------------------------------------

void __fastcall TZoneForm::ShortNameChange(TObject *Sender)
{
	TestDone();
}

//---------------------------------------------------------------------------

void __fastcall TZoneForm::GenChange(TObject *Sender)
{
	TestDone();
}

//---------------------------------------------------------------------------

void __fastcall TZoneForm::TestDone(void)
{
	Add->Enabled = !FullName->Text.IsEmpty() && !ShortName->Text.IsEmpty() && !Gen->Text.IsEmpty();
	if (!Gen->Text.IsEmpty())
	{
		try { Gen->Text.ToInt(); }
		catch(...) { Gen->Clear(); }
	}
}

//---------------------------------------------------------------------------

void __fastcall TZoneForm::AddClick(TObject *)
{
	try
	{
		Gen->Text = Gen->Text.Trim();
		Gen->Text.ToInt();
		AnsiString a((Gen->Text + ':' + FullName->Text.Trim()).c_str());
		AnsiString b(ShortName->Text.Trim().c_str());
    if (a.IsEmpty() || b.IsEmpty()) throw ("���� �������� ��� �� ������ ���� �������!");
		if (edit_item)
		{
			int i = (int) edit_item->Data;
			edit_item = NULL;
			free((char *) zone_list->GetString(i));
			free((char *) zone_list->GetString(i + 1));
			zone_list->Items[i] = strdup(a.c_str());
			zone_list->Items[++i] = strdup(b.c_str());
		}
		else
		{
			zone_list->AddString(a.c_str());
			zone_list->AddString(b.c_str());
		}
		ShortName->Clear();
		FullName->Clear();
		Gen->Clear();
		Add->Enabled = false;
		Render();
	}
	catch(const char *p)
	{
		MessageBox(NULL,p,"������",MB_APPLMODAL|MB_ICONWARNING|MB_OK);
	}
	catch	(...)
	{
		MessageBox(NULL,"����������� ����� ������������ �����!","������",MB_APPLMODAL|MB_ICONWARNING|MB_OK);
		Gen->SetFocus();
	}
}

//---------------------------------------------------------------------------

void __fastcall TZoneForm::AutoClick(TObject *Sender)
{
	Gen->Text = PopulationWin->rabbits->FindFreeGenNumber(0xffff);
}

//---------------------------------------------------------------------------

void __fastcall TZoneForm::ZoneViewChange(TObject *, TListItem *Item,TItemChange Change)
{
	Ok->Enabled = Item->Selected;
}

//---------------------------------------------------------------------------

void __fastcall TZoneForm::OkClick(TObject *Sender)
{
	enum { SHORT,GENOM };
	TListItem *li;
	if (!(li = ZoneView->Selected)) return;
	cookie = (unsigned short) li->SubItems->Strings[GENOM].ToInt();
}

//---------------------------------------------------------------------------

void __fastcall TZoneForm::FormShow(TObject *)
{
	edit_item = NULL;
	Ok->Enabled = false;
}

//---------------------------------------------------------------------------

void __fastcall TZoneForm::ZoneViewDblClick(TObject *)
{
	edit_item = ZoneView->Selected;
	if (!edit_item) return;
	FullName->Text = edit_item->Caption;
	ShortName->Text = edit_item->SubItems->Strings[0];
	Gen->Text =	edit_item->SubItems->Strings[1];
	Add->Enabled = true;
	Ok->Enabled = false;
}

//---------------------------------------------------------------------------

