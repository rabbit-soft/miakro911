#include <vcl.h>
#pragma hdrstop

#include "MeatSold.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"
TMeatSoldForm *MeatSoldForm;

//---------------------------------------------------------------------------

__fastcall TMeatSoldForm::TMeatSoldForm(TComponent* Owner) : TForm(Owner)
{
}

//---------------------------------------------------------------------------
