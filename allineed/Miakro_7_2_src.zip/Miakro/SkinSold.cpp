#include <vcl.h>
#pragma hdrstop

#include "SkinSold.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"
TSkinSoldForm *SkinSoldForm;

//---------------------------------------------------------------------------

__fastcall TSkinSoldForm::TSkinSoldForm(TComponent* Owner) : TForm(Owner)
{
}

//---------------------------------------------------------------------------
