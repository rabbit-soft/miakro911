#include <vcl.h>
#pragma hdrstop

#include "GetBabies.h"
#include "Miakro.h"
#include "Params.h"
#include "Young.h"
#include "Sorting.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"

TGetBabiesForm *GetBabiesForm;

//---------------------------------------------------------------------------

__fastcall TGetBabiesForm::TGetBabiesForm(TComponent* Owner) : TForm(Owner)
{
	donors = NULL;
	GetBabyList->Tag = (int) new Srt(GetBabyList);
}

//---------------------------------------------------------------------------

__fastcall TGetBabiesForm::~TGetBabiesForm()
{
	if (donors) delete donors;
	delete (Srt *) GetBabyList->Tag;
}

//---------------------------------------------------------------------------

void __fastcall TGetBabiesForm::Add(Rabbit *from,unsigned short group_key,Rabbit *to)
{
	Donor *donor = new Donor(from,group_key,to);
	if (donors)
		donors->Add(donor);
	else
		donors = new Donors(donor);
	donor->ReCalc();
	GetBabyList->Columns->BeginUpdate();
	GetBabyList->Items->BeginUpdate();
	donor->Render(GetBabyList);
	Render();
	GetBabyList->Items->EndUpdate();
	GetBabyList->Columns->EndUpdate();
	Visible = true;
	PopulationWin->MoverWin->Checked = true;
}

//---------------------------------------------------------------------------

void __fastcall TGetBabiesForm::FormClose(TObject *,TCloseAction &Action)
{
	PopulationWin->MoverWin->Checked = false;
}

//---------------------------------------------------------------------------

void __fastcall TGetBabiesForm::Render()
{
	GetBabyList->Items->BeginUpdate();
	GetBabyList->Items->Clear();
	if (donors)
		for (int i = 0; i < donors->Count; donors->GetDonor(i++)->Render(GetBabyList));
	((Srt *) GetBabyList->Tag)->Process();
	GetBabyList->Items->EndUpdate();
}

//---------------------------------------------------------------------------

void __fastcall TGetBabiesForm::DelItemClick(TObject *)
{
	TItemStates Is;
	Is << isSelected;
	TListItem *li = GetBabyList->Selected;
	if (!li) return;
	GetBabyList->Items->BeginUpdate();
	Donor *d;
	do
	{
		d = (Donor *) li->Data; // ������ �� ���� ������� ������ ���������� � ���������� ���
		donors->Remove(d);
		delete d;
	}
	while (li = GetBabyList->GetNextItem(li,sdAll,Is));
	GetBabyList->Items->EndUpdate();
	Render();
}

//---------------------------------------------------------------------------

void __fastcall TGetBabiesForm::GetBabyListColumnClick(TObject *Sender,TListColumn *Column)
{
	((Srt *) ((TComponent *) Sender)->Tag)->Process(Column);
}

//---------------------------------------------------------------------------

void __fastcall TGetBabiesForm::ImmediateClick(TObject *)
{
	Mover();
}

//---------------------------------------------------------------------------

void __fastcall TGetBabiesForm::Mover() // ��������� ����������
{
	TItemStates Is;
	Is << isSelected;
	TListItem *li = GetBabyList->Selected;
	if (!li) return;
	bool done = false;
	Donor *d;
	GetBabyList->Items->BeginUpdate();
	do
	{
		d = (Donor *) li->Data; // ������ �� ���� ������� ������ ���������� � ���������� ���
		if (d->DoMoveBabies(false))
		{
			donors->Remove(d);
			delete d;
			done = true;
		}
	}
	while (li = GetBabyList->GetNextItem(li,sdAll,Is));
	GetBabyList->Items->EndUpdate();
	if (done)
	{
		Render();
		PopulationWin->ListUpdated();
		YoungForm->Render();
	}
}

//---------------------------------------------------------------------------

void __fastcall TGetBabiesForm::GetBabyListDblClick(TObject *)
{
	Mover();
}

//---------------------------------------------------------------------------

