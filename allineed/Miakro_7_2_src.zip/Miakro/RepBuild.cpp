#include <vcl.h>
#pragma hdrstop

#include "RepBuild.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"

TRepBuildForm *RepBuildForm;

//---------------------------------------------------------------------------

__fastcall TRepBuildForm::TRepBuildForm(TComponent* Owner) : TForm(Owner)
{
}

//---------------------------------------------------------------------------

