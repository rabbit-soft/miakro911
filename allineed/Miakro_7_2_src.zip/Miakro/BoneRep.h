#ifndef BoneRepH
#define BoneRepH

//---------------------------------------------------------------------------

#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Qrctrls.hpp>
#include <QuickRpt.hpp>
#include <Db.hpp>
#include <DBTables.hpp>
#include <ComCtrls.hpp>

class Rabbit;

//---------------------------------------------------------------------------

class TBoneReport : public TForm
{
__published:
  TDataSource *DataSource;
  TTable *Table;
  TQuickRep *Report;
  TQRBand *QRBand2;
  TQRLabel *DeltaLabel;
  TQRLabel *JobLabel;
  TQRLabel *QRLabel3;
  TQRLabel *Address;
  TQRLabel *QRLabel5;
  TQRLabel *QRLabel6;
  TQRLabel *QRLabel7;
  TQRLabel *QRLabel8;
  TQRLabel *QRLabel1;
  TQRBand *QRBand4;
  TQRDBText *Delta;
  TQRDBText *QRDBText2;
  TQRDBText *QRDBText3;
  TQRDBText *QRDBText4;
  TQRDBText *QRDBText5;
  TQRDBText *QRDBText6;
  TQRDBText *QRDBText7;
  TQRDBText *Job;
  TQRDBText *QRDBText1;
  TQRBand *QRBand5;
  TQRLabel *Summary;
  TQRBand *QRBand3;
  TQRSysData *WhenPrinted;
  TQRBand *QRBand1;
  TQRLabel *Title;
  TQRLabel *QRLabel2;
  TQRDBText *QRDBText8;
  TListView *Fake;
  TQRBand *QRBand6;
  TQRLabel *FarmId;
  TQRShape *HorLine;
private:
public:
       __fastcall TBoneReport(TComponent* Owner);
  int  __fastcall RenderRabbitList(TListView *lw);
  void __fastcall RenderRabbit(Rabbit *r);
};

//---------------------------------------------------------------------------

extern PACKAGE TBoneReport *BoneReport;

//---------------------------------------------------------------------------

#endif
