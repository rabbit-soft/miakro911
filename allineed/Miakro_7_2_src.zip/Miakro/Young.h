#ifndef YoungH
#define YoungH

//---------------------------------------------------------------------------

#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ComCtrls.hpp>

#include "Miakro.h"
#include "Rabbit.h"
#include <vcl\Menus.hpp>
#include <Db.hpp>
#include <DBTables.hpp>
#include <ExtCtrls.hpp>
#include <Qrctrls.hpp>
#include <quickrpt.hpp>

enum { Y_NAME,Y_GROUP,Y_AGE,Y_KUK,Y_SEX,Y_BREED,Y_ADDRESS,Y_CLASS,Y_MOTHER,Y_NEIGHBOURS,Y_PARTNERS,Y_NOTES,Y_MAXCOLS };

//---------------------------------------------------------------------------

class TYoungForm : public TForm
{
__published:
	TListView *YoungList;
	TStatusBar *Status;
	TMainMenu *MainMenu1;
	TMenuItem *N1;
	TMenuItem *Preview;
	TMenuItem *Print;
	TPopupMenu *YoungPopUp;
	TMenuItem *DieGroup;
	TMenuItem *DieOne;
	TMenuItem *N4;
	TMenuItem *MoveAllToSection;
	TMenuItem *MoveOneToSection;
	TMenuItem *N2;
	TMenuItem *MoveGroupRabList;
	TMenuItem *MoveOneRabList;
	TMenuItem *N3;
	TMenuItem *Self;
	TMenuItem *N5;
	TMenuItem *MarkSection;
  TMenuItem *MarkFeeder;
  TMenuItem *MarkParents;
  TMenuItem *DieFromGroup;
  TMenuItem *N6;
  TMenuItem *Bone;
  TMenuItem *N7;
  TMenuItem *PlemPreview;
  TMenuItem *PlemPrint;
  TGroupBox *GenTreePanel;
  TTreeView *GenTree;
  TSplitter *Splitter1;
  TMenuItem *N8;
  TMenuItem *ShowGenTree;
  TMenuItem *N9;
  TMenuItem *SvidYoung;
  TMenuItem *N11;
	void __fastcall FormShow(TObject *Sender);
	void __fastcall YoungListColumnClick(TObject *Sender, TListColumn *Column);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall YoungListChange(TObject *Sender, TListItem *Item,TItemChange Change);
	void __fastcall PreviewClick(TObject *Sender);
	void __fastcall PrintClick(TObject *Sender);
	void __fastcall MoveAllToSectionClick(TObject *Sender);
	void __fastcall YoungListDragOver(TObject *Sender, TObject *Source, int X,int Y, TDragState State, bool &Accept);
	void __fastcall YoungListDragDrop(TObject *Sender, TObject *Source, int X,int Y);
	void __fastcall MoveOneRabListClick(TObject *Sender);
	void __fastcall DieOneClick(TObject *Sender);
	void __fastcall DieGroupClick(TObject *Sender);
	void __fastcall SelfClick(TObject *Sender);
	void __fastcall MarkFeederClick(TObject *Sender);
	void __fastcall MarkSectionClick(TObject *Sender);
  void __fastcall MarkParentsClick(TObject *Sender);
  void __fastcall DieFromGroupClick(TObject *Sender);
  void __fastcall BoneClick(TObject *Sender);
  void __fastcall PlemPreviewClick(TObject *Sender);
  void __fastcall ShowGenTreeClick(TObject *Sender);
  void __fastcall SvidYoungClick(TObject *Sender);
private:
	bool defer; 																								// �������� �������
	void 				 __fastcall RealRender();
	const int  * __fastcall CountSuckers();
	void 				 __fastcall PreviewOrPrint(bool print);
  bool         __fastcall NotSingleLine();
public:
	char notify;
					__fastcall TYoungForm(TComponent* Owner);
					__fastcall ~TYoungForm();
	void 		__fastcall Render();
	void 		__fastcall Render(const Rabbit *r,unsigned char overall,const Rabbit *mother);
	void 		__fastcall RefreshStatus();
	int 		__fastcall CountSelected() const; // ���������� ����� ����� ��������� �������� � ���������� ��� ��� ���
	bool 		__fastcall RabMarker(Rabbit *r);
};

//---------------------------------------------------------------------------

extern TYoungForm *YoungForm;

//---------------------------------------------------------------------------

#endif

