#include <vcl.h>
#pragma hdrstop

#include "Other.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"
TOtherForm *OtherForm;

//---------------------------------------------------------------------------

__fastcall TOtherForm::TOtherForm(TComponent* Owner) : TForm(Owner)
{
}

//---------------------------------------------------------------------------
