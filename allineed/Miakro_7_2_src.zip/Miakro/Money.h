#ifndef MoneyH
#define MoneyH

#include "Miakro.h"
#include "Rabbit.h"
#include "Params.h"
#include "MoneyForm.h"

extern const char *skin_string[MAX_SKIN];

class Rabbits;
class Trans;

//---------------------------------------------------------------------------

class TransList : public TList
{
  private:
    bool owner;
	public:
		bool modified;
										__fastcall TransList(bool own = true) : TList() { owner = own; }
		Trans* 		      __fastcall GetTrans(int i) { return (Trans *) Items[i]; }
		int					 		__fastcall NewTrans(Trans *t) { modified = true; return Add(t); }
		void			  	  __fastcall Clear();
		friend TStream& __fastcall operator << (TStream& s,const TransList *tl);
		friend TStream& __fastcall operator >> (TStream& s,TransList *tl);
};

//---------------------------------------------------------------------------

class Trans
{
	protected:
		unsigned short when;       	 // ����
		char *				 notes;        // �������
		unsigned long	 units;        // ���������� ������
	public:
													 __fastcall Trans(const char *nt = NULL,unsigned long	 u = 1);
													 __fastcall Trans(const Rabbit *r);
													 __fastcall Trans(TStream& s);
		virtual					    	 __fastcall ~Trans() { if (notes) free(notes); }
		unsigned short      	 __fastcall GetWhen() const { return when; }
		const char * 		    	 __fastcall GetNotes() const { return notes; }
		void                	 __fastcall SetWhen(unsigned short x) { when = x; }
		void         		    	 __fastcall SetNotes(const char *p) { if (notes) free(notes); notes = p && *p ? strdup(p) : NULL; }
		virtual X_TYPE 	    	 __fastcall GetType() const = 0;

		virtual void  				 __fastcall SetPartner(const char *,Currency = 0) {} //  | Partner
		virtual const char * 	 __fastcall GetPartner() const { return NULL; }      //  |
		virtual void           __fastcall SetPrice(Currency c) {}                  //  |
		virtual Currency       __fastcall GetPrice() const { return 0; }           //  |

		virtual SKIN_TYPE 		 __fastcall GetSrt() const { return SK_UNKNOWN; }    // | Srt
		virtual	void      		 __fastcall SetSrt(SKIN_TYPE) {}   									 // |

		virtual unsigned long  __fastcall GetWeight() const { return 0; }          // | Weight
		virtual void				   __fastcall SetWeight(unsigned long) { }             // |

		virtual unsigned short __fastcall GetBreed() const { return 0; }          // | Breed
		virtual void       		 __fastcall SetBreed(unsigned short) {}             // | Breed

		virtual void  				  __fastcall SetName(const char *) {}
		virtual const char * 	  __fastcall GetName() const { return NULL; }
		virtual const char * 	  __fastcall GetKind() const { return NULL; }

		virtual unsigned short	__fastcall GetMurderDate() const { return 0; }
		virtual void				  	__fastcall SetMurderDate(unsigned short) {}
		virtual unsigned short	__fastcall GetBrutto() const { return 0; }
		virtual void				  	__fastcall SetBrutto(unsigned short) {}
		virtual unsigned short	__fastcall GetNetto() const { return 0; }
		virtual void				  	__fastcall SetNetto(unsigned short) {}
    virtual const char *    __fastcall GetRabName() const { return NULL; }
    virtual const char *    __fastcall GetAddress() const { return NULL; }

		virtual unsigned short __fastcall GetAge() const { return 0; }
		virtual void           __fastcall SetAge(unsigned short) {}

		virtual bool					 __fastcall IsSold() const { return false; }
		virtual bool					 __fastcall GetSex() const { return false; }
		virtual	void 		    	 __fastcall ShowMe() const = 0;
		friend TStream&     	 __fastcall operator << (TStream& s,const Trans *t);
};

//---------------------------------------------------------------------------

class Rabbits : public Trans
{
	private:
		unsigned short age;
		bool					 sold;
		char *				 name;
		unsigned short breed;
		unsigned short weight;
		char *				 partner;
		Currency			 price;
	public:
									 __fastcall Rabbits(const Rabbit *r,Currency price = 0,bool sold = false,bool diff_breeds = false,const char *zone = NULL);
									 __fastcall Rabbits(TStream& s);
									 __fastcall ~Rabbits() { if (name) free(name); if (partner) free(partner); }
		X_TYPE 				 __fastcall GetType() const { return RABBITS; }
		void 					 __fastcall ShowMe() const;
		unsigned short __fastcall GetAge() const { return age; }
		const char *   __fastcall GetName() const { return name; }
		unsigned short __fastcall GetBreed() const { return breed; }
		unsigned long  __fastcall GetWeight() const { return weight; }
		const char *   __fastcall GetPartner() const { return partner; }
		bool					 __fastcall IsSold() const { return sold; }
		Currency			 __fastcall GetPrice() const { return price; }
};

//---------------------------------------------------------------------------

class Skin : public Trans
{
	private:
		unsigned short age;    	  	 // ������� �������, ��� ������ ���������
		unsigned short murder_date;  // ���� �����
		unsigned short breed;
		bool           female;
		SKIN_TYPE 		 srt;
    const char *   name;         // ��� �������� �������
    const char *   address;      // ��� �����
	public:
									 __fastcall Skin(const Rabbit *r);
									 __fastcall Skin(TStream& s);
									 __fastcall ~Skin() { if (name) free((char *) name); if (address) free((char *) address); }
		X_TYPE 				 __fastcall GetType() const { return SKIN; }
		void 					 __fastcall ShowMe() const;
		unsigned short __fastcall GetAge() const { return age; }
		unsigned short __fastcall GetMurderDate() const { return murder_date; }
		void				   __fastcall SetMurderDate(unsigned short x) { murder_date = x; }
		unsigned short __fastcall GetBreed() const { return breed; }
		SKIN_TYPE      __fastcall GetSrt() const { return srt; }
		bool           __fastcall GetSex() const { return female; }
		void           __fastcall SetSex(const Rabbit *r) { female = r->GetSex() == FEMALE; }
		void      		 __fastcall SetSrt(SKIN_TYPE s) { srt = s; }
    const char *   __fastcall GetRabName() const { return name; }
    const char *   __fastcall GetAddress() const { return address; }
};

//---------------------------------------------------------------------------

class Meat : public Trans
{
	private:
		unsigned short age;    			 // ������� �������, ��� ����� ���������
		unsigned short murder_date;  // ���� �����
		unsigned short netto;        // ��� �����
		unsigned short brutto;       // ��� ������
    const char *   name;         // ��� �������� �������
    const char *   address;      // ��� �����
	public:
									 __fastcall Meat(const Rabbit *r);
									 __fastcall Meat(TStream& s);
									 __fastcall ~Meat() { if (name) free((char *) name); if (address) free((char *) address); }
		X_TYPE 				 __fastcall GetType() const { return MEAT; }
		void 					 __fastcall ShowMe() const;
		unsigned short __fastcall GetAge() const { return age; }
		unsigned short __fastcall GetMurderDate() const { return murder_date; }
		void				   __fastcall SetMurderDate(unsigned short x) { murder_date = x; }
		unsigned short __fastcall GetNetto() const { return netto; }
		unsigned short __fastcall GetBrutto() const { return brutto; }
    const char *   __fastcall GetRabName() const { return name; }
    const char *   __fastcall GetAddress() const { return address; }
		void           __fastcall SetNetto(unsigned short n)  { netto = n; }
		void           __fastcall SetBrutto(unsigned short b) { brutto = b; }
};

//---------------------------------------------------------------------------

class MeatSold : public Trans
{
	private:
		unsigned short age;
		unsigned long  weight;  // ����� ��� � �������
		char *				 partner;
		Currency			 price;   // ���� ����������
	public:
		__fastcall MeatSold(const Meat *m,const char *partner,Currency price,const char *notes);
		__fastcall MeatSold(TStream& s);
		__fastcall ~MeatSold() { if (partner) free(partner); }
		X_TYPE 				 __fastcall GetType() const { return MEAT_SOLD; }
		void 					 __fastcall ShowMe() const;
		unsigned short __fastcall GetAge() const { return age; }
		unsigned long  __fastcall GetWeight() const { return weight; }
		const char *   __fastcall GetPartner() const { return partner; }
		Currency			 __fastcall GetPrice() const { return price; }
		void					 __fastcall MoreBodies() { units++; }
		void					 __fastcall MoreWeight(unsigned long w) { weight += w; }
};

//---------------------------------------------------------------------------

class	SkinSold : public Trans
{
	private:
		unsigned short age;
		SKIN_TYPE 		 srt;
		char *				 partner;
		Currency			 price;
	public:
		__fastcall SkinSold(const Skin *sk,const char *par,Currency pr,const char *notes);
		__fastcall SkinSold(TStream& s);
		__fastcall ~SkinSold() { if (partner) free(partner); }
		X_TYPE 	__fastcall GetType() const { return SKIN_SOLD; }
		void 		__fastcall ShowMe() const;
		void 					 __fastcall MoreSkins() { units++; }
		void 					 __fastcall MorePrice(Currency c) { price += c; }
		unsigned short __fastcall GetAge() const { return age; }
		SKIN_TYPE      __fastcall GetSrt() const { return srt; }
		void      		 __fastcall SetSrt(SKIN_TYPE s) { srt = s; }
		const char *   __fastcall GetPartner() const { return partner; }
		Currency			 __fastcall GetPrice() const { return price; }
};

//---------------------------------------------------------------------------

class Feed : public Trans
{
	private:
		unsigned short age;
		char *				 name;
		unsigned long  weight;
		char *         kind;
		char *				 partner;
		Currency 			 price;
	public:
		__fastcall Feed(const char *nam,const char *kin,const char *prt,unsigned long w,Currency pr,const char *notes);
		__fastcall Feed(TStream& s);
		__fastcall ~Feed() { if (name) free(name); if (partner) free(partner); if (kind) free(kind); }
		X_TYPE 				 __fastcall GetType() const { return FEED; }
		void 					 __fastcall ShowMe() const;
		unsigned short __fastcall GetAge() const { return age; }
		const char * 	 __fastcall GetName() const 	 { return name; }
		unsigned long  __fastcall GetWeight() const { return weight; }
		const char * 	 __fastcall GetKind() const 	 { return kind; }
		const char * 	 __fastcall GetPartner() const { return partner; }
		Currency			 __fastcall GetPrice() const { return price; }
};

//---------------------------------------------------------------------------

class UsedFeed : public Trans
{
	private:
		unsigned short age;
		char *				 name;
		unsigned long  weight;
		char *         kind;
	public:
		__fastcall UsedFeed(const char *nam,const char *kin,unsigned long w,const char *notes);
		__fastcall UsedFeed(TStream& s);
		__fastcall ~UsedFeed() { if (name) free(name); if (kind) free(kind); }
		X_TYPE 				 __fastcall GetType() const { return USED_FEED; }
		void 					 __fastcall ShowMe() const;
		unsigned short __fastcall GetAge() const { return age; }
		const char * 	 __fastcall GetName() const 	 { return name; }
		unsigned long  __fastcall GetWeight() const { return weight; }
		const char * 	 __fastcall GetKind() const 	 { return kind; }
};

//---------------------------------------------------------------------------

class Other : public Trans
{
	private:
		unsigned short age;
		bool					 sold;	// �������-�������
		char *				 name;
		unsigned long  weight;
		char *         kind;
		char *				 partner;
		Currency 			 price;
	public:
		__fastcall Other(bool sl,unsigned long units,const char *nam,const char *kin,const char *prt,unsigned long w,Currency pr,const char *notes);
		__fastcall Other(TStream& s);
		__fastcall ~Other() { if (name) free(name); if (partner) free(partner); if (kind) free(kind); }
		X_TYPE 				 __fastcall GetType() const { return OTHER; }
		void 					 __fastcall ShowMe() const;
		unsigned short __fastcall GetAge() const { return age; }
		const char * 	 __fastcall GetName() const 	 { return name; }
		unsigned long  __fastcall GetWeight() const { return weight; }
		const char * 	 __fastcall GetKind() const 	 { return kind; }
		const char * 	 __fastcall GetPartner() const { return partner; }
		bool					 __fastcall IsSold() const { return sold; }
		Currency			 __fastcall GetPrice() const { return price; }
};

//---------------------------------------------------------------------------

class Otsev : public Trans
{
	private:
		unsigned short age;
		bool					 sold;	// �����������-�������
		unsigned long  weight;
		char *				 partner;
		char *         kind;
		Currency 			 price;
	public:
		__fastcall Otsev(bool sl,const char *partner,const char *kind,unsigned long w,Currency pr,const char *notes);
		__fastcall Otsev(TStream& s);
		__fastcall ~Otsev() { if (partner) free(partner); if (kind) free(kind); }
		X_TYPE 				 __fastcall GetType() const { return OTSEV; }
		void 					 __fastcall ShowMe() const;
		unsigned short __fastcall GetAge() const { return age; }
		unsigned long  __fastcall GetWeight() const { return weight; }
		const char * 	 __fastcall GetPartner() const { return partner; }
		bool					 __fastcall IsSold() const { return sold; }
		const char * 	 __fastcall GetKind() const { return kind; }
		Currency			 __fastcall GetPrice() const { return price; }
};

//---------------------------------------------------------------------------

#endif
