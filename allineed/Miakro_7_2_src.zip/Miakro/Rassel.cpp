#include <vcl.h>
#pragma hdrstop

#include "Params.h"
#include "Breed.h"
#include "Rassel.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"
TRasselForm *RasselForm;

//---------------------------------------------------------------------------

__fastcall TRasselForm::TRasselForm(TComponent* Owner) : TForm(Owner)
{
	cur_list = NULL;
}

//---------------------------------------------------------------------------

void __fastcall TRasselForm::Render(TListView *lw)
{
	cur_list = lw;
	StringList *sl = BreedForm->GetBreedList();
	TListItem *li;
	Rabbit *r;

	RasselList->Items->BeginUpdate();
	RasselList->Columns->BeginUpdate();
	RasselList->Items->Clear();
	for (int i = 0; i < list->Count; i++)
	{
		li = RasselList->Items->Add();
		li->Data = r = list->GetRabbit(i);
		li->Caption = r->GetFullName();
		li->SubItems->Add((int) r->GetGroup());
		li->SubItems->Add(ParamForm->GetBreedName(r->GetBreed(),AS_FULL));
		li->SubItems->Add(sl->GetString(r->GetBreed() * BREED_STEP + COLOR_BIAS));
	}
	RasselList->Columns->EndUpdate();
	RasselList->Items->EndUpdate();
}

//---------------------------------------------------------------------------

void __fastcall TRasselForm::RasselListDblClick(TObject *)
{
	TListItem *li = RasselList->Selected;
	if (!li) return;
	Rabbit *r = (Rabbit *) li->Data;
	r->Rassel(cur_list,true);
	list->Remove(r);
	if (list->Count == 1 && list->GetRabbit(0)->GetGroup() == 1)
		Close();
	else
		li->Delete();
}

//---------------------------------------------------------------------------

