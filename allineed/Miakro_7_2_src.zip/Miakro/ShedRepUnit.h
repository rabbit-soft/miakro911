//---------------------------------------------------------------------------
#ifndef ShedRepUnitH
#define ShedRepUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <QuickRpt.hpp>
//---------------------------------------------------------------------------
class TShedRepForm : public TForm
{
__published:	// IDE-managed Components
  TQuickRep *QuickRep1;
private:	// User declarations
public:		// User declarations
  __fastcall TShedRepForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TShedRepForm *ShedRepForm;
//---------------------------------------------------------------------------
#endif
