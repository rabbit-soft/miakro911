#ifndef RUSCTYPE_H
#define RUSCTYPE_H

// ������ �� 26.10.01

// =================================================================================

inline bool rusisspace(char x)
{
	return (x & 0x7f) == ' ' || x == '\t';
}

// =================================================================================

inline bool rusisdigit(char x)
{
	return x >= '0' && x <= '9';
}

// =================================================================================

inline bool isrus(char x)
{
	return (x & '�') == '�' || x == '�' || x == '�';
}

// =================================================================================

inline bool rusisupper(char x)
{
	return (x & '�') == '�' || x == '�';
}

// =================================================================================

inline bool rusislower(char x)
{
	return (x & '�') == '�' || x == '�';
}

// =================================================================================

inline char rustoupper(char x)
{
	return (x & '�') == '�' ? (x & ~' ') : x != '�' ? x : '�';
}

// =================================================================================

inline char rustolower(char x)
{
	return (x & '�') == '�' ? (x | ' ') : x != '�' ? x : '�';
}

// =================================================================================

inline char *russtrupr(char * const x)
{
	for (char *y = x; *y = rustoupper(*y); y++);
  return x;
}

// =================================================================================

inline char * const russtrlwr(char * const x)
{
	for (char *y = x; *y = rustolower(*y); y++);
  return x;
}

// =================================================================================

inline const char *stpblk(const char *x)
{
	for (; rusisspace(*x); x++);
	return x;
}

// =================================================================================

inline char *stpblk(char *x)
{
	for (; rusisspace(*x); x++);
	return x;
}

// =================================================================================

inline char *isrusword(char *x)
{
  char *p;
  char c = 0;
	for (p = x; isrus(*p) || *p == '-' && x != p && !c++ && *(p + 1); p++);
  return (p != x && *(p - 1) != '-' && (!*p || rusisspace(*p)) ? p : NULL);
}

// =================================================================================

inline char *strins(char * const dest,const char *src)
{
	char c = strlen(src);
	memmove(dest + c,dest,strlen(dest) + 1);
	return strncpy(dest,src,c);
}

// =================================================================================

int russtricmp(const char *a,const char *b)
{
	if (a == b) return 0;
	if (!a || !b) return 1;
	if (!stricmp(a,b)) return 0;
	char ax;
	int c;
	do
	{
		ax = rustolower(*a++);
		c = ax - rustolower(*b++);
	}
	while(!c && ax);
	return c;
}

// =================================================================================

int russtrnicmp(const char *a,const char *b,int count)
{
	if (a == b || !count) return 0;
	if (!a || !b) return 1;
	if (!strnicmp(a,b,count)) return 0;
	char ax,bx;
	int c = 0;
	while(count--)
	{
		ax = rustolower(*a++);
		bx = rustolower(*b++);
		c = ax - bx;
		if (c || !ax)
			break;
	}
	return c;
}

// =================================================================================

inline char *trim(char *s)
{
  static char buf[256];
  s = stpblk(s);
  if (!*s) return s;
  char *src = strcpy(buf,s);
	for (char *dest = src + strlen(src); --dest != src && rusisspace(*dest); *dest = '\0');
	return src;
}

// =================================================================================

inline bool isvowel(char x)
{
	return strchr("���������",x) != NULL;
}

// =================================================================================

inline bool isconsonant(char x)
{
	return !isvowel(x) && !strchr("���",x);
}

// =================================================================================

inline char *ruscap(char * const src)    // ���� �������� ������
{
	char *p = src;
	while (*(p = stpblk(p)))
		for (*p = rustoupper(*p); *++p && !rusisspace(*p); *p = rustolower(*p));
	return src;
}

// =================================================================================

inline int getrusword(const char * const src,int num) // ������� �������� n-�� �����, ���� ~0, ���� ������ ����� ���
{
	const char *p;
	for (p = src; *(p = stpblk(p)) && num; num--)
		while (!rusisspace(*p))
			if (!*p++) return ~0;
	return (int) ((unsigned long) p - (unsigned long) src);
}

// =================================================================================

inline char *if_strdup(const char *p)
{
	return p && *p ? strdup(p) : NULL;
}
// =================================================================================

inline char *free_deletter(char *dest)
{
	if (dest)
		free(dest);
	return NULL;
}

// =================================================================================

inline char *strdupper(char *dest,const char *src)
{
	free_deletter(dest);
	return if_strdup(src);
}

// =================================================================================

char *namer(const char *src)
{
	static char buf[256];
	*buf = 0;
	if (!src || !*src) return buf;
	char *p = buf;
	strcpy(buf,src);
	bool upper = true;
	bool space = false;
	do
	{
		if (strchr("\"\'()[]{} ",*p))
		{
			while (space && rusisspace(*p))
				strcpy(p,p + 1);
			upper = true;
			if (space = rusisspace(*p))
				continue;
		}
		*p = upper ? rustoupper(*p) : rustolower(*p);
		upper = space = false;
	}
	while (*p++);
	return buf;
}

// =================================================================================

bool test_email_address(const char *p)
{
	const char *px;
	if (!p || !*p || !(px = strchr(p,'@')) || px == p || !*++px || strchr(px,'@')) return false;
	const char *py = px + strlen(px);
	while (--py != px)
		if (*py == '.')
			break;
	if (py == px-- || strlen(py) < 3) return false;
	do
	{
		if (!isalpha(*p) && !isdigit(*p) && !strchr("._-",*p))
			return false;
	}
	while (++p != px);
	while (*p++) // �� @
		if (!isalpha(*p) && !isdigit(*p) && !strchr("._-",*p))
			return false;
	return true;
}

// =================================================================================

bool test_server_name(const char *p)
{
	const char *px;
	if (!p || !*p || !(px = strchr(p,'.')) || px == p || !*++px || !strchr(px,'.')) return false;
	const char *py = px + strlen(px);
	px--;
	while (--py != px)
		if (*py == '.')
			break;
	if (strlen(py) < 3) return false;
	do
	{
		if (!isalpha(*p) && !isdigit(*p) && !strchr("._-",*p))
			return false;
	}
	while (*++p);
	return true;
}
// =================================================================================

#endif // RUSCTYPE
