#include <vcl\vcl.h>
#pragma hdrstop

#include "Graph.h"
#include "Params.h"
#include "MoneyForm.h"
#include "ReportWin.h"
#include "Sorting.h"

//---------------------------------------------------------------------------

#pragma link "CSPIN"
#pragma resource "*.dfm"

TGraphForm *GraphForm;

static TColor colors[2] = { clYellow,clRed };
static double v_ratio,h_ratio;
static int cl_height,cl_width;
static int old_h[2];

const int addon = 2;
const int max_used_day = 300;
enum { X_NAME,X_ADDRESS,X_SEX,X_STATUS,X_AGE,X_WEIGHT,X_REASON,X_WORKER,X_NOTES };

//---------------------------------------------------------------------------

__fastcall TGraphForm::TGraphForm(TComponent* Owner): TForm(Owner)
{
	notify = 0;
	cl_width = Graph->ClientWidth;
	cl_height = Graph->ClientHeight;
	h_ratio = cl_width / (double) kill_size;
	v_ratio = (cl_height - addon * 2) / (double) (MAX_SKIN - 2);
	old_h[0] = old_h[1] = -1;
	memset(weights,0,sizeof(weights));
	LostList->Tag = (int) new Srt(LostList);
}

//---------------------------------------------------------------------------

__fastcall TGraphForm::~TGraphForm()
{
	notify++;
	ClearWeights();
	delete (Srt *) LostList->Tag;
}
//---------------------------------------------------------------------------

void __fastcall TGraphForm::TrackChange(TObject *Sender)
{
	if (notify) return;
	notify++;
	bool fem = ((TComponent *) Sender)->Tag != 0;
	unsigned char pos = ((TTrackBar *) Sender)->Position;
	Apply->Enabled = true;
	ManualAvto->ItemIndex = 0;
	ParamForm->Config.automode = false;
	if (fem)
	{
		FemaleLabel->Caption = pos;
		ParamForm->Config.killbrides = pos;
	}
	else
	{
		MaleLabel->Caption = pos;
		ParamForm->Config.killboys = pos;
	}
	Graph->Canvas->Pen->Color = colors[fem];
	Verticaller(fem);
	notify--;
}

//---------------------------------------------------------------------------

void __fastcall TGraphForm::SubRender(bool fem)
{
	TCanvas *canvas = Graph->Canvas;
	canvas->Pen->Width = 1;
	canvas->Pen->Style = psSolid;
	canvas->Pen->Color = colors[fem];
	canvas->Pen->Mode = pmCopy;
	int i,last_i,r;
	for (i = 0; i < kill_size; i++)
		if (r = values_array[fem][1][i])
			break;
	if (!r) return; // �����!
	int h;
	canvas->MoveTo(0,h = int (v_ratio * values_array[fem][0][last_i = i] / (double) r) + addon);
	canvas->LineTo(h_ratio * (last_i = i),h);
	while (r)
	{
		while (++i < kill_size && !(r = values_array[fem][1][i]));
		if (r)
			canvas->LineTo(h_ratio * i,h = int (v_ratio * values_array[fem][0][last_i = i] / (double) r) + addon);
	}
	if (last_i < kill_size)
		canvas->LineTo(cl_width,h);
	Verticaller(fem);
}

//---------------------------------------------------------------------------

void __fastcall TGraphForm::Render()
{
	TCanvas *canvas = Graph->Canvas;
	TRect Client;
	Client.Left = 0;
	Client.Top = 0;
	Client.Right = cl_width;
	Client.Bottom = cl_height;
	canvas->Brush->Color = clBlack;
	canvas->FillRect(Client);
	old_h[0] = old_h[1] = -1;
	SubRender(false);
	SubRender(true);
}

//---------------------------------------------------------------------------

void __fastcall TGraphForm::Verticaller(bool fem)
{
	TCanvas *canvas = Graph->Canvas;
	canvas->Pen->Width = 1;
	canvas->Pen->Style = psDot;
	canvas->Pen->Mode = pmXor;
	int pos = int (((fem ? FemaleTrack->Position : MaleTrack->Position) - min_kill) * h_ratio);
	int old = old_h[fem];
	if (pos == old) return;
	if (old >= 0)
	{
		canvas->MoveTo(old,0);
		canvas->LineTo(old,cl_height);
	}
	canvas->MoveTo(pos,0);
	canvas->LineTo(pos,cl_height);
	old_h[fem] = pos;
}

//---------------------------------------------------------------------------

void __fastcall TGraphForm::ApplyClick(TObject *)
{
	Apply->Enabled = false;
	if (ParamForm->Config.automode)
		AutoSet();
	ListRab *lr = PopulationWin->rabbits;
	Rabbit *r;
	bool gp;
	int more = 0,less = 0;
	for (int i = 0; i < lr->Count; i++)
	{
		r = lr->GetRabbit(i);
		gp = r->GetButcher();
		if (!r->AutoUpdateStatus(today))
			r->SetButcher(false);
		if (r->GetButcher() != gp)
		{
			if (gp)
				less += r->GetGroup();
			else
				more += r->GetGroup();
		}
	}
	AnsiString x("��������� ���");
	if (less || more)
	{
		PopulationWin->ListUpdated();
		if (less)
			x = AnsiString("������� �� ���� � ") + RabDecl(less,GENITIVE);
		if (more)
		{
			if (less)
				x += AnsiString('\n');
			else
				x = "";
			x += AnsiString("������� �� �������� ") + RabDecl(more,DATIVE);
		}
	}
	MessageBox(NULL,x.c_str(),"���������",MB_APPLMODAL|MB_ICONINFORMATION|MB_OK);
}

//---------------------------------------------------------------------------

void __fastcall TGraphForm::AutoSet() // ������������� ������
{
	AutoMod(false);
	AutoMod(true);
}

//---------------------------------------------------------------------------

void __fastcall TGraphForm::AutoMod(bool fem) // ������������� ������
{
	TTrackBar *t = fem ? FemaleTrack : MaleTrack;
	TLabel *l = fem ? FemaleLabel : MaleLabel;
	unsigned char *c = fem ? &ParamForm->Config.killbrides : &ParamForm->Config.killboys;
	for (int i = 0; i < kill_size; i++)
		if (!values_array[fem][1][i]) 			// ������ �������?
		{
			notify++;
			t->Position = i += min_kill;
			l->Caption = i;
			*c = i;
			notify--;
			Render();
			return;
		}
	unsigned long x,max = MAXLONG;
	int res;
	if (rand() % 20)
	{
		for (int i = 0; i < kill_size; i++)
			if ((x = int (values_array[fem][0][i] * 100 / (double) values_array[fem][1][i])) < max)
			{
				if (rand() % 3)
				{
					max = x;
					res = i;
				}
			}
	}
	else
		res = rand() % kill_size;
	notify++;
	t->Position = res += min_kill;
	l->Caption = res;
	*c = res;
	notify--;
	Render();
}

//---------------------------------------------------------------------------

void __fastcall TGraphForm::ManualAvtoClick(TObject *)
{
	if (notify) return;
	ParamForm->Config.automode = ManualAvto->ItemIndex;
	Apply->Enabled = true;
}

//---------------------------------------------------------------------------

void __fastcall TGraphForm::SetGpStatus()
{
	enum { B_MALE,B_FEMALE,B_OVERALL };
	int m = 0,f = 0;
	ListRab *lr = PopulationWin->rabbits;
	const Rabbit *r;
	for (int i = 9; i < lr->Count; i++)
	{
		r = lr->GetRabbit(i);
		if (r->GetButcher())
			switch (r->GetSex())
			{
				case MALE:
					m += r->GetGroup();
					break;
				case FEMALE:
					f += r->GetGroup();
			}
	}
	GpStatus->Panels->Items[B_MALE]->Text = AnsiString("��-������: ") + m;
	GpStatus->Panels->Items[B_FEMALE]->Text = AnsiString("��-�����: ") + f;
	GpStatus->Panels->Items[B_OVERALL]->Text = AnsiString("����� ��: ") + (m + f);
}

//---------------------------------------------------------------------------

bool __fastcall AverList::PassedFilter(const TListItem *li,const Rabbit *r)
{
	char x = GraphForm->Who->ItemIndex;
	return r->GetWeight() && (!x || x == 1 && li->Selected || x == 2 && li->Checked);
}

//---------------------------------------------------------------------------

void __fastcall TGraphForm::RenderWeights()
{
	ClearWeights();
	for (SEX sx = SEX_VOID; sx < MAX_SEX; ((char) sx)++)
	{
		weights[sx] = new AverList(sx);
		weights[sx]->Render();
	}
}

//---------------------------------------------------------------------------

void __fastcall TGraphForm::FormShow(TObject *)
{
	RenderWeights();
}

//---------------------------------------------------------------------------

Aver * __fastcall AverList::Find(unsigned short d) const
{
	Aver *av;
	for (int i = 0; i < Count; i++)
		if ((av = GetAver(i))->When() == d)
			return av;
	return NULL;
}

//---------------------------------------------------------------------------

void __fastcall AverList::More(unsigned short w,unsigned short d)
{
	Aver *av = Find(d);
	if (av)
		av->More(w);
	else
		Add(new Aver(w,d));
}

//---------------------------------------------------------------------------

void __fastcall AverList::Render() const
{
	GraphForm->WeightChart->Series[sex]->Clear();
	for (int i = 0; i < Count; GetAver(i++)->Render(sex));
}

//---------------------------------------------------------------------------

void __fastcall Aver::Render(SEX sx) const
{
	GraphForm->WeightChart->Series[sx]->AddXY(age,Get(),String(""),clTeeColor);
}

//---------------------------------------------------------------------------

__fastcall AverList::AverList(SEX sx) : TList()
{
	sex = sx;
	TListItems *lis = PopulationWin->RabbitList->Items;
	const WeightList *wl;
	const TListItem *li;
	const ListRab *lr = new ListRab;
	const Rabbit *r;
	More(0,0);
	for (int i = 0; i < lis->Count; i++)
	{
		li = lis->Item[i];
		r = (const Rabbit *) li->Data;
		if (r->GetSex() == sx && PassedFilter(li,r))
		{
			lr->Add((void *) r);
			wl = r->GetWeightList();
			for (int j = wl->Count; --j >= 0; More(wl->GetWeight(j),wl->GetDate(j) - r->GetAge(true)));
		}
	}
/*	unsigned short date;
	Aver *av;
	unsigned short nearest[2];
  for (int i = 1; i < Count; i++) // �� ���� Aver-��...
	{
		av = GetAver(i);
		date = av->When();
		for (int j = 0; j < lr->Count; j++)
		{
			r = lr->GetRabbit(j);
			if (!r->HasThisWeightDate(date + r->GetAge(true)))
				More(r->GetWeight(date),date);
		}
	} */
	delete lr;
}

//---------------------------------------------------------------------------

void __fastcall TGraphForm::ClearWeights()
{
	for (char i = 0; i < MAX_SEX; i++)
		if (weights[i])
		{
			delete weights[i];
			weights[i] = NULL;
		}
}

//---------------------------------------------------------------------------

__fastcall Aver::Aver(unsigned long w,unsigned short d)
{
	gross = w;
	num = 1;
	age = d;
}

//---------------------------------------------------------------------------

void __fastcall TGraphForm::WhoClick(TObject *)
{
	RenderWeights();
}

//---------------------------------------------------------------------------

void __fastcall TGraphForm::FormClose(TObject *,TCloseAction &Action)
{
	PopulationWin->SortFMenu->Checked = false;
}

//---------------------------------------------------------------------------

void __fastcall TGraphForm::RefreshClick(TObject *)
{
	RenderWeights();
}

//---------------------------------------------------------------------------

void __fastcall TGraphForm::PreviewClick(TObject *)
{
	PreviewOrPrint(false);
}

//---------------------------------------------------------------------------

void __fastcall TGraphForm::PrintClick(TObject *)
{
	PreviewOrPrint(true);
}

//---------------------------------------------------------------------------

void __fastcall TGraphForm::AddClick(TObject *)
{
	TListItem *li;
	Reason->Text = Reason->Text.Trim();
	Worker->Text = Worker->Text.Trim();
	if (!Reason->Text.IsEmpty())
	{
		if (ReasonsList->FindCaption(0,Reason->Text,false,true,false))
			MessageBox(NULL,"��������� ������� ��� ���� � ������!","��������",MB_APPLMODAL|MB_ICONINFORMATION|MB_OK);
		else
		{
			ReasonsList->Items->BeginUpdate();
			ReasonsList->Selected = NULL;
			li = ReasonsList->Items->Add();
			li->ImageIndex = -2;
			li->Caption = Reason->Text;
			li->SubItems->Add(ReasonRate->Value);
			Reason->Clear();
			ReasonsList->SortType = Listactns::stText;
			ReasonsList->SortType = Listactns::stNone;
			li->Selected = true;
			ReasonsList->Items->EndUpdate();
		}
	}
	if (!Worker->Text.IsEmpty())
	{
		if (Workers->FindCaption(0,Worker->Text,false,true,false))
			MessageBox(NULL,"��������� �������� ��� ���� � ������!","��������",MB_APPLMODAL|MB_ICONINFORMATION|MB_OK);
		else
		{
			Workers->Items->BeginUpdate();
			Workers->Selected = NULL;
			li = Workers->Items->Add();
			li->ImageIndex = -2;
			li->Caption = Worker->Text;
			li->SubItems->Add(WorkerRate->Value);
			Worker->Clear();
			Workers->SortType = Listactns::stText;
			Workers->SortType = Listactns::stNone;
			li->Selected = true;
			Workers->Items->EndUpdate();
		}
	}
}

//---------------------------------------------------------------------------

void __fastcall TGraphForm::PreviewOrPrint(bool print)
{
	AnsiString head("�������� ��������");
	AnsiString foot("����� ");
	ReportForm->reports->Prepare(Q_LOSS,LostList,head,foot + LostList->Items->Count + '.');
	if (print)
		ReportForm->reports->Print();
	else
		ReportForm->reports->PreView();
}

//---------------------------------------------------------------------------

TStream& __fastcall operator >> (TStream& s,TGraphForm *gf)
{
	s >> gf->ReasonsList;
  s >> gf->Workers;
  s >> gf->LostList;
	int i = gf->LostList->Items->Count;
	TListItem *li;
	int date = today - ParamForm->Config.lost_days;
	while (--i >= 0)
	{
		li = gf->LostList->Items->Item[i];
		if ((int) StrToDate(li->Caption) < date)
			delete li;
	}
	return s;
}

//---------------------------------------------------------------------------

TStream& __fastcall operator << (TStream& s,TGraphForm *gf)
{
	s << gf->ReasonsList << gf->Workers << gf->LostList;
	return s;
}

//---------------------------------------------------------------------------

void __fastcall TGraphForm::LostRabbit(const Rabbit *r)
{
	TListItem *li = LostList->Items->Add();
	li->ImageIndex = -2;
	li->Checked = true;
	li->Caption = DateToStr(Now());
	AnsiString n(r->GetFullName());
	if (r->GetGroup() > 1)
		n = n + " [" + (int) r->GetGroup() + ']';
	li->SubItems->Add(n);
	li->SubItems->Add(r->GetAddressName());
	li->SubItems->Add(r->GetSexChar());
	li->SubItems->Add(ParamForm->GetStatusName(r,AS_SHORT));
	li->SubItems->Add((int) r->GetAge());
	li->SubItems->Add((int) r->GetWeight());
	li->SubItems->Add(' ');
	li->SubItems->Add(' ');
	if (r->GetNotes())
		li->SubItems->Add(r->GetNotes());
	((Srt *) LostList->Tag)->Process();
}

//---------------------------------------------------------------------------


void __fastcall TGraphForm::LostListDblClick(TObject *)
{
	TListItem *li = LostList->Selected;
	if (!li) return;
	const TListItem *worker,*reason = ReasonsList->Selected;
	if (reason)
	{
		if (li->SubItems->Count <= X_REASON)
			li->SubItems->Add(reason->Caption);
		else
			li->SubItems->Strings[X_REASON] = reason->Caption;
		li->Checked = false;
	}
	if (worker = Workers->Selected)
	{
		while	(li->SubItems->Count <= X_WORKER)
			li->SubItems->Add(' ');
		li->SubItems->Strings[X_WORKER] = worker->Caption;
		if (reason)
			worker->SubItems->Strings[0] = worker->SubItems->Strings[0].ToInt() + reason->SubItems->Strings[0].ToInt();
		li->Checked = false;
	}
	li->Caption = DateToStr(When->Date);
}

//---------------------------------------------------------------------------

void __fastcall TGraphForm::DeleteClick(TObject *)
{
	TListItem *li = LostList->Selected;
	if (!li || MessageBox(NULL,"������������� ������� ���������� ������?","������",MB_APPLMODAL|MB_ICONQUESTION|MB_YESNO|MB_DEFBUTTON2) != IDYES) return;
	TItemStates Is;
	Is << isSelected;
	TList *d = new TList;
	do
		d->Add(li);
	while (li = LostList->GetNextItem(li,sdAll,Is));
	LostList->Items->BeginUpdate();
	for (int i = d->Count; --i >= 0; delete (TListItem *) d->Items[i]);
	LostList->Items->EndUpdate();
	delete d;
}

//---------------------------------------------------------------------------

void __fastcall TGraphForm::ReasonsListDblClick(TObject *)
{
	TListItem *li = ReasonsList->Selected;
	if (!li) return;
	Reason->Text = li->Caption;
	ReasonRate->Value = li->SubItems->Strings[0].ToInt();
	delete li;
}

//---------------------------------------------------------------------------

void __fastcall TGraphForm::WorkersDblClick(TObject *)
{
	TListItem *li = Workers->Selected;
	if (!li) return;
	Worker->Text = li->Caption;
	WorkerRate->Value = li->SubItems->Strings[0].ToInt();
	delete li;
}

//---------------------------------------------------------------------------

void __fastcall TGraphForm::DeleteReasonClick(TObject *)
{
	TListItem *li = ReasonsList->Selected;
	if (!li || MessageBox(NULL,"������������� ������� ���������� ������� ��������?","������",MB_APPLMODAL|MB_ICONQUESTION|MB_YESNO|MB_DEFBUTTON2) != IDYES) return;
	TItemStates Is;
	Is << isSelected;
	TList *d = new TList;
	do
		d->Add(li);
	while (li = ReasonsList->GetNextItem(li,sdAll,Is));
	ReasonsList->Items->BeginUpdate();
	for (int i = d->Count; --i >= 0; delete (TListItem *) d->Items[i]);
	ReasonsList->Items->EndUpdate();
	delete d;
}

//---------------------------------------------------------------------------

void __fastcall TGraphForm::DeleteWorkerClick(TObject *)
{
	TListItem *li = Workers->Selected;
	if (!li || MessageBox(NULL,"������������� ������� ���������� ����������?","������",MB_APPLMODAL|MB_ICONQUESTION|MB_YESNO|MB_DEFBUTTON2) != IDYES) return;
	TItemStates Is;
	Is << isSelected;
	TList *d = new TList;
	do
		d->Add(li);
	while (li = Workers->GetNextItem(li,sdAll,Is));
	Workers->Items->BeginUpdate();
	for (int i = d->Count; --i >= 0; delete (TListItem *) d->Items[i]);
	Workers->Items->EndUpdate();
	delete d;
}

//---------------------------------------------------------------------------

void __fastcall TGraphForm::LostListColumnClick(TObject *Sender,TListColumn *Column)
{
	((Srt *) ((TComponent *) Sender)->Tag)->Process(Column);
}

//---------------------------------------------------------------------------

