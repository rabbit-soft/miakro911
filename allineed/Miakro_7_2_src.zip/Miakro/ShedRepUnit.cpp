//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "ShedRepUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TShedRepForm *ShedRepForm;
//---------------------------------------------------------------------------
__fastcall TShedRepForm::TShedRepForm(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------
