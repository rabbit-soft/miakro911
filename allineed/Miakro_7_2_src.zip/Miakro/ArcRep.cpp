#include <vcl.h>
#pragma hdrstop

#include "ArcRep.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"

TArcRepForm *ArcRepForm;

//---------------------------------------------------------------------------

__fastcall TArcRepForm::TArcRepForm(TComponent* Owner) : TForm(Owner)
{
}

//---------------------------------------------------------------------------

