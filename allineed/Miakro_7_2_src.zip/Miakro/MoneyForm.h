#ifndef MoneyFormH
#define MoneyFormH

//---------------------------------------------------------------------------

#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ComCtrls.hpp>

#include "Rabbit.h"
#include <vcl\Menus.hpp>
#include <vcl\ExtCtrls.hpp>
#include "CSPIN.h"

enum X_TYPE
{
	MEAT_SOLD, // ��������� �����      | ���������� ����	 | 1				|
	SKIN_SOLD, // ��������� ������     | ���������� ������ | 1				|
	RABBITS, 	 // �������/������� �����| ������� ����� 		 | 0				|BodyList
	FEED,      // �����                | ������� ������      1
	OTHER,     // ������               | ������            | 1				|
	MEAT,      // �������  �����       | ���������� ����	 | 					|
	SKIN,    	 // ����������� ������   | ������� ������		 | 					|
  USED_FEED, // �����������
  OTSEV,     // �����
	MAX_XTYPE
};

const int min_kill = 110; // ����������� ���� �����
const int max_kill = 201; // ������������ ���� ����� + 1
const int kill_size = max_kill - min_kill;

enum SKIN_TYPE { SK_UNKNOWN,LUXURY,I,II,III,IV,MAX_SKIN };
enum { ST_OVERALL,ST_SELECTED,ST_DEBET,ST_CREDIT,ST_PROFIT };
extern unsigned long values_array[2][2][kill_size]; // ����/����� ��������

class TransList;
class Trans;

//---------------------------------------------------------------------------

class TTransForm : public TForm
{
__published:
	TPageControl *TransPages;
	TTabSheet *RabPage;
	TTabSheet *FeedPage;
	TTabSheet *OtherPage;
	TTabSheet *ButcherPage;
	TListView *SellMeetList;
	TTabSheet *SkinPage;
	TTabSheet *LeftMeet;
	TListView *RabbitsSellBuyList;
	TTabSheet *SkinLeftPage;
	TStatusBar *TransStatus;
	TListView *BodyList;
	TListView *SkinList;
	TListView *SkinSoldList;
	TListView *OtherList;
	TListView *FeedList;
	TMainMenu *MainMenu1;
	TMenuItem *MoneyMenu;
	TMenuItem *DelRecords;
	TMenuItem *N2;
  TMenuItem *Preview;
	TGroupBox *GroupBox1;
	TLabel *Label4;
	TLabel *Label5;
	TLabel *Label6;
	TLabel *Label7;
	TLabel *Label8;
	TLabel *Label3;
	TLabel *Label2;
	TLabel *Label1;
	TButton *SkinBought;
	TEdit *Price_4;
	TEdit *LuxPrice;
	TComboBox *SkinBuyers;
	TComboBox *SkinSort;
	TEdit *Price_3;
	TEdit *Price_1;
	TEdit *Price_2;
	TGroupBox *GroupBox2;
	TLabel *Label11;
	TLabel *Label12;
	TEdit *Brutto;
	TEdit *Netto;
	TButton *PutWeights;
	TLabel *Label9;
	TComboBox *BodyBuyers;
	TLabel *Label10;
	TEdit *PricePerKilo;
	TButton *MeetBought;
	TGroupBox *GroupBox3;
	TButton *OtherDone;
	TComboBox *OtherPartner;
	TLabel *Label15;
	TEdit *OtherPrice;
	TLabel *Label14;
	TRadioGroup *SellBuy;
	TEdit *OtherNum;
	TLabel *Label13;
	TUpDown *OtherNunUD;
	TComboBox *OtherKind;
	TLabel *Label25;
	TLabel *Lx;
	TComboBox *OtherProduct;
	TGroupBox *GroupBox4;
	TLabel *Label21;
	TComboBox *RabbitPartner;
	TEdit *RabbitsNum;
	TUpDown *RabbitsNumUD;
	TLabel *Label22;
	TLabel *Label23;
	TEdit *RabbitPrice;
	TButton *RabbitsSell;
	TGroupBox *GroupBox5;
	TLabel *Label18;
	TComboBox *FeedType;
	TLabel *Label24;
	TComboBox *Kind;
	TLabel *Label16;
	TLabel *Label17;
	TLabel *Label19;
	TComboBox *FeedPartner;
	TButton *FeedBuy;
	TEdit *FeedPrice;
	TEdit *FeedWeight;
	TUpDown *FeedWeightUD;
	TGroupBox *GroupBox6;
	TLabel *Label20;
	TButton *Refresh;
	TEdit *Notes;
	TButton *TakeFomRabList;
	TLabel *GrossPrice;
	TEdit *Gross;
  TDateTimePicker *TransDate;
  TDateTimePicker *From;
  TDateTimePicker *Till;
	TLabel *Label26;
	TLabel *Label27;
	TButton *TakeFromYoungList;
	TCheckBox *MothersWithBabies;
  TMenuItem *Print;
  TTabSheet *FeedSpentPage;
  TTabSheet *OtsevPage;
  TListView *UsedFeedList;
  TListView *OtsevList;
  TGroupBox *GroupBox7;
  TLabel *Label28;
  TComboBox *UsedFeedType;
  TLabel *Label29;
  TComboBox *UsedFeedSpec;
  TButton *UsedFeedDone;
  TCSpinEdit *UsedFeedWeight;
  TLabel *Label30;
  TGroupBox *GroupBox8;
  TLabel *Label31;
  TComboBox *OtsevBuyer;
  TLabel *Label32;
  TEdit *OtsevPricePerKilo;
  TButton *OtsevSold;
  TLabel *Label33;
  TCSpinEdit *OtsevWeight;
  TButton *GetOtsev;
  TMenuItem *N1;
  TMenuItem *FeedGraphWindow;
  TComboBox *Spec;
  TLabel *Label34;
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall FormShow(TObject *Sender);
	void __fastcall TransPagesChange(TObject *Sender);
	void __fastcall RefreshClick(TObject *Sender);
	void __fastcall FromChange(TObject *Sender);
	void __fastcall SkinBoughtClick(TObject *Sender);
	void __fastcall SkinSortChange(TObject *Sender);
	void __fastcall MeetBoughtClick(TObject *Sender);
	void __fastcall PutWeightsClick(TObject *Sender);
	void __fastcall DelRecordsClick(TObject *Sender);
	void __fastcall FeedBuyClick(TObject *Sender);
	void __fastcall OtherDoneClick(TObject *Sender);
	void __fastcall PreviewClick(TObject *Sender);
	void __fastcall ListChange(TObject *Sender, TListItem *Item,TItemChange Change);
	void __fastcall ListChanging(TObject *Sender,TListItem *Item,TItemChange Change, bool &AllowChange);
	void __fastcall ColumnClick(TObject *Sender, TListColumn *Column);
	void __fastcall SortMe(int index);
	void __fastcall TakeFomRabListClick(TObject *Sender);
	void __fastcall RabbitsSellClick(TObject *Sender);
	void __fastcall TakeFromYoungListClick(TObject *Sender);
	void __fastcall MothersWithBabiesClick(TObject *Sender);
  void __fastcall PrintClick(TObject *Sender);
  void __fastcall UsedFeedDoneClick(TObject *Sender);
  void __fastcall GetOtsevClick(TObject *Sender);
  void __fastcall OtsevSoldClick(TObject *Sender);
  void __fastcall FeedGraphWindowClick(TObject *Sender);
  void __fastcall ListDblClick(TObject *Sender);
private:
	static TEdit *SkinPrc[MAX_SKIN];
	bool take_youngs;
	void __fastcall ForcedRender();
	void __fastcall DelOrDisappear(Rabbit *rx,bool take_youngs);
  void __fastcall PreviewOrPrint(bool print);
  void __fastcall CalcSum(int max,int extracol,int morecol,int page);
  void __fastcall FillUsedFeedSpecCombo();
public:
	char notify;
	TransList *translist;
	bool needs_refresh[MAX_XTYPE];
						 __fastcall TTransForm(TComponent* Owner);
						 __fastcall ~TTransForm();
	void       __fastcall Render();
	void 			 __fastcall RefreshStatus();
	void       __fastcall RabbitWasBought(const Rabbit *r,const Currency& Price);
	void       __fastcall RabbitWasButchered(const Rabbit *r);
	Currency 	 __fastcall Str2Curr(AnsiString s);
	AnsiString __fastcall Curr2Str(Currency c);
  int        __fastcall CalcGrossFeedWeight(Trans *sample,TransList *processed);
  int        __fastcall CalcUsedFeedWeight(Trans *sample);
  void       __fastcall FillSpecCombo();
	friend TStream& operator << (TStream& s,TTransForm *tf); // ������ � ������ ����������
	friend TStream& operator >> (TStream& s,TTransForm *tf);
	friend int __stdcall Sorter(long a,long b,long col);
};

//---------------------------------------------------------------------------

extern TTransForm *TransForm;

//---------------------------------------------------------------------------

#endif

