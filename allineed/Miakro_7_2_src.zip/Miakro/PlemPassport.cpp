
#include <vcl\vcl.h>
#pragma hdrstop

#include "PlemPassport.h"
#include "Params.h"
#include "Bone.h"

//----------------------------------------------------------------------------

#pragma resource "*.dfm"
TPlemReport *PlemReport;

Rabbit *TPlemReport::cookie;

//----------------------------------------------------------------------------

__fastcall TPlemReport::TPlemReport(TComponent* Owner) : TQuickRep(Owner)
{
  Parenter *p;
  GrandParent *f,*m;

  p = new Parenter(M_No,M_Class,M_Name,M_Age,MX_Weight,C_M,N_M,A_M,W_M,M_Body,M_Hair,M_Color,M_Weight,M_LB,M_LH,M_LC,M_LW,M_Classify);
  m = new GrandParent(MM_No,MM_Class,MM_Name,MX_Age,MM_Weight,C_MM,N_MM,A_MM,W_MM);
  f = new GrandParent(MF_No,MF_Class,MF_Name,MF_Age,MF_Weight,C_MF,N_MF,A_MF,W_MF);
  mother = new SvidRab(p,f,m);
  p = new Parenter(F_No,F_Class,F_Name,F_Age,FX_Weight,C_F,N_F,A_F,W_F,F_Body,F_Hair,F_Color,F_Weight,F_LB,F_LH,F_LC,F_LW,F_Classify);
  m = new GrandParent(FM_No,FM_Class,FM_Name,FM_Age,FM_Weight,C_FM,N_FM,A_FM,W_FM);
  f = new GrandParent(FF_No,FF_Class,FF_Name,FF_Age,FF_Weight,C_FF,N_FF,A_FF,W_FF);
  father = new SvidRab(p,f,m);
}

//----------------------------------------------------------------------------

__fastcall TPlemReport::~TPlemReport()
{
	delete father;
	delete mother;
}

//----------------------------------------------------------------------------

void __fastcall TPlemReport::PlemReportBeforePrint(TCustomQuickRep *Sender,bool &PrintReport)
{
  HeadLabel->Caption = ParamForm->SvidHead->Text;
  SvidLabel->Caption = String("��������� ������������� �") + ParamForm->NewConf.next_svid->Value;
  String Sex,A;
  int x;
  OverallRab->Enabled = false;
  OverallRabbits->Enabled = false;
  switch (TPlemReport::cookie->GetSex())
  {
    case MALE:
      Sex = "�����-���������";
      break;
    case FEMALE:
      Sex = "���������-�����������";
      OverallRab->Enabled = true;
      OverallRabbits->Enabled = true;
      OverallRabbits->Caption = (int) cookie->GetOverallBabies();
      break;
    default:
      Sex = "����������-���������";
  }
  if (TPlemReport::cookie->CalcBon() != B_UNKNOWN)
    RabLabel->Caption = Sex + " ������ " + cookie->GetClassName(AS_FULL);
  else
    RabLabel->Caption = Sex + " (����� �� ��������)";
  Breed->Caption = String("������: ") + ParamForm->GetBreedName(cookie->GetBreed(),AS_FULL);
  if (x = cookie->GetOkrolNum())
    A = String("����") + (cookie->GetSex() == FEMALE ? "���" : "��") + " �� " + x + "-�� ������";
  else
  {
    A = String("���������� ����� ������, �� �������� ����");
    if (cookie->GetSex() == FEMALE)
      A += String("��� ������ ") + (cookie->GetStatus() >= char(PERVO) ? "���������" : "�����");
    else
      A += String("�� ������ ������");
  }
  OkrolNum->Caption = A;
  bool b = ParamForm->Config.double_sur;
  ParamForm->Config.double_sur = true;
  char buf[100];
  ostrstream s(buf,sizeof(buf));
  cookie->NameAndSurname(s);
  s << ends;
  Name->Caption = buf;
  ParamForm->Config.double_sur = b;
  Address->Caption = cookie->GetAddressName(true,true);
  BirthPlace->Caption = ParamForm->GetZoneName(cookie->GetZone(),AS_FULL,true);
  TDateTime Dt(int(cookie->GetAge(true)));
  BirthDay->Caption = DateToStr(Dt);
  x = cookie->GetAge();
  Age->Caption = String(x) + " �" + day_decl[Decler(x)];
  x = cookie->GetWeight();
  if (x)
  {
    String A(String(x) + " �.");
    int y = cookie->GetWeightList()->GetDate(0);
    if (y)
    {
      Dt = y;
      y -= cookie->GetAge(true);
      A += String(" (") + DateToStr(Dt) + ", ������� " + y + " �" + day_decl[Decler(y)] + ')';
    }
    Weight->Caption = A;
  }
  else
    Weight->Caption = '-';
  B_Weight->Caption = bon_names[cookie->GetBonWeight()];
  Body->Caption = bon_names[cookie->GetBonBody()];
  Thickness->Caption = bon_names[cookie->GetBonHair()];
  Color->Caption = bon_names[cookie->GetBonColor()];
  A = "";
  for (x = 0; x < cookie->GetGenesis()->Count; A += String(int(cookie->GetGenesis()->Items[x++])))
    if (x)
      A += String(", ");
  Genesis->Caption = A;
  bool dead;
  Rabbit *gf,*gm,*r = cookie->FindMyParent(MALE,dead);
  gf = r ? r->FindMyParent(MALE,dead) : NULL;
  gm = r ? r->FindMyParent(FEMALE,dead) : NULL;
  father->Render(r,gf,gm);
  r = cookie->FindMyParent(FEMALE,dead);
  gf = r ? r->FindMyParent(MALE,dead) : NULL;
  gm = r ? r->FindMyParent(FEMALE,dead) : NULL;
  mother->Render(r,gf,gm);
  ParamForm->NewConf.Render();
  Memo->Lines->Assign(ParamForm->Remarks->Lines);
}

//---------------------------------------------------------------------------

void __fastcall GrandParent::Render(Rabbit *r)
{
  no->Enabled = !r;
  x_class->Enabled = r != NULL;
  name->Enabled = r != NULL;
  age->Enabled = r != NULL;
  weight->Enabled = r != NULL;
  l_class->Enabled = r != NULL;
  l_name->Enabled = r != NULL;
  l_age->Enabled = r != NULL;
  l_weight->Enabled = r != NULL;
  if (r)
  {
    x_class->Caption = r->GetClassName(AS_FULL);
    name->Caption = r->GetFullName();
    age->Caption = (int) r->GetAge();
    int x = r->GetWeight();
    if (x)
      weight->Caption = x;
    else
      weight->Caption = '-';
  }
}

//---------------------------------------------------------------------------

void __fastcall Parenter::Render(Rabbit *r)
{
  GrandParent::Render(r);
  classify->Enabled = r != NULL;
  b_weight->Enabled = r != NULL;
  b_body->Enabled = r != NULL;
  b_hair->Enabled = r != NULL;
  b_color->Enabled = r != NULL;
  l_weight->Enabled = r != NULL;
  l_body->Enabled = r != NULL;
  l_hair->Enabled = r != NULL;
  l_color->Enabled = r != NULL;
  if (r)
  {
    b_weight->Caption = bon_names[r->GetBonWeight()];
    b_body->Caption = bon_names[r->GetBonBody()];
    b_hair->Caption = bon_names[r->GetBonHair()];
    b_color->Caption = bon_names[r->GetBonColor()];
  }
}
