#ifndef ArchiveH
#define ArchiveH

//---------------------------------------------------------------------------

#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>

#include "Zoo.h"
#include <Menus.hpp>

class ArcPlan;
enum Y_TYPE { ZOO_ARC,RAB_ARC,MAX_A_PAGES };

//---------------------------------------------------------------------------

class ArcWork
{
	private:
		StringList *cols;
	public:
    char notify;
    Y_TYPE page;
		__fastcall ArcWork(TListItem *li);
		__fastcall ArcWork(TStream& s);
		__fastcall ~ArcWork();
		void __fastcall Render(TListItem *li,const char *date);
		friend TStream& __fastcall operator << (TStream& s,ArcWork *aw);
		friend ArcPlan;
};

//---------------------------------------------------------------------------

class ArcPlan
{
	private:
		unsigned short date;
		TList					*works; // ������ ArcWork
	public:
		__fastcall ArcPlan();
		__fastcall ArcPlan(TStream& s);
		__fastcall ~ArcPlan();
		unsigned short 	__fastcall GetDate() const { return date; }
		TList * 				__fastcall GetWorks() const { return works; }
		void 						__fastcall Render();
		ArcWork *				__fastcall AddJob(TListItem *li) { ArcWork *aw; works->Add(aw = new ArcWork(li)); return aw; }
		friend TStream& __fastcall operator << (TStream& s,ArcPlan *ap);
};

//---------------------------------------------------------------------------

class TArchiveForm : public TForm
{
__published:
	TStatusBar *StatusBar1;
	TMainMenu *MainMenu1;
	TMenuItem *Print;
	TMenuItem *Preview;
	TMenuItem *PrintIt;
	TPopupMenu *ArcPopup;
	TMenuItem *Delete;
  TPageControl *ArchivePages;
  TTabSheet *PlanPage;
  TGroupBox *GroupBox1;
  TListView *PlansList;
  TGroupBox *GroupBox2;
  TLabel *Label4;
  TListView *Archives;
  TGroupBox *GroupBox3;
  TLabel *Label1;
  TLabel *Label2;
  TLabel *Label3;
  TDateTimePicker *From;
  TDateTimePicker *Till;
  TEdit *Name;
  TButton *Refresh;
  TTabSheet *RabPage;
  TListView *RabbitList;
  TGroupBox *GroupBox4;
  TEdit *NewNotes;
	void __fastcall FormShow(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall RefreshClick(TObject *Sender);
	void __fastcall ArchivesDblClick(TObject *Sender);
	void __fastcall PlansListColumnClick(TObject *Sender,TListColumn *Column);
	void __fastcall PreviewClick(TObject *Sender);
	void __fastcall PrintItClick(TObject *Sender);
	void __fastcall DeleteClick(TObject *Sender);
  void __fastcall ArchivePagesChange(TObject *Sender);
  void __fastcall RabbitListChange(TObject *Sender,TListItem *Item,TItemChange Change);
  void __fastcall NewNotesKeyUp(TObject *Sender,WORD &Key,TShiftState Shift);
private:
	bool needs_refresh;
	TListView *listviews[MAX_A_PAGES];
	Y_TYPE page;
	ArcPlan * __fastcall FindArcPlan(unsigned short date);
	int 			__fastcall OverallItems();
	void 			__fastcall PreviewOrPrint(bool print);
public:
	int this_date;
	char notify;
	TList   *plans; // ������ �������� ArcPlan
	ListRab *dead;
	__fastcall TArchiveForm(TComponent* Owner);
	__fastcall ~TArchiveForm();
	void __fastcall RenderDead();
	void __fastcall AddJob(TListItem *li);
	void __fastcall Render();
  void __fastcall ClearAll();
	friend TStream& __fastcall operator >> (TStream& s, TArchiveForm *af);
	friend TStream& __fastcall operator << (TStream& s, TArchiveForm *af);
};

//---------------------------------------------------------------------------

extern PACKAGE TArchiveForm *ArchiveForm;

//---------------------------------------------------------------------------

#endif

