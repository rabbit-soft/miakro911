#ifndef FilterH
#define FilterH

//---------------------------------------------------------------------------

#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ExtCtrls.hpp>

#include "Miakro.h"
#include "Rabbit.h"
#include <ComCtrls.hpp>
#include "CSPIN.h"

enum { NO_RESET,RESET_RAB,RESET_BUILD };
//               1            2               3             4                5              6               7
enum CTRLS { ALL_ENABLED,MALES_ENABLED,FEMALES_ENABLED,NOSEX_ENABLED,BOYS_ENABLED,CANDIDATES_ENABLED,FATHERS_ENABLED,
//     8            9               10              11        12    			  13     		14   15    16     		17
	GIRLS_ENABLED,BRIDES_ENABLED,PERVO_ENABLED,MOTHERS_ENABLED,FEMALES_BAD,MALES_BAD,SUKROL,KUKU,FAMILY,WORKS_ENABLED,
//		18			19      	20        			21            22          	23     			24         25
	FROM_AGE,TILL_AGE,USE_FROM_WEIGHT,FROM_WEIGHT,USE_TILL_WEIGHT,TILL_WEIGHT,FROM_SUKROL,TILL_SUKROL,
	B_ALL_ENABLED,B_FREE,B_BUSY,B_SELRABBITS,B_MALE,B_FEMALE,B_OTHER,B_NESTS,B_HEATERS,
	MAX_FCONTROLS };

typedef Set<CTRLS,ALL_ENABLED,MAX_FCONTROLS - 1> CtrlSet;
extern CtrlSet RabSet,BuildSet,InvertedBoxes;

#define CONTROLS_1x  25
#define CONTROLS_2x  23
#define CONTROLS_2_2 24
#define CONTROLS_3_0 32
#define CONTROLS_4_3 34

//---------------------------------------------------------------------------

class Filter
{
	private:
		bool *modify;
		int values[MAX_FCONTROLS];
	public:
					__fastcall Filter(bool *mo);
					__fastcall Filter(bool *mod,TStream& s);
					__fastcall Filter::~Filter();
		void  __stdcall ScanControls(TComponent *obj,bool set_controls = false,bool reset = false,CtrlSet *ctrl = NULL); // ����������� ��������� �������������� ��� ����������
		void	__fastcall SetValue(CTRLS index,int value,bool mod = true) { *modify = mod; values[index] = value; }
		int   __fastcall GetValue(CTRLS index) const { return values[index]; }
		void	__fastcall Render();
		bool	__fastcall Passed(const Rabbit *r) const;
		bool 	__fastcall BuildPassed(const BuildListRecord *blr) const;
		friend TStream& operator <<(TStream& s,Filter *f) { s.WriteBuffer(&f->values,sizeof(f->values)); return s; }
};

//---------------------------------------------------------------------------

class FilterList : public TList
{
	private:
	public:
		bool modified;
		int look_at;    										// ������ ��������� ������� � ������
							__fastcall FilterList();
							__fastcall ~FilterList();
		Filter *	__fastcall GetFilter(int i) { return (Filter *) Items[i]; }
		Filter *	__fastcall Acquire() { return GetFilter(look_at); }
		void 			__fastcall Erase();
		void 			__fastcall Clear();
		friend TStream& operator >> (TStream& s,FilterList *fl);
		friend TStream& operator << (TStream& s,FilterList *fl);
};

//---------------------------------------------------------------------------

class TFilterForm : public TForm
{
__published:
	TGroupBox *RabFilter;
	TButton *Ok;
	TCheckBox *MainSwitch;
	TGroupBox *Sex;
	TCheckBox *Males;
	TCheckBox *Females;
	TCheckBox *Sexless;
	TGroupBox *GroupBox2;
	TCheckBox *Boy;
	TCheckBox *Candidate;
	TCheckBox *Father;
	TRadioGroup *MaleCrap;
	TComboBox *RabFilterName;
	TGroupBox *GroupBox3;
	TCheckBox *Girl;
	TCheckBox *Bride;
	TCheckBox *Pervo;
	TCheckBox *Mother;
	TRadioGroup *FemaleCrap;
	TRadioGroup *Sukrol;
	TRadioGroup *Kuku;
	TRadioGroup *Family;
	TButton *RabFilterReset;
	TGroupBox *BuildFilter;
	TCheckBox *SwitchBuilds;
	TCheckBox *Free;
	TCheckBox *Busy;
	TCheckBox *Male;
	TCheckBox *Female;
	TCheckBox *Other;
	TButton *OkBuild;
	TButton *ResetBuild;
	TRadioGroup *LookAtRab;
	TRadioGroup *FilterZooWorks;
	TGroupBox *GroupBox1;
	TDateTimePicker *FromAge;
	TLabel *Label1;
	TDateTimePicker *TillAge;
	TLabel *Label2;
	TGroupBox *GroupBox4;
	TCSpinEdit *MinWeight;
	TCSpinEdit *MaxWeight;
	TCheckBox *UseFromWeight;
	TCheckBox *UseTillWeight;
	TGroupBox *GroupBox5;
	TLabel *Label3;
	TLabel *Label4;
	TDateTimePicker *FromSukrol;
	TDateTimePicker *TillSukrol;
  TRadioGroup *Heaters;
  TRadioGroup *Nests;
	void __fastcall MainSwitchClick(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall OkClick(TObject *Sender);
	void __fastcall RabFilterResetClick(TObject *Sender);
	void __fastcall ResetBuildClick(TObject *Sender);
	void __fastcall OkBuildClick(TObject *Sender);
	void __fastcall RabFilterNameKeyDown(TObject *Sender, WORD &Key,TShiftState Shift);
	void __fastcall RabFilterNameChange(TObject *Sender);
private:
public:
	char notify;
	FilterList *filters;
	__fastcall TFilterForm(TComponent* Owner);
	__fastcall ~TFilterForm() { notify++; delete filters; }
	void __fastcall Clear() { filters->Clear(); }
	bool __fastcall Try(const Rabbit *r) { return filters->Acquire()->Passed(r); }
	bool __fastcall Try(const BuildListRecord *blr) { return filters->Acquire()->BuildPassed(blr); }
	bool __fastcall BuildsDependOnRabbits() const { return filters->Acquire()->GetValue(B_SELRABBITS) != NULL; }
	friend TStream& operator << (TStream& s,TFilterForm *ff); // ������ � ������ ����������
	friend TStream& operator >> (TStream& s,TFilterForm *ff);
};

//---------------------------------------------------------------------------

extern TFilterForm *FilterForm;

//---------------------------------------------------------------------------

#endif
