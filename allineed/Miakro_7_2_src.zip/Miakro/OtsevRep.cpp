#include <vcl.h>
#pragma hdrstop

#include "OtsevRep.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"

TOtsevRepForm *OtsevRepForm;

//---------------------------------------------------------------------------

__fastcall TOtsevRepForm::TOtsevRepForm(TComponent* Owner) : TForm(Owner)
{
}

//---------------------------------------------------------------------------
