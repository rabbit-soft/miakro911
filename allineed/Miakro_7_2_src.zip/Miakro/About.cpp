#include <vcl.h>
#pragma hdrstop

#include "About.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
#pragma link "CGAUGES"
#pragma resource "*.dfm"

TAboutForm *AboutForm;

const char last_used_file[] = "LastUsed.cfg";
char vers[] = "7.2.2";

//---------------------------------------------------------------------------

__fastcall TAboutForm::TAboutForm(TComponent* Owner) : TForm(Owner)
{

#ifdef DEMO
  VersLabel->Caption = String("���������������� ������ ������ ") + vers;
#else
  VersLabel->Caption = String("������ ������ ") + vers;
#endif
  VersLabel->Left = (Width - Canvas->TextWidth(VersLabel->Caption)) >> 1;
  Show();
}

//---------------------------------------------------------------------------

void __fastcall TAboutForm::Advance(int n)
{
	DataLabel->Visible = false;
	DoLabel->Visible = true;
	cur_gauge += (float) n * step;
	if (int(cur_gauge) == int(Gauge->Progress)) return;
	Gauge->Progress = cur_gauge;
	Gauge->Update();
}

//---------------------------------------------------------------------------

void __fastcall TAboutForm::Reset(const char *str,int steps)
{
	DataLabel->Visible = true;
	DoLabel->Visible = false;
	Gauge->Progress = 0;
	cur_gauge = 0.0;
	if (str)
		DataLabel->Caption = str;
	else
	{
		DataLabel->Visible = false;
//DoLabel->Visible = true;
	}
	step = steps ? Gauge->MaxValue / (float) steps : (float) steps;
	Update();
}
