#include <vcl.h>
#pragma hdrstop

#include "QuickRx.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"
TButcherReport *ButcherReport;

//---------------------------------------------------------------------------

__fastcall TButcherReport::TButcherReport(TComponent* Owner) : TForm(Owner)
{

}

//---------------------------------------------------------------------------







