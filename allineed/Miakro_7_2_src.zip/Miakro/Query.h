#ifndef QueryH
#define QueryH

//---------------------------------------------------------------------------

#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ComCtrls.hpp>

#include "Passportform.h"
#include "CSPIN.h"

//---------------------------------------------------------------------------

class TQueryForm : public TForm
{
__published:
  TButton *Ok;
  TLabel *NotesLabel;
  TLabel *DeltaLabel;
  TLabel *OverallLabel;
  TCSpinEdit *Overall;
  TCSpinEdit *Delta;
  TEdit *Notes;
  TButton *Cancel;
  TDateTimePicker *When;
  TLabel *WhenLabel;
  TCSpinEdit *WhenRel;
  TLabel *WhenRelLabel;
  TLabel *WhenDateLabel;
	void __fastcall FormShow(TObject *Sender);
	void __fastcall WhenChange(TObject *Sender);
	void __fastcall WhenRelChange(TObject *Sender);
	void __fastcall WhenDblClick(TObject *Sender);
  void __fastcall DeltaChange(TObject *Sender);
  void __fastcall OverallChange(TObject *Sender);
private:
public:
	char notify;
  unsigned char rabbits_in_group;
	QUERY_MODE mode;
	unsigned short cookie_absday; // ����
	__fastcall TQueryForm(TComponent* Owner);
	__fastcall ~TQueryForm() { notify++; }
};

//---------------------------------------------------------------------------

extern TQueryForm *QueryForm;

//---------------------------------------------------------------------------

#endif
