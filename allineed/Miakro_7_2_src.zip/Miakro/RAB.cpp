#include <vcl\vcl.h>
#pragma hdrstop

#include "about.h"
#include <stdlib.h>

//---------------------------------------------------------------------------

USEFORM("Miakro.cpp", PopulationWin);
USERES("Rab.res");
USEUNIT("Rabbit.cpp");
USEFORM("PassportForm.cpp", Passport);
USEFORM("Params.cpp", ParamForm);
USEFORM("BuildPassport.cpp", BuildPas);
USEFORM("Builds.cpp", BuildWin);
USEFORM("Query.cpp", QueryForm);
USEFORM("ReportWin.cpp", ReportForm);
USEUNIT("Money.cpp");
USEFORM("MoneyForm.cpp", TransForm);
USEFORM("Zoo.cpp", ZooForm);
USEFORM("Names.cpp", NameForm);
USEFORM("Genesis.cpp", GenForm);
USEFORM("Zones.cpp", ZoneForm);
USEFORM("Breed.cpp", BreedForm);
USEFORM("Partner.cpp", PartnerForm);
USEFORM("Young.cpp", YoungForm);
USEFORM("Filter.cpp", FilterForm);
USEUNIT("Donor.cpp");
USEFORM("Graph.cpp", GraphForm);
USEUNIT("Import.cpp");
USEFORM("RepRabbit.cpp", RepRabForm);
USEFORM("RepBuild.cpp", RepBuildForm);
USEFORM("ZooRep.cpp", ZooRepForm);
USEFORM("ReportYoung.cpp", RepYoungForm);
USEFORM("GetBabies.cpp", GetBabiesForm);
USEFORM("QuickRx.cpp", ButcherReport);
USEFORM("Archive.cpp", ArchiveForm);
USEFORM("ArcRep.cpp", ArcRepForm);
USEFORM("LossRep.cpp", LossRepForm);
USEFORM("About.cpp", AboutForm);
USEFORM("SellBuyRabRep.cpp", SellBuyRabbitsForm);
USEFORM("MeatSold.cpp", MeatSoldForm);
USEFORM("SkinSold.cpp", SkinSoldForm);
USEFORM("Feed.cpp", FeedForm);
USEFORM("HaveSkin.cpp", HaveSkinForm);
USEFORM("Other.cpp", OtherForm);
USEFORM("HaveMeat.cpp", HaveMeatForm);
USEFORM("Shed.cpp", ShedForm);
USEFORM("OtsevRep.cpp", OtsevRepForm);
USEFORM("UsedFeedRep.cpp", UsedFeedRepForm);
USEFORM("FeedGraph.cpp", FeedGraphForm);
USEFORM("ArcRab.cpp", ArcRabForm);
USEFORM("Bone.cpp", BoneForm);
USEFORM("BoneRep.cpp", BoneReport);
USEFORM("Weight.cpp", WeightForm);
USEFORM("PlemPassport.cpp", PlemReport);
USEUNIT("Sorting.cpp");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR par, int)
{
	try
	{
    HWND hWnd = FindWindowEx(NULL,NULL,NULL,"MIAKRO_DM");
    if (hWnd)
    {
      MessageBox(hWnd,"��������� ��� ��������. ��������, ��� � ������ ���������\n�������� �� ��������������� ������ �� ������ �����!","������ ��� ��������!",MB_OK|MB_ICONWARNING);
      return(0);
    }
		Application->Initialize();
    Application->Title = "MIAKRO_DM";
    Application->HelpFile = "Miakro.hlp";
		Application->CreateForm(__classid(TPopulationWin), &PopulationWin);
     Application->CreateForm(__classid(TAboutForm), &AboutForm);
    AboutForm->Reset("�������������...",40);
     Application->CreateForm(__classid(TBuildWin), &BuildWin);
    AboutForm->Advance();
     Application->CreateForm(__classid(TPlemReport), &PlemReport);
    AboutForm->Advance();
     Application->CreateForm(__classid(TParamForm), &ParamForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TPassport), &Passport);
    AboutForm->Advance();
     Application->CreateForm(__classid(TBuildPas), &BuildPas);
    AboutForm->Advance();
     Application->CreateForm(__classid(TQueryForm), &QueryForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TTransForm), &TransForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TZooForm), &ZooForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TNameForm), &NameForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TGenForm), &GenForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TZoneForm), &ZoneForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TBreedForm), &BreedForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TPartnerForm), &PartnerForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TYoungForm), &YoungForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TFilterForm), &FilterForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TGraphForm), &GraphForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TRepRabForm), &RepRabForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TRepBuildForm), &RepBuildForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TZooRepForm), &ZooRepForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TRepYoungForm), &RepYoungForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TGetBabiesForm), &GetBabiesForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TButcherReport), &ButcherReport);
    AboutForm->Advance();
     Application->CreateForm(__classid(TArchiveForm), &ArchiveForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TArcRepForm), &ArcRepForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TLossRepForm), &LossRepForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TSellBuyRabbitsForm), &SellBuyRabbitsForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TMeatSoldForm), &MeatSoldForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TSkinSoldForm), &SkinSoldForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TFeedForm), &FeedForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(THaveSkinForm), &HaveSkinForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TOtherForm), &OtherForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(THaveMeatForm), &HaveMeatForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TShedForm), &ShedForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TOtsevRepForm), &OtsevRepForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TFeedGraphForm), &FeedGraphForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TUsedFeedRepForm), &UsedFeedRepForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TArcRabForm), &ArcRabForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TBoneForm), &BoneForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TBoneReport), &BoneReport);
    AboutForm->Advance();
     Application->CreateForm(__classid(TWeightForm), &WeightForm);
    AboutForm->Advance();
     Application->CreateForm(__classid(TReportForm), &ReportForm);
		AboutForm->Reset();
		Application->Run();
	}
	catch (Exception &exception)
	{
		MessageBox(NULL,"��������� ����� ������. ��������� ����� �������.\n����� ���������� ������� ��������� ��������� ������� ���� ���������� ���������\n����� ����� (���� ������� �������)","������",MB_APPLMODAL|MB_ICONEXCLAMATION|MB_OK);
		DeleteFile(last_used_file);
		Application->ShowException(&exception);
	}
	return 0;
}

