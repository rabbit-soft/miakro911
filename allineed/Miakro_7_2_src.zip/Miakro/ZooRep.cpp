#include <vcl.h>
#pragma hdrstop

#include "ZooRep.h"
#include "Zoo.h"
#include "ReportWin.h"
#include "Archive.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"

TZooRepForm *ZooRepForm;

//---------------------------------------------------------------------------

__fastcall TZooRepForm::TZooRepForm(TComponent* Owner) : TForm(Owner)
{
}

//---------------------------------------------------------------------------

void __fastcall TZooRepForm::ZooCompReportAddReports(TObject *Sender)
{
	AnsiString head("���������� �� ");
	AnsiString foot("����� ");
	int x = ZooForm->ZooList->Items->Count;
	ReportForm->reports->Prepare(Q_ZOO,ZooForm->ZooList,head += DateToStr(ZooForm->ZooDater->Date),foot + x + ' ' + WorkDecl(x));
	RemField->Lines->Assign(ZooForm->ZooEdit->Lines);
	DupTitle->Caption = head;
	RemDupTitle->Caption = head;
	RemLabel->Caption = AnsiString("���������� � ����������� �� ") + DateToStr(ZooForm->ZooDater->Date);
	ZooCompReport->Reports->Add(ZooRepForm->Report);
	ZooCompReport->Reports->Add(ZooRepForm->RemRep);
}

//---------------------------------------------------------------------------

void __fastcall TZooRepForm::TitleOfRemBeforePrint(TQRCustomBand *Sender,bool &PrintBand)
{
	RemRep->NewPage();
}

//---------------------------------------------------------------------------



