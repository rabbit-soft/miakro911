#include <vcl.h>
#pragma hdrstop

//---------------------------------------------------------------------------

#include "Import.h"
#include "Names.h"
#include "Breed.h"
#include "Builds.h"
#include "ReportWin.h"
#include "About.h"

#define IMPORT_STEPS (H_MAX - H_NAMES + 7)

//---------------------------------------------------------------------------

const char version = 3;
enum { NK_KEY,NK_NAME,NK_MSUR,NK_FSUR,NK_BOOL_MALE,NK_BOOL_USED };
enum { BR_KEY,BR_FULL_BREED,BR_SHORT_BREED };
static const char *fnames[H_MAX]  = { "names","porody","ferma","fath","math","chil","kfath","kmath","kchil","note","realiz" };
static Header *headers[H_MAX];
Rabbit *Header::glob_rab;
ConvSet HdSets[H_MAX];

static const char map[128] = // 866->Win
{
		'�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�',
		'�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�',
		'�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�',
		'+','+','+','+','+','+','+','+','+','+','+','+','+','+','+','+',
		'+','+','+','+','+','+','+','+','+','+','+','+','+','+','+','+',
		'+','+','+','+','+','+','+','+','+','+','+','+','+','+','+','+',
		'�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�',
		'�','�','+','+','+','+','+','+','+','+','+','+','+','+','+','+'
};

//---------------------------------------------------------------------------

#pragma package(smart_init)

//---------------------------------------------------------------------------

__fastcall Field::Field(TStream& s)
{
	s.ReadBuffer(name,sizeof(name));
	s.ReadBuffer(&type,1);
	s.ReadBuffer(&addr,sizeof(addr));
	s.ReadBuffer(&len,1);
	s.ReadBuffer(&dec,1);
	s.ReadBuffer(&reserved,sizeof(reserved));
}

//---------------------------------------------------------------------------

__fastcall FieldList::FieldList(TStream& s) : TList()
{
	Field *f;
	unsigned char len = 1,x;
	while(true)
	{
		s.ReadBuffer(&x,1);
		if (x == 0xd)
			break;
		s.Position = s.Position - 1;
		Add(f = new Field(s));
		f->SetBias(len);
		len += f->GetLen();
	}
}

//---------------------------------------------------------------------------

__fastcall FieldList::~FieldList()
{
	for (int i = 0; i < Count; i++)
		delete GetField(i);
}

//---------------------------------------------------------------------------

__fastcall Header::Header(TStream& s,char set_index)
{
	fields = NULL;
	start = NULL;
	unsigned char c;
	s.ReadBuffer(&c,1);
	int len;
	ConvSet& hdset = HdSets[set_index];
	unsigned short head_len;
	if ((c & 0x7f) != version) return;
	s.ReadBuffer(&numrec,3); 		 // ���� ����������
	s.ReadBuffer(&numrec,4); 		 // ���-�� �������
	s.ReadBuffer(&head_len,2); 	 // ����� ���������
	s.ReadBuffer(&reclen,2); 		 // ����� ������
	s.Position = s.Position + 20; // ���������� ��������� �����
	fields = new FieldList(s);
	len = numrec * reclen;
	start = new char[len];
	s.Position = head_len;
	char *p,*px,l,j;
	px = start;
	s.ReadBuffer(px,len);
	for (int i = 0; i < (signed) numrec; i++)
		for (j = 0,p = GetRecord(i); j < fields->Count; j++)
			if (hdset.Contains(j))
				for (px = GetField(p,j,true),l = GetFieldLen(j); l--; px++)
					if (*px & 0x80)
						*px = map[*px & 0x7f];
}

//---------------------------------------------------------------------------

bool GetAll(const AnsiString& Path)
{
	memset(headers,0,sizeof(headers));
	TFileStream *s = NULL;
	for (char i = H_NAMES; i < H_MAX; i++)
	{
		AnsiString x(Path);
		x += AnsiString(fnames[i]) + ".dbf";
		try
		{
			s = new TFileStream(x,fmOpenRead);
			headers[i] = new Header(*s,i);
		}
		catch(...)
		{
			if (s) delete s;
			return false;
		}
		AboutForm->Advance();
		if (s)
		{
			delete s;
			s = NULL;
		}
	}
	return true;
}

//---------------------------------------------------------------------------

void ClearBase()
{
	for (char i = H_NAMES; i < H_MAX; i++)
		if (headers[i])
		{
			delete headers[i];
			headers[i] = NULL;
		}
}

//---------------------------------------------------------------------------

char * __fastcall Header::GetRecord(int n)
{
	if (n < 0 || n >= (signed) numrec) return NULL;
	return start + n * reclen;
}

//---------------------------------------------------------------------------

char * __fastcall Header::GetField(char *rec,int field,bool adr)
{
	static char buf[40];
	if (!rec || field > fields->Count)
		PopulationWin->Terminator("������ ����������!");
	rec += fields->GetField(field)->GetBias();
	if (adr) return rec;
	strncpy(buf,rec,field = fields->GetField(field)->GetLen());
	do
		buf[field--] = 0;
	while (field >= 0 && buf[field] == ' ');
	return buf;
}

//---------------------------------------------------------------------------

bool ImportFile(const AnsiString& Path)
{
	const int suckers_count_limit = 10; // ��� �������� �������� �����, ��� �� 10 ���� ������ �� ������� �� �����
	int i;
	unsigned short x;

	if (!ParamForm->Config.heterosis)
		PopulationWin->HeterosisClick(NULL);
	if (!ParamForm->Config.inbreeding)
		PopulationWin->InbreedingClick(NULL);
	AboutForm->Reset("���������� ������ � �����...",IMPORT_STEPS);
	if (GetAll(Path))
	{
		ReportForm->Report->Lines->Clear();
		try { ReportForm->Report->Lines->LoadFromFile(map_file); }
		catch (...) {}
		ReportForm->changed = false;
		AboutForm->Advance();
		for (i = 0; i < H_MAX; i++)
			if (!headers[i])
			{
				AboutForm->Reset();
				return false;
			}
		BuildWin->ProcessMap();
		headers[H_NAMES]->InsertNames();
		AboutForm->Advance();
		headers[H_BREEDS]->InsertBreeds();
		AboutForm->Advance();
		headers[H_FARM]->InsertFarm(BuildWin->mapper);
		AboutForm->Advance();
		headers[H_KFA]->InsertKFathers(BuildWin->mapper);
		AboutForm->Advance();
		headers[H_KMO]->InsertKMothers(BuildWin->mapper);
		AboutForm->Advance();
		headers[H_KCHIL]->InsertKChildren(BuildWin->mapper);
		AboutForm->Advance();
		ListRab *lr = PopulationWin->rabbits;
		Rabbit *r;
		for (i = 0; i < lr->Count; i++)
		{
			NameForm->MakeRabNameBusy(r = lr->GetRabbit(i));
			r->TestCountsAndNests();
			if ((x = r->DateOfSuckersCount()) && today - x > suckers_count_limit)
				r->AdjustCountDate();
		}
		ListBuild *bl = BuildWin->builds;
		MiniFarm *mf;
		unsigned short id;
		for (i = 0; i < bl->Count; i++)       // ������� ���������������
		{
			mf = bl->GetMiniFarmByIndex(i);
			if (mf->IntegralBusy()) continue; 	// �� ������ �� ���������
			id = mf->GetId();
			if (BuildWin->mapper->FindRabMap(id,0,false) != ~0 && !BuildWin->mapper->FindAtLeft(id))
			{
				for (int j = 0; j < BuildWin->mapper->ids->Count; j++)
					if ((unsigned short) BuildWin->mapper->ids->Items[j] == id)
					{
						((TTreeNode *) BuildWin->mapper->tns->Items[j])->Delete();
						BuildWin->mapper->tns->Delete(j);
						BuildWin->mapper->ids->Delete(j);
						break;
					}
				bl->Remove(mf);
				delete mf;
				i--;
			}
		}
		AboutForm->Advance();
		PopulationWin->MakeSuckers(false);
		AboutForm->Reset();
		return true;
	}
	AboutForm->Reset();
	return false;
}

//---------------------------------------------------------------------------

void __fastcall Header::InsertNames()
{
	RabName *rn;
	char *rec,*name,*sur;
	RabNameList *nl;
	for (int i = 0; i < (int) numrec; i++)
	{
		rec = GetRecord(i);
		nl = IsTrue(rec,NK_BOOL_MALE) ? NameForm->male_names : NameForm->female_names;
		name = (char *) CheckName(GetField(rec,NK_NAME),GetField(rec,NK_NAME,true));
		sur = GetField(rec,NK_MSUR);
		if (!*sur)
			sur = (char *) NameForm->MakeSurname(name,strlen(name));
		else
			sur = (char *) CheckName((char *) sur,GetField(rec,NK_MSUR,true));
		if (!nl->Add(rn = new RabName(name,sur))) delete rn; // ������������ �����������. ������ ���������
		free(name);
		free(sur);
	}
}

//---------------------------------------------------------------------------

const char * __fastcall Header::CheckName(char *name,char *adr)
{
	static char decode[2][22] =
	{
		{ "eETyYoOpPaAHkKxXcCBmM" },
		{ "���������������������" }
	};
	bool bad = false;
	char *px;
	for (char *p = name; *p; p++,adr++)
	{
		if (px = strchr(decode[0],*p))
			*p = *adr = decode[1][(unsigned long) px - (unsigned long) decode];
		else if (!isrus(*p))
		{
			*adr = *p = '?';
			bad = true;
		}
	}
	if (bad)
	{
		AnsiString a("������ ��� \"");
		a += AnsiString(name) + "\" � ��� ������������ ��������� ����� ��� ������������ �������. ��� ������������� ���������������.";
		ReportForm->Report->Lines->Add(a);
		ReportForm->changed = false;
	}
	return strdup(name);
}

//---------------------------------------------------------------------------

char * __fastcall Header::FindRecByKey(char *key,char len,unsigned char k_field)
{
	char *rec;
	for (unsigned int i = 0; i < numrec; i++)
	{
		rec = GetRecord(i);
		if (!memcmp(key,GetField(rec,k_field,true),len))
			return GetRecord(i);
	}
	return NULL;
}

//---------------------------------------------------------------------------

void __fastcall Header::InsertBreeds()
{
	char *rec;
	StringList *sl = BreedForm->GetBreedList();
	int c = 0;
	for (int i = 0; i < (int) numrec; i++)
	{
		rec = GetRecord(i);
		AnsiString Full(GetField(rec,BR_FULL_BREED));
		AnsiString Short(GetField(rec,BR_SHORT_BREED));
		if (sl->FindString(Full) == ~0 && sl->FindString(Short) == ~0)
		{
			sl->AddString(Full);
			sl->AddString(Short);
			sl->AddString(++c);
		}
	}
}

//---------------------------------------------------------------------------

void __fastcall Header::InsertFarm(Mapper *mapper)
{
	enum { I_BLK,I_SHED,I_FARM,I_LOWER,I_A,I_B,I_C,I_D };
	enum { X_REPAIR = 1 };
	Map *map_change_tier_type;
	char *rec;
	int id,mf_id,blk,shed,mshed;
	TTreeNode *tn,*root;
	MiniFarm *mf;
	Tier *ti;
	for (int i = 0; i < (int) numrec; i++)
	{
		rec = GetRecord(i);
		if (!(mf_id = atoi(GetField(rec,I_FARM)))) continue; // ���� ����� ���������?
		root = BuildWin->Plan->Items->GetFirstNode();
		blk = shed = mshed = 0;
		if (map_change_tier_type = mapper->GetSrc(mapper->Find(mf_id,CHANGE_TIER_TYPE)))
		{
			blk = map_change_tier_type->GetBlock();
			shed = map_change_tier_type->GetShed();
			mshed = map_change_tier_type->GetMiniShed();
		}
		if ((id = blk ) || (id = atoi(GetField(rec,I_BLK)))) // ���� ����?
		{
			if (!(tn = BuildWin->FindSiblBuild(root,BLOCK,id)))
				tn = BuildWin->InsertSorted(root,AnsiString("���� ") + id);
			root = tn;
		}
		if ((id = shed) || (id = atoi(GetField(rec,I_SHED)))) // ���� ���?
		{
			if (!(tn = BuildWin->FindSiblBuild(root,SHED,id)))
				tn = BuildWin->InsertSorted(root,AnsiString("��� ") + id);
			root = tn;
		}
		if (mshed) // ���� �������?
		{
			if (!(tn = BuildWin->FindSiblBuild(root,MINISHED,mshed)))
				tn = BuildWin->InsertSorted(root,AnsiString("������� ") + mshed);
			root = tn;
		}
		if (!(tn = BuildWin->FindSiblBuild(root,MINIFARM,mf_id)))
			tn = BuildWin->InsertSorted(root,AnsiString(mf_id));
		mapper->AddTreeNodeRef(tn,mf_id);                // ������������ ����� ������� ��������� � �� �����
		BuildWin->builds->Add(mf = new MiniFarm(mf_id));
		if (map_change_tier_type)
		{
			mf->CreateTier(map_change_tier_type->GetUpperTierType());
			if (map_change_tier_type->HasTwoTiers())
				mf->CreateTier(map_change_tier_type->GetLowerTierType(),true);
		}
		else
		{
			ti = mf->CreateTier(T_FEMALE,true); // ������ - ������ ����������
			if (atoi(GetField(rec,I_LOWER)) == X_REPAIR)
				ti->SetRepair(true);
			ti = mf->CreateTier(T_BARIN);       // �� ��������� - �����
			if (atoi(GetField(rec,I_A)) == X_REPAIR || atoi(GetField(rec,I_B)) == X_REPAIR)
				ti->SetRepair(true);
		}
	}
}

//---------------------------------------------------------------------------

int __fastcall Header::ExtractDate(const char *field)
{
	if (rusisdigit(*field) && *field != '0')
	{
		unsigned short day,month,year;
		char buf[5];
		strncpy(buf,field,4);
		buf[4] = 0;
		year = atoi(buf);
		strncpy(buf,field += 4,2);
		buf[2] = 0;
		month = atoi(buf);
		strncpy(buf,field += 2,2);
		day = atoi(buf);
		try
		{
			TDateTime dt(year,month,day);
			return (int) dt;
		}
		catch(...)
		{
			year = 1980;
			day = 1;
			month = 1;
			TDateTime dt(year,month,day);
			return (int) dt;
		}
	}
	return 0;
}

//---------------------------------------------------------------------------

unsigned short __fastcall Header::Breeder(char *rec,Rabbit *r,char field)
{
	char *rx;
	int n = 0;
	if (*(rx = GetField(rec,field,true)) && (rx = headers[H_BREEDS]->FindRecByKey(rx,fields->GetField(field)->GetLen(),0))) // ���� � ���� �����
	{
		rx = headers[H_BREEDS]->GetField(rx,BR_FULL_BREED); // ������ �������� ������, ������������ �� ���� �����
		if ((n = BreedForm->GetBreedList()->FindString(rx)) != ~0)
			r->SetBreed(n /= 3);
		else
			n = 0;
	}
	return n;
}

//---------------------------------------------------------------------------

void __fastcall Header::Namer(char *rec,Rabbit *r,char field,SEX ctrl)
{
	if (rec = headers[H_NAMES]->FindRecByKey(GetField(rec,field,true),fields->GetField(field)->GetLen(),0))
	{
		rec = headers[H_NAMES]->GetField(rec,NK_NAME); // ���� ���
		RabName *rn = NameForm->FindRabName(rec,ctrl);
		if (!rn)
			PopulationWin->Terminator("���� ��� ��� �������! #1");
		switch (ctrl)
		{
			case SEX_VOID:
				if (rn->IsUsed())
				{
					AnsiString a("�� ����� ����� ��������� �������� � ������ \"");
					ReportForm->Report->Lines->Add(a + rn->GetName() + '\"');
					r->SetDupName(true);
				}
				r->SetName(rn->MakeUsed());
				break;
			case MALE:
				r->SetPathonomic(rn->GetOrSetSurKey());
				break;
			case FEMALE:
				r->SetSurname(rn->GetOrSetSurKey());
		}
	}
}

//---------------------------------------------------------------------------

void __fastcall Header::Farmer(char *rec,Rabbit *r,char farm,char area,Mapper *mapper)
{
	MiniFarm *mf;
	Tier *ti;
	int m,id = atoi(GetField(rec,farm));
	char ar = *GetField(rec,area);
	if ((m = mapper->FindRabMap(id,ar)) != ~0)
	{
		TIER_ID tid;
		Map *dest = mapper->GetDest(m);
		r->SetWhere(id = dest->GetId());
		r->SetTierId(tid = dest->GetTierId());
		mf = BuildWin->builds->GetMiniFarmById(id);
		ti = mf->GetTier(tid == LOWER_TIER);
		r->SetArea(area = dest->GetArea() - '�');
		r->SetTier(ti->GetType());
		ti->SetBusy(true,area);
		return;
	}
	mf = BuildWin->builds->GetMiniFarmById(id);
	ti = mf->GetTier();
	try
	{
		r->SetWhere(id); 																	// �����
		r->SetTierId(UPPER_TIER);
		r->SetArea(0);
		switch (*(rec = GetField(rec,area)))
		{
			case 'a':
			case '�':
				r->SetTierId(LOWER_TIER);
				if (ti = mf->GetTier(true))
					ti->SetBusy(true);
				else
					throw(NULL);
				break;
			case '�':
				if (rec[1] == '�')
				{
					ti->SetDelim(0,false);
					ti->SetBusy(true);
				}
				ti->SetBusy(true);
				break;
			case '�':
				r->SetArea(1);
				ti->SetBusy(true,1);
				break;
			case '�':
				mf->CreateTier(T_FEMALE);
				ti = mf->GetTier();
				ti->SetBusy(true);
		}
		if (!ti) throw(NULL);
		r->SetTier(ti->GetType());
	}
	catch (...)
	{
		AnsiString a("��������� ������ � ����� ������������. � ��������� ");
		ReportForm->Report->Lines->Add(a + id + " ����������� ������ ���� (������� ������� �������� ���� �������)");
		ReportForm->changed = false;
	}
}

//---------------------------------------------------------------------------

void __fastcall Header::Blooder(char *rec,char field)
{
	rec = GetField(rec,field); 																	// ��������
	char * const key = rec + fields->GetField(field)->GetLen();
	int n;
	do
	{
		if (n = atoi(rec))
			glob_rab->AddGenNumber(n);
		while (*++rec && rec != key && rusisdigit(*rec));
		for (; *rec && rec != key && !rusisdigit(*rec); rec++);
	}
	while (*rec && rec != key);
}

//---------------------------------------------------------------------------

void __fastcall Header::InsertKFathers(Mapper *mapper)
{
	enum { I_KEY,I_NAME,I_PAPA,I_MAMA,I_BREED,I_GEN,I_BLOOD,I_BORN,I_WHENFUCK,I_BLK,I_SHED,I_FARM,I_AREA,I_STATUS,I_STATRAB,I_DATRAB,I_WEIGHT,I_RATE,I_OVERALL_FUCKS,I_OVERALL_CHILDREN };
	int n;

	for (int i = 0; i < (int) numrec; i++)
	{
		char *rec = GetRecord(i);
		PopulationWin->rabbits->Add(glob_rab = new Male);
		Namer(rec,glob_rab,I_NAME);
		Breeder(rec,glob_rab,I_BREED);
		Blooder(rec,I_BLOOD);
		Farmer(rec,glob_rab,I_FARM,I_AREA,mapper);
		Parenter(rec,glob_rab,I_MAMA,FEMALE);
		Parenter(rec,glob_rab,I_PAPA,MALE);
		glob_rab->SetAge(ExtractDate(GetField(rec,I_BORN)),true); // ���� ��������
		n = ExtractDate(GetField(rec,I_WHENFUCK));
		if (n == today || n == today - 1)
			glob_rab->SetLastFuck(n,true);
		glob_rab->SetRate(atoi(GetField(rec,I_RATE)));
		glob_rab->SetWeight(atoi(GetField(rec,I_WEIGHT)),glob_rab->GetAge());
		glob_rab->SetStatus(FATHER);
	}
}

//---------------------------------------------------------------------------

void __fastcall Header::Parenter(char *rec,Rabbit *r,char field,SEX sex)
{
	char *key = GetField(rec,field,true);
	if (!*key || !strncmp(key,"...",3)) return;
	char len = fields->GetField(field)->GetLen();
	char *rx;
	if (sex == MALE)
	{
		if (rx = headers[H_KFA]->FindRecByKey(key,len,0))
		{
			enum { I_NAME = 1,I_MAMA,I_PAPA,I_BLOOD = 6 };
			if (r)
				headers[H_KFA]->Namer(rx,r,I_NAME,sex);
			headers[H_KFA]->Blooder(rx,I_BLOOD);
			headers[H_KFA]->Parenter(rx,NULL,I_MAMA,FEMALE);
			headers[H_KFA]->Parenter(rx,NULL,I_PAPA,MALE);
		}
		else if (rx = headers[H_FA]->FindRecByKey(key,len,0))
		{
			enum { I_BLOOD = 5 }; // ����� ����� ���
			headers[H_FA]->Blooder(rx,I_BLOOD);
		}
	}
	else
	{
		if (rx = headers[H_KMO]->FindRecByKey(key,len,0))
		{
			enum { I_NAME = 1,I_MAMA,I_PAPA,I_BLOOD = 10 };
			if (r)
				headers[H_KMO]->Namer(rx,r,I_NAME,sex);
			headers[H_KMO]->Blooder(rx,I_BLOOD);
			headers[H_KMO]->Parenter(rx,NULL,I_MAMA,FEMALE);
			headers[H_KMO]->Parenter(rx,NULL,I_PAPA,MALE);
		}
		else if (rx = headers[H_MO]->FindRecByKey(key,len,0))
		{
			enum { I_NAME = 2,I_MAMA,I_PAPA,I_BLOOD = 7 };
			if (r)
				headers[H_MO]->Namer(rx,r,I_NAME,sex);
			headers[H_MO]->Blooder(rx,I_BLOOD);
			headers[H_MO]->Parenter(rx,NULL,I_MAMA,FEMALE);
			headers[H_MO]->Parenter(rx,NULL,I_PAPA,MALE);
		}
	}
}

//---------------------------------------------------------------------------

void __fastcall Header::InsertKMothers(Mapper *mapper)
{ //                                                                                              			                        DATE    DATE    num    num     num      num     char 1   char 4     Date    num 2  char 3
	enum { I_KEY,I_NAME,I_MAMA,I_PAPA,I_BREED,I_BORN,I_BLK,I_SHED,I_FARM,I_AREA,I_BLOOD,FUCKER_1,FUCKER_2,FUCKER_3,I_OKROLS,I_KUK,DPLVAS,DLOKROL,KOLKRS,KOLWRKS,KOLKROL,I_WEIGHT,I_STATUS,I_STATRAB,I_DATRAB,I_RATE,I_RKVOD };
	const int crap_mask = 8;
	char *rec;
	int status;
	for (int i = 0; i < (int) numrec; i++)
	{
		rec = GetRecord(i);
		PopulationWin->rabbits->Add(glob_rab = new Female);
		Namer(rec,glob_rab,I_NAME);
		Breeder(rec,glob_rab,I_BREED);
		Blooder(rec,I_BLOOD);
		Farmer(rec,glob_rab,I_FARM,I_AREA,mapper);
		glob_rab->SetAge(ExtractDate(GetField(rec,I_BORN)),true); // ���� ��������
		glob_rab->SetRate(atoi(GetField(rec,I_RATE)));
		glob_rab->SetWeight(atoi(GetField(rec,I_WEIGHT)),glob_rab->GetAge());
		glob_rab->SetBorns(atoi(GetField(rec,I_OKROLS)));
		glob_rab->SetEvDate(ExtractDate(GetField(rec,DPLVAS)),true);
		glob_rab->SetOkrolDate(ExtractDate(GetField(rec,DLOKROL)),true);
		status = atoi(GetField(rec,I_STATUS));
		glob_rab->SetCrap(status & crap_mask);
		if (*GetField(rec,I_KUK))
			glob_rab->SetEvType(KUK);
		else switch (glob_rab->GetBorns())
		{
			case 0:
				if (glob_rab->GetEvDate(true))
					glob_rab->SetEvType(SLUCHKA);
				break;
			case 1:
				if (!glob_rab->IsPregnant()) // �� ���������� - ������
				{
					glob_rab->SetEvType(SLUCHKA);
					break;
				}
			default:
				glob_rab->SetEvType(VYAZKA);
		}
		Parenter(rec,glob_rab,I_MAMA,FEMALE);
		Parenter(rec,glob_rab,I_PAPA,MALE);
	}
}

//---------------------------------------------------------------------------

void __fastcall Header::InsertKChildren(Mapper *mapper)
{ //        C3   C3     C3      C2        C2     C1       D2     C1    DAt8     C4       DAT8     C4                                30         30     D2
	enum { I_KEY,I_PAPA,I_MAMA,I_SURNAME,I_NAME,I_BREED,I_NUMBER,I_SEX,I_BORN,I_STATRAB,I_DATRAB,I_STATUS,I_BLK,I_SHED,I_FARM,I_AREA,I_BLOOD1,I_BLOOD,I_OKROL,I_WEIGHT,I_KRVOD,I_KUK };
	ListRab * const lr = PopulationWin->rabbits;
	for (int i = 0; i < (int) numrec; i++)
	{
		char *rec = GetRecord(i);
		switch (*GetField(rec,I_SEX))
		{
			case 'M':
			case '�':
			case '�':
				glob_rab = new Male;
				break;
			case '�':
			case '�':
				glob_rab = new Female;
				break;
			default:
				glob_rab = new Rabbit;
		}
		Namer(rec,glob_rab,I_NAME);
		Breeder(rec,glob_rab,I_BREED);
		Blooder(rec,I_BLOOD);
		Farmer(rec,glob_rab,I_FARM,I_AREA,mapper);
		glob_rab->SetAge(ExtractDate(GetField(rec,I_BORN)),true); // ���� ��������
		glob_rab->SetWeight(atoi(GetField(rec,I_WEIGHT)),glob_rab->GetAge());
		Parenter(rec,glob_rab,I_MAMA,FEMALE);
		Parenter(rec,glob_rab,I_PAPA,MALE);
		glob_rab->SetGroup(max(1,atoi(GetField(rec,I_NUMBER))));
		glob_rab->SetOkrolNum(atoi(GetField(rec,I_OKROL)));
		lr->Add(glob_rab); // ������ ��� ���� ������ � �������� ������ - ��� ����� ������������� � ����������� �����
	}
}

//---------------------------------------------------------------------------

void FixNeededFuckers() // ������ �� ���������� � ��������� ����� �� ����
{
	enum { I_KEY,I_NAME,FUCKER_1 = 11,FUCKER_2,FUCKER_3 }; // ����� ��� ������� � �����
	ListRab * const lr = PopulationWin->rabbits;
	ListFuck *lf;
	Fucker *fu;
	Rabbit *r;
	int i,j,k;
	const char *p,*px;
	char *pq,*moth_rec,*fath_rec,*key,len;
	Header *h = headers[H_KMO];
	for (i = 0; i < lr->Count; i++)
		if ((r = lr->GetRabbit(i))->IsPregnant() && (p = r->GetName()))
		{
			r->AddMoreFuckers();
			lf = r->GetFuckersList();
			moth_rec = h->FindRabbitByName(p,I_NAME);
			for (j = FUCKER_1; j <= FUCKER_3; j++)
			{
				if (*(key = h->GetField(moth_rec,j,true)) == ' ') continue;
				len = h->GetFields()->GetField(j)->GetLen();
				if (fath_rec = headers[H_KFA]->FindRecByKey(key,len,I_KEY))   // ���� ����
				{
					enum { I_NAME = 1 };
					px = headers[H_KFA]->GetField(fath_rec,I_NAME); 						// ���� ����� ����
				}
				else
				{
					enum { I_NAME = 3 };
					if (fath_rec = headers[H_FA]->FindRecByKey(key,len,I_KEY))  // ���� ����
						px = headers[H_FA]->GetField(fath_rec,I_NAME);            // ���� ����� ����
					else
					{
						AnsiString a(p);
						a += AnsiString(": �� ���� ����� ���������� �������� �� �����!");
						ReportForm->Report->Lines->Add(a);
						lf->Add(new Fucker(r->GetBreed()));
						continue;
					}
				}
				enum { I_NAME = 1 };
				len = headers[H_NAMES]->GetFields()->GetField(I_KEY)->GetLen();
				pq = headers[H_NAMES]->FindRecByKey((char *) px,len,0);       // ������ �����
				pq = headers[H_NAMES]->GetField(pq,I_NAME);										// pq - ��� ������
				for (k = 0; k < lf->GetCount(); k++)
					if (!russtricmp(pq,(fu = lf->GetFucker(k))->GetName()))
					{
						fu->SetIsFuckLast(true);
						break;
					}
				if (k && k == lf->GetCount()) // ����� �� ������! ��������, ��� ��� ��� �� �����, ���� - ���������/���������...
				{
					RabName *rn = NameForm->male_names->Find(pq);
					if (rn->IsUsed())
					{
						AnsiString a(p);
						a += AnsiString(": ��������� ������� \"") + pq + "\" ����������� � ������ ��������� ���������! (���� �������� ����)";
						ReportForm->Report->Lines->Add(a);
					}
					else // ���� ��� ��� �� �����.
					{
						enum { FATH_BREED = 4,FATH_KROV };
						Fucker *fu;
						Header::glob_rab = new Male();
						headers[H_FA]->Blooder(fath_rec,FATH_KROV);
						headers[H_FA]->Breeder(fath_rec,Header::glob_rab,FATH_BREED);
						lf->Add(fu = new Fucker(Header::glob_rab));
						fu->Dead(Header::glob_rab);
						fu->SetIsFuckLast(true);
						fu->SetFuckNum(1);
						delete Header::glob_rab;
						Header::glob_rab = NULL;
					}
				}
			}
		}
	ReportForm->changed = false;
}

//---------------------------------------------------------------------------

char * __fastcall Header::FindRabbitByName(const char *name,char field)
{
	enum { I_NAME = 1 };
	char *p,*px;
	char len = fields->GetField(field)->GetLen();
	for (unsigned i = 0; i < numrec; i++)
	{
		p = GetRecord(i);
		px = GetField(p,field,true);
		px = headers[H_NAMES]->FindRecByKey(px,len,0);
		px = headers[H_NAMES]->GetField(px,I_NAME);
		if (!russtricmp(name,px))
			return p;
	}
	return NULL;
}

//---------------------------------------------------------------------------

bool operator == (const Map& a,const Map& b)
{
	return a.id == b.id && a.area == b.area;
}

//---------------------------------------------------------------------------

int __fastcall Mapper::Find(int id,OPER oper)
{
	Map *map;
	for (int i = 0; i < src->Count; i++)
	{
		map = src->GetMap(i);
		if (map->GetId() == id && (oper == OP_VOID || oper == map->GetOper()))
			return i;
	}
	return ~0;
}

//---------------------------------------------------------------------------

int __fastcall Mapper::FindRabMap(int id,char area,bool use_area)
{
	Map *map;
	for (int i = 0; i < src->Count; i++)
	{
		map = src->GetMap(i);
		if (map->GetOper() == REMAP_RABBIT && map->GetId() == id && (!use_area || map->GetArea() == area))
			return i;
	}
	return ~0;
}

//---------------------------------------------------------------------------

bool __fastcall Mapper::FindAtLeft(int id)
{
	int i = 0;
	while (i < dest->Count)
		if (dest->GetMap(i++)->GetId() == id) return true;
	return false;
}

