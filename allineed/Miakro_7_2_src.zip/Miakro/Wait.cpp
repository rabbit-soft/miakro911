#include <vcl.h>
#pragma hdrstop

#include "Wait.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"
TWaitForm *WaitForm;

//---------------------------------------------------------------------------

__fastcall TWaitForm::TWaitForm(TComponent* Owner) : TForm(Owner)
{
}

//---------------------------------------------------------------------------

