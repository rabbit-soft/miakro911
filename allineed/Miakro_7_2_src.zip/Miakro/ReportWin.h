#ifndef ReportWinH
#define ReportWinH

//---------------------------------------------------------------------------

#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ComCtrls.hpp>
#include <vcl\Menus.hpp>
#include <fstream.h>
#include <vcl\ExtCtrls.hpp>
#include <vcl\Dialogs.hpp>
#include <quickrpt.hpp>
#include "QuickRx.h"

#include "Grids.hpp"
#include "Params.h"

class WinCoorList;
class Columners;

#define WINCOOR_FILE "win_coords.cfg"

enum REPORT_TYPE { ZOO_PAGE,RABBIT_PAGE,SHED_PAGE }; // ���� �������
enum START_STOP { START,STOP,MIDDLE };
enum QRP { Q_BUTCHER,Q_RABBITS,Q_BUILDINGS,Q_ZOO,Q_YOUNG,Q_ARCHIVE,Q_LOSS,Q_MEATSOLD,Q_SKINSOLD,Q_SELLBUYRAB,Q_FEED,Q_OTHER,Q_HAVEMEAT,Q_HAVESKIN,Q_USEDFEED,Q_OTSEV,Q_ARCRAB,Q_BONE,MAX_REPORTS };

//---------------------------------------------------------------------------

class RepInfo
{
	private:
		TQuickRep *report;
		TQRLabel  *header;
		TQRLabel  *summary;
		unsigned short __fastcall CalcRecLen(TListView *lw,unsigned short *arr);
	public:
				 __fastcall RepInfo(TQuickRep *rep,TQRLabel *h,TQRLabel *s) { report = rep; header = h; summary = s; }
		void __fastcall Set(AnsiString& h,AnsiString& f) { header->Caption = h; summary->Caption = f; }
		void __fastcall Reset() { report->DataSet->Active = false; }
		void __fastcall MakeReport(TListView *lw);
		TQuickRep * __fastcall GetReport() { return report; }
};

//---------------------------------------------------------------------------

class Reports : public TList
{
	private:
		QRP current;
		RepInfo * __fastcall GetRepInfo(int i) { return (RepInfo *) Items[i]; }
		void      __fastcall ToDb(TStream& s,AnsiString a,START_STOP start = MIDDLE);
	public:
		static TQuickRep *rep_table[MAX_REPORTS];
		static TQRLabel  *head_table[MAX_REPORTS];
		static TQRLabel  *summary_table[MAX_REPORTS];
							__fastcall Reports();
							__fastcall ~Reports() { for (int i = 0; i < Count; delete GetRepInfo(i++)); }
		void 			__fastcall Prepare(QRP what,TListView *lw,AnsiString header,AnsiString summary);
		void 			__fastcall PreView() { GetRepInfo(current)->GetReport()->Preview(); }
		void 			__fastcall Print() { GetRepInfo(current)->GetReport()->Print(); }
};

//---------------------------------------------------------------------------

class TReportForm : public TForm
{
__published:
	TMainMenu *MainMenu1;
	TMenuItem *Type;
	TMenuItem *PrintMe;
	TRichEdit *Report;
	TStatusBar *ReportStatus;
	TMenuItem *N1;
	TMenuItem *SelFont;
	TMenuItem *N2;
	TMenuItem *RememberMap;
	TMenuItem *OpenMap;
  TGroupBox *LowGroup;
  TButton *RememberNotes;
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall FormDestroy(TObject *Sender);
	void __fastcall RememberMapClick(TObject *Sender);
	void __fastcall OpenMapClick(TObject *Sender);
	void __fastcall PrintMeClick(TObject *Sender);
	void __fastcall ReportChange(TObject *Sender);
  void __fastcall RememberNotesClick(TObject *Sender);
  void __fastcall FormShow(TObject *Sender);
private:
	AnsiString 			 last_header,last_footer;
	unsigned short 	 page_width;
	unsigned short 	 delta_day;
	const TListView *last_list;
	TStrings 				*last_rem;
	bool 						 last_sel_only;
	void 				 	 __fastcall PutFreeAreas(); // ���� ������ ��������� ������
public:
	Reports 		*	reports;
	Columners		* columners;
	WinCoorList * win_coords;
	TList				* auto_lists;
	char 					notify;
	bool 					changed;
  TListItem  *notes_li;
  char        notes_col_index;
								 __fastcall TReportForm(TComponent* Owner);
								 __fastcall ~TReportForm();
	void 		  		 __fastcall TrySaveMap();
  void           __fastcall Alarm();
};

//---------------------------------------------------------------------------

class WinCoor
{
	private:
		W_ID	what;
		RECT 	Coords;
		bool	visible;
		TForm *win;
	public:
		__fastcall WinCoor(W_ID wh) { win = form_array[what = wh]; memset(&Coords,0,sizeof(Coords)); visible = false; }
		void __fastcall Render() const;
		friend TStream& operator >> (TStream& s,WinCoor *wc);
		friend TStream& operator << (TStream& s,WinCoor *wc);
		friend WinCoorList;
};

//---------------------------------------------------------------------------

class WinCoorList : public TList
{
	private:
	public:
		__fastcall WinCoorList();
		__fastcall ~WinCoorList() { for (int i = 0; i < Count; delete GetWinCoor(i++)); }
		WinCoor * __fastcall GetWinCoor(int i) { return (WinCoor *) Items[i]; }
		void __fastcall Process() {	for (int i = 0; i < Count; GetWinCoor(i++)->Render()); }
		friend TStream& operator >> (TStream& s,WinCoorList *wcl);
		friend TStream& operator << (TStream& s,WinCoorList *wcl);
};

//---------------------------------------------------------------------------

enum CLIST_TYPE { C_RABBITS,C_BUILDS,C_YOUNG,C_ZOO,C_ARCHIVE,MAX_CLISTS  };
enum PAR_ID { PI_TIER,PI_AREA,PI_SUR,PI_ABBR };

class Columner
{
	private:
		struct
		{
			unsigned show_tier_types 	: 1;
			unsigned show_area_types	: 1;
			unsigned double_sur				:	1;	// ������� �������
			unsigned tab_abbr 				: 1;  // ���������� � ��������
			unsigned id								: 4;  // CLIST_TYPE
		} Id;
		TList *params;
	public:
		__fastcall Columner(CLIST_TYPE id);
		__fastcall ~Columner() { delete params; }
		__fastcall Columner(TStream& s);
		void __fastcall UpdateParams();
		void __fastcall Render();
		friend bool __fastcall operator == (Columner& a,Columner& b);
		friend TStream& __fastcall operator << (TStream& s,Columner *c);
};

//---------------------------------------------------------------------------

class Columners : public TList
{
	private:
	public:
								__fastcall Columners() : TList() {}
								__fastcall Columners(TStream& s);
								__fastcall ~Columners();
		Columner *	__fastcall GetColumner(int i) { return (Columner *) Items[i]; }
		Columner *	__fastcall Find(CLIST_TYPE id);
		void				__fastcall RefreshOrCreate(CLIST_TYPE id); // ���������
		void			  __fastcall ApplyWidth(CLIST_TYPE cl);      // ���������������
		friend TStream& __fastcall operator << (TStream& s,Columners *cs);
};

//---------------------------------------------------------------------------

class Backuper : public StringList
{
	public:
		__fastcall Backuper();
};

//---------------------------------------------------------------------------

extern TReportForm *ReportForm;

//---------------------------------------------------------------------------

#endif
