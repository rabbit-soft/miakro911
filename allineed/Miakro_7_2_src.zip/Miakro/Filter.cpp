#include <vcl\vcl.h>
#pragma hdrstop

#include "Filter.h"

static CtrlSet RabSet,BuildSet,InvertedBoxes;

//---------------------------------------------------------------------------

#pragma link "CSPIN"
#pragma resource "*.dfm"

TFilterForm *FilterForm;

//---------------------------------------------------------------------------

__fastcall Filter::Filter(bool *mo) // ����������� ��� ���������� �����
{
	modify = mo;
	ScanControls(FilterForm);
}

//---------------------------------------------------------------------------

void __stdcall Filter::ScanControls(TComponent *obj,bool set,bool reset,CtrlSet *ctrl)
{
	TComponent *tc;
	CTRLS tag;
	FilterForm->notify++;
	for (int i = 0; i < obj->ComponentCount; i++)
	{
		tc = obj->Components[i];
		if (tc->ComponentCount)
			ScanControls(tc);
		if (tc->Tag)
		{
			tag = CTRLS (tc->Tag - 1);
			if (!ctrl || ctrl->Contains(tag))
			{
				if (tc->ClassNameIs("TCheckBox"))
				{
					if (reset)
						values[tag] = !InvertedBoxes.Contains(tag);
					if (set)
						((TCheckBox *) tc)->Checked = values[tag];
					else
						SetValue(tag,((TCheckBox *) tc)->Checked);
				}
				else if (tc->ClassNameIs("TRadioGroup"))
				{
					if (reset)
						values[tag] = 0;
					if (set)
						((TRadioGroup *) tc)->ItemIndex = values[tag];
					else
						SetValue(tag,((TRadioGroup *) tc)->ItemIndex,false);
				}
				else if (tc->ClassNameIs("TCSpinEdit"))
				{
					if (reset)
						values[tag] = 0;
					if (set)
					{
						if (values[tag])
							((TCSpinEdit *) tc)->Value = values[tag];
						else
							SetValue(tag,((TCSpinEdit *) tc)->Value,false);
					}
					else
						SetValue(tag,(int) ((TCSpinEdit *) tc)->Value,false);
				}
				else if (tc->ClassNameIs("TDateTimePicker"))
				{
					if (reset)
					{
						values[tag] = 0;
						((TDateTimePicker *) tc)->Checked = false;
					}
					else if (set)
					{
						if (values[tag])
						{
							((TDateTimePicker *) tc)->Date = values[tag];
							((TDateTimePicker *) tc)->Checked = true;
						}
						else
						{
							((TDateTimePicker *) tc)->Date = (int) today;
							((TDateTimePicker *) tc)->Checked = false;
						}
					}
					else
						SetValue(tag,(int) ((TDateTimePicker *) tc)->Date,false);
				}
			}
		}
	}
	FilterForm->notify--;
}

//---------------------------------------------------------------------------

__fastcall FilterList::FilterList() : TList()
{
	int count;
	for (count = ALL_ENABLED; count < B_ALL_ENABLED; RabSet << (CTRLS) (count++));
	while (count < MAX_FCONTROLS) BuildSet << (CTRLS) (count++);
	look_at = 0;
	Add(new Filter(&modified));
	FilterForm->notify++;
	Acquire()->Render(); // ������������ � �������� ����������
	FilterForm->notify--;
}

//---------------------------------------------------------------------------

void __fastcall Filter::Render()
{
	FilterForm->notify++;
	ScanControls(FilterForm,true);
	FilterForm->notify--;
}

//---------------------------------------------------------------------------

__fastcall TFilterForm::TFilterForm(TComponent* Owner) : TForm(Owner)
{
	notify = 0;
	InvertedBoxes << USE_FROM_WEIGHT << USE_TILL_WEIGHT;
	filters = new FilterList();
}

//---------------------------------------------------------------------------

void __fastcall TFilterForm::MainSwitchClick(TObject *Sender)
{
	if (notify) return;
	int tag = ((TComponent *) Sender)->Tag; // ��������� � �������
	if (!tag) return;
	notify++;
	int res = ~0;
	if (Sender->ClassNameIs("TCheckBox"))
		res = ((TCheckBox *) Sender)->Checked;
	else if (Sender->ClassNameIs("TRadioGroup"))
		res = ((TRadioGroup *) Sender)->ItemIndex;
	else if (Sender->ClassNameIs("TDateTimePicker"))
		res = ((TDateTimePicker *) Sender)->Checked ? (int) ((TDateTimePicker *) Sender)->Date : 0;
	if (res >= 0)
		filters->Acquire()->SetValue((CTRLS) --tag,res);
	notify--;
}
//---------------------------------------------------------------------------

bool __fastcall Filter::Passed(const Rabbit *r) const
{
	enum { NONE = 1,CRAP,BUTCH };
	enum {          YES = 2    };

	if (!values[ALL_ENABLED]) return true;
	switch (values[WORKS_ENABLED])
	{
		case 1:
			if (!r->GetUnique(PRIMARY) && !r->GetUnique(SECONDARY)) return false;
			break;
		case 2:
			if (r->GetUnique(PRIMARY) || r->GetUnique(SECONDARY)) return false;
	}
	if (values[FROM_AGE] 			 	&& r->GetAge(true) < values[FROM_AGE]
	 || values[TILL_AGE] 			 	&& r->GetAge(true) > values[TILL_AGE]
	 || values[USE_FROM_WEIGHT] && r->GetWeight()  < values[FROM_WEIGHT]
	 || values[USE_TILL_WEIGHT] && r->GetWeight()  > values[TILL_WEIGHT])
		return false;
	switch (r->GetSex())
	{
		case MALE:
			if (!values[MALES_ENABLED]) return false;
			switch (r->GetStatus())
			{
				case BOY:
					if (!values[BOYS_ENABLED]) return false;
					break;
				case KANDIDATE:
					if (!values[CANDIDATES_ENABLED]) return false;
					break;
				case FATHER:
					if (!values[FATHERS_ENABLED]) return false;
					break;
			}
			switch (values[MALES_BAD])
			{
				case  NONE:
					if (r->GetCrap() || r->GetButcher()) return false;
					break;
				case  CRAP:
					if (!r->GetCrap()) return false;
					break;
				case  BUTCH:
					if (!r->GetButcher()) return false;
			}
			break;
		case FEMALE:
			if (!values[FEMALES_ENABLED]) return false;
			switch (r->GetStatus())
			{
				case GIRL:
					if (!values[GIRLS_ENABLED]) return false;
					break;
				case BRIDE:
					if (!values[BRIDES_ENABLED]) return false;
					break;
				case PERVO:
					if (!values[PERVO_ENABLED]) return false;
					break;
				case MOTHER:
					if (!values[MOTHERS_ENABLED]) return false;
			}
			switch (values[FEMALES_BAD])
			{
				case  NONE:
					if (r->GetCrap() || r->GetButcher()) return false;
					break;
				case  CRAP:
					if (!r->GetCrap()) return false;
					break;
				case  BUTCH:
					if (!r->GetButcher()) return false;
			}
			switch (values[SUKROL])
			{
				case  NONE:
					if (r->IsPregnant()) return false;
					break;
				case  YES:
					if (!r->IsPregnant()
					 || values[FROM_SUKROL] && r->GetEvDate(true) < values[FROM_SUKROL]
					 || values[TILL_SUKROL] && r->GetEvDate(true) > values[TILL_SUKROL])
					return false;
			}
			switch (values[KUKU])
			{
				case  NONE:
					if (r->GetEvType() == KUK) return false;
					break;
				case  YES:
					if (r->GetEvType() != KUK) return false;
			}
			switch (values[FAMILY])
			{
				case  NONE:
					if (r->HasFamily()) return false;
					break;
				case  YES:
					if (!r->HasFamily()) return false;
			}
			break;
		default:
			if (!values[NOSEX_ENABLED]) return false;
	}
	return true;
}

//---------------------------------------------------------------------------

void __fastcall TFilterForm::FormClose(TObject *Sender, TCloseAction &Action)
{
	PopulationWin->ShowFilter->Checked = false;
}

//---------------------------------------------------------------------------

void __fastcall TFilterForm::OkClick(TObject *Sender)
{
	PopulationWin->RefreshRabbitListView();
}

//---------------------------------------------------------------------------

void __fastcall TFilterForm::RabFilterResetClick(TObject *)
{
	notify++;
	filters->Acquire()->ScanControls(FilterForm,true,true,&RabSet);
	notify--;
}

//---------------------------------------------------------------------------

void __fastcall TFilterForm::ResetBuildClick(TObject *)
{
	notify++;
	filters->Acquire()->ScanControls(FilterForm,true,true,&BuildSet);
	notify--;
}

//---------------------------------------------------------------------------

bool __fastcall Filter::BuildPassed(const BuildListRecord *blr) const
{
  enum { HAVE_NEST = 1,NO_NEST };
  enum { HAVE_HEATER = 1,NO_HEATER,HEATER_ON,HEATER_OFF };
	if (!values[B_ALL_ENABLED])
    return true;
	MiniFarm *mf = blr->GetMiniFarm();
	bool low = blr->GetLower();
	Tier *ti = mf->GetTier(low);
	char i = blr->GetSection();
	bool busy = ti->IsBusy(i);
	if (!values[B_FREE] && !busy || busy && !values[B_BUSY])
    return false;
	TIER t = ti->GetType();
	bool male = MaleSecs.Contains(t);
	bool female = StdFemaleSecs.Contains(t) || (t == T_COMPLEX || t == T_CABIN) && !i || t == T_JURTA && (bool) i == ti->GetJurtaLink();
  switch (values[B_NESTS])
  {
    case HAVE_NEST:
      if (!ti->GetNest(i))
        return false;
      break;
    case NO_NEST:
      if (!female || ti->GetNest(i))
        return false;
  }
  switch (values[B_HEATERS])
  {
    case HAVE_HEATER:
      if (!ti->GetHeater(i))
        return false;
      break;
    case NO_HEATER:
      if (!female || ti->GetHeater(i))
        return false;
      break;
    case HEATER_ON:
      if (!ti->GetHeaterOn(i))
        return false;
      break;
    case HEATER_OFF:
      if (!ti->GetHeater(i) || ti->GetHeaterOn(i))
        return false;
  }
	if (!values[B_MALE] && male || !values[B_FEMALE] && female || !values[B_OTHER] && !male && !female) return false;
	if (values[B_SELRABBITS])
	{
		if (!busy) return false;
		Rabbit *r;
		TListView *lw = PopulationWin->RabbitList;
		TListItem *li = lw->Selected;
		TItemStates Is;
		unsigned short id = mf->GetId();
		for (Is << isSelected; li; li = lw->GetNextItem(li,sdAll,Is))
		{
			r = (Rabbit *) li->Data;
			if (r->GetWhere() == id && (r->GetTierId() == LOWER_TIER) == low && r->GetArea() == i)
				break;
		}
		if (!li) return false;
	}
	return true;
}

//---------------------------------------------------------------------------

void __fastcall TFilterForm::OkBuildClick(TObject *)
{
	BuildWin->RefreshBuildListView();
}

//---------------------------------------------------------------------------

void __fastcall TFilterForm::RabFilterNameKeyDown(TObject *, WORD &Key,TShiftState Shift)
{
	if (Key != enter) return;
	notify++;
	if (RabFilterName->Text.IsEmpty()) // ������� ������� ������������?
	{
		if (filters->Count > 1)
			filters->Erase();
		else
			RabFilterName->Text = RabFilterName->Items->Strings[0];
	}
	else
	{
		RabFilterName->Text = RabFilterName->Text + " (�����)";
		for (int i = 0,max = RabFilterName->Items->Count; i < max; i++)
			if (!RabFilterName->Text.AnsiCompareIC(RabFilterName->Items->Strings[i]))
			{
				MessageBox(NULL,"������ � ���� ������ ��� ����������!","���������",MB_APPLMODAL|MB_ICONEXCLAMATION|MB_OK);
				notify--;
				return;
			}
		RabFilterName->Items->Add(RabFilterName->Text);
		filters->modified = true;
		filters->look_at = filters->Add(new Filter(*filters->Acquire())); // ����� �������� ������� ��� ����� ������
	}
	notify--;
}

//---------------------------------------------------------------------------

void	__fastcall FilterList::Erase()
{
	if (Count == 1) return;
	delete Acquire();
	Delete(look_at);
	FilterForm->RabFilterName->Items->Delete(look_at);
	if (look_at == Count)
		look_at--;
	FilterForm->RabFilterName->Text = FilterForm->RabFilterName->Items->Strings[look_at];
	modified = true;
	Acquire()->Render();
}

//---------------------------------------------------------------------------

void __fastcall TFilterForm::RabFilterNameChange(TObject *Sender)
{
	if (notify) return;
	filters->modified = true;
	char x = RabFilterName->ItemIndex;
	if (x < 0 || x == filters->look_at)
	{
		if (!RabFilterName->Text.IsEmpty())
			RabFilterName->Items->Strings[filters->look_at] = RabFilterName->Text;
		return;
	}
	notify++;
	RabFilterName->Text = RabFilterName->Items->Strings[filters->look_at = x];
	filters->Acquire()->Render();
	notify--;
}

//---------------------------------------------------------------------------

TStream& operator >> (TStream& s,FilterList *fl)
{
	unsigned short count;

	int x = fl->Count;
	s.ReadBuffer(&fl->look_at,sizeof(fl->look_at));
	for (s.ReadBuffer(&count,sizeof(count)); count--; fl->Add(new Filter(&fl->modified,s)));
	while (x--) { delete fl->GetFilter(0); fl->Delete(0); }
	return s;
}

//---------------------------------------------------------------------------

TStream& operator << (TStream& s,FilterList *fl)
{
	unsigned short max = fl->Count;
	s.WriteBuffer(&fl->look_at,sizeof(fl->look_at));
	s.WriteBuffer(&max,sizeof(max));
	for (int i = 0; i < max; s << fl->GetFilter(i++));
	return s;
}

//---------------------------------------------------------------------------

TStream& operator << (TStream& s,TFilterForm *ff)
{
	s << ff->filters;
	SaveCombo(s,ff->RabFilterName);
	return s;
}

//---------------------------------------------------------------------------

TStream& operator >> (TStream& s,TFilterForm *ff)
{
	s >> ff->filters;
	LoadCombo(s,ff->RabFilterName);
	ff->notify++;
	ff->RabFilterName->Text = ff->RabFilterName->Items->Strings[ff->filters->look_at];
	ff->filters->Acquire()->Render(); // ������������ � �������� ����������
	ff->notify--;
	return s;
}

//---------------------------------------------------------------------------

void __fastcall FilterList::Clear()
{
	FilterForm->notify++;
	for (int i = Count; --i >= 0; delete GetFilter(i));
	TList::Clear();
	look_at = 0;
	Add(new Filter(&modified));
	FilterForm->RabFilterName->Items->Clear();
	FilterForm->RabFilterName->Items->Add("����������");
	FilterForm->RabFilterName->Text = "����������";
	Acquire()->Render(); // ������������ � �������� ����������
	FilterForm->notify--;
}

//---------------------------------------------------------------------------

__fastcall Filter::Filter(bool *mod,TStream& s)
{
	modify = mod;
	memset(&values,0,sizeof(values));
	if (old_file_version || version_2_0 || version_2_2)
	{
		int fake[CONTROLS_1x]; // ��� ������������� � �������� ��������
		MessageBox(NULL,"���������� ������ ����� ����� - ������� �� ����� ���������!","��������������",MB_APPLMODAL|MB_ICONEXCLAMATION|MB_OK);
		if (old_file_version)
			s.ReadBuffer(&fake,CONTROLS_1x * sizeof(int));
		else if (version_2_0)
			s.ReadBuffer(&fake,CONTROLS_2x * sizeof(int));
		else if (version_2_2)
			s.ReadBuffer(&fake,CONTROLS_2_2 * sizeof(int));
		return;
	}
	else if (version_3_0 | version_3_1 || version_3_9 || version_4_2)
		s.ReadBuffer(&values,CONTROLS_3_0 * sizeof(int));
	else
		s.ReadBuffer(&values,sizeof(values));
}

//---------------------------------------------------------------------------

__fastcall Filter::~Filter()
{
}

//---------------------------------------------------------------------------

__fastcall FilterList::~FilterList()
{
	for (int i = Count; --i >= 0; delete GetFilter(i));
	TList::Clear();
}

