#ifndef GetBabiesH
#define GetBabiesH

//---------------------------------------------------------------------------

#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>

#include "Rabbit.h"
#include "Donor.h"
#include <Menus.hpp>

//---------------------------------------------------------------------------

class TGetBabiesForm : public TForm
{
__published:
	TGroupBox *GroupBox1;
	TListView *GetBabyList;
	TPopupMenu *GetBabyPopup;
	TMenuItem *DelItem;
	TMenuItem *Immediate;
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall DelItemClick(TObject *Sender);
	void __fastcall GetBabyListColumnClick(TObject *Sender,TListColumn *Column);
	void __fastcall ImmediateClick(TObject *Sender);
	void __fastcall GetBabyListDblClick(TObject *Sender);
private:
	Donors *donors;
	void __fastcall Mover();
public:
			 __fastcall TGetBabiesForm(TComponent* Owner);
			 __fastcall ~TGetBabiesForm();
	Donors * __fastcall GetDonors() const { return donors; }
	void __fastcall SetDonors(Donors *d) { donors = d; }
	void __fastcall Add(Rabbit *from,unsigned short group_key,Rabbit *to);
	void __fastcall Render();
};

//---------------------------------------------------------------------------

extern PACKAGE TGetBabiesForm *GetBabiesForm;

//---------------------------------------------------------------------------
#endif

