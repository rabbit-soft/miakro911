//---------------------------------------------------------------------------
#ifndef SellBuyRabRepH
#define SellBuyRabRepH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Db.hpp>
#include <DBTables.hpp>
#include <ExtCtrls.hpp>
#include <Qrctrls.hpp>
#include <QuickRpt.hpp>
//---------------------------------------------------------------------------
class TSellBuyRabbitsForm : public TForm
{
__published:	// IDE-managed Components
  TDataSource *DataSource;
  TTable *Table;
private:	// User declarations
public:		// User declarations
  __fastcall TSellBuyRabbitsForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TSellBuyRabbitsForm *SellBuyRabbitsForm;
//---------------------------------------------------------------------------
#endif
