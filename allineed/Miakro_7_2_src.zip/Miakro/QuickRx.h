#ifndef QuickRxH
#define QuickRxH

//---------------------------------------------------------------------------

#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Qrctrls.hpp>
#include <quickrpt.hpp>
#include <Db.hpp>
#include <DBTables.hpp>
#include <QuickRpt.hpp>

//---------------------------------------------------------------------------

class TButcherReport : public TForm
{
__published:
	TQuickRep *Report;
	TTable *Table;
	TDataSource *Source_1;
	TQRBand *QRBand3;
	TQRSysData *QRSysData2;
	TQRSysData *QRSysData1;
	TQRSysData *QRSysData3;
	TQRSysData *QRSysData4;
	TQRBand *QRBand2;
	TQRDBText *QRDBText1;
	TQRDBText *QRDBText2;
	TQRDBText *QRDBText3;
	TQRDBText *QRDBText4;
	TQRDBText *QRDBText5;
	TQRDBText *QRDBText6;
	TQRDBText *QRDBText7;
	TQRDBText *QRDBText8;
	TQRDBText *QRDBText9;
	TQRBand *QRBand1;
	TQRLabel *Title;
	TQRBand *QRBand4;
	TQRLabel *Summary;
	TQRBand *QRBand5;
	TQRLabel *QRLabel1;
	TQRLabel *QRLabel2;
	TQRLabel *QRLabel3;
	TQRLabel *QRLabel4;
	TQRLabel *QRLabel5;
	TQRLabel *QRLabel6;
	TQRLabel *QRLabel7;
	TQRLabel *QRLabel8;
	TQRLabel *QRLabel9;
private:
public:
	__fastcall TButcherReport(TComponent* Owner);
};

//---------------------------------------------------------------------------

extern PACKAGE TButcherReport *ButcherReport;

//---------------------------------------------------------------------------

#endif

