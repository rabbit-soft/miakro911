#include <vcl.h>
#pragma hdrsto

#include "Archive.h"
#include "Params.h"
#include "ReportWin.h"
#include "ArcRep.h"
#include "About.h"
#include "ArcRab.h"
#include "Sorting.h"

const char archive_file[] = "archive.miz";

enum { W_DATE,W_PLUS,W_WORK,W_ADDRESS,W_NAME,W_AGE,W_PARTNER,W_ADDR_2,W_NOTES,W_MAX };
enum { R_DATE,R_NAME,R_SEX,R_AGE,R_BREED,R_CLASS,R_ADDR,R_NOTES,R_MAX };

//---------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"

TArchiveForm *ArchiveForm;

static char last_column[MAX_A_PAGES];

//---------------------------------------------------------------------------

static int __stdcall DateSorter(long a,long b,long)
{
	return (int) StrToDate(((TListItem *) b)->Caption) - (int) StrToDate(((TListItem *) a)->Caption);
}

//---------------------------------------------------------------------------

__fastcall ArcWork::ArcWork(TListItem *li)
{
	cols = new StringList();
	cols->AddStrings(li);
}

//---------------------------------------------------------------------------

__fastcall ArcWork::ArcWork(TStream& s)
{
	cols = new StringList(s);
}

//---------------------------------------------------------------------------

__fastcall ArcWork::~ArcWork()
{
	delete cols;
}

//---------------------------------------------------------------------------

void __fastcall ArcWork::Render(TListItem *li,const char *date)
{
  li->Data = this;
	li->Caption = date;
	for (int i = 0; i < cols->Count; li->SubItems->Add(cols->GetString(i++)));
}

//---------------------------------------------------------------------------

TStream& __fastcall operator << (TStream& s,ArcWork *aw)
{
	s << aw->cols;
	return s;
}

//---------------------------------------------------------------------------

__fastcall ArcPlan::ArcPlan()
{
	date = (int) ZooForm->ZooDater->Date;
	works = new TList;
}

//---------------------------------------------------------------------------

__fastcall ArcPlan::ArcPlan(TStream& s)
{
	s.ReadBuffer(&date,sizeof(date));
	works = new TList();
	int max;
	s.ReadBuffer(&max,sizeof(max));
	for (works->Capacity = max; max--; works->Add(new ArcWork(s)));
}

//---------------------------------------------------------------------------

__fastcall ArcPlan::~ArcPlan()
{
	for (int i = 0; i < works->Count; delete (ArcWork *) works->Items[i++]);
	delete works;
}

//---------------------------------------------------------------------------

TStream& __fastcall operator << (TStream& s,ArcPlan *ap)
{
	s.WriteBuffer(&ap->date,sizeof(ap->date));
	int max = ap->works->Count;
	s.WriteBuffer(&max,sizeof(max));
	for (int i = 0; i < max; s << (ArcWork *) ap->works->Items[i++]);
	return s;
}

//---------------------------------------------------------------------------

__fastcall TArchiveForm::TArchiveForm(TComponent* Owner) : TForm(Owner)
{
//	static int tp[MAX_A_PAGES][W_MAX] =
//	{
//		{ as_dat,as_mix,as_txt,as_mix,as_txt,as_mix,as_txt,as_txt,as_txt },
//		{ as_dat,as_txt,as_sex,as_mix,as_txt,as_cla,as_mix,as_txt }
//	};
	RabbitList->Tag = (int) new Srt(RabbitList);
	PlansList->Tag = (int) new Srt(PlansList);
	dead = new ListRab(true);
	this_date = notify = 0;
	page = (Y_TYPE) ArchivePages->ActivePage->PageIndex;
	needs_refresh = true;
	plans = new TList;
	listviews[ZOO_ARC] = PlansList;
	listviews[RAB_ARC] = RabbitList;
	TFileStream *s = NULL;
	if (version_3_0 || version_3_1 || version_3_9)
	{
		try { s = new TFileStream(archive_file,fmOpenRead); }
		catch(...) { return; }
		int max;
		ArcPlan *ap;
		s->ReadBuffer(&max,sizeof(max));
		try
		{
			while(max--)
			{
				ap = new ArcPlan(*s);
				if (ap->GetDate() >= today - ParamForm->Config.arctime)
					plans->Add(ap);
				else
					delete ap;
			}
		}
		catch(...) {}
  	if (s) delete s;
	}
}

//---------------------------------------------------------------------------

__fastcall TArchiveForm::~TArchiveForm()
{
	notify++;
	ClearAll();
	delete plans;
	delete dead;
	delete (Srt *) RabbitList->Tag;
	delete (Srt *) PlansList->Tag;
}

//---------------------------------------------------------------------------

void __fastcall TArchiveForm::AddJob(TListItem *li)
{
	ArcPlan *ap = FindArcPlan((int) ZooForm->ZooDater->Date);
	if (!ap)
	{
		plans->Add(ap = new ArcPlan());
		Archives->Items->BeginUpdate();
		Archives->Items->Add()->Caption = DateToStr((int) ZooForm->ZooDater->Date);
		Archives->Items->EndUpdate();
	}
	ap->AddJob(li)->Render(PlansList->Items->Add(),DateToStr((int) ZooForm->ZooDater->Date).c_str());
 	((Srt *) PlansList->Tag)->Process();
}

//---------------------------------------------------------------------------

ArcPlan * __fastcall TArchiveForm::FindArcPlan(unsigned short date)
{
	ArcPlan *ap;
	for (int i = 0; i < plans->Count; i++)
	{
		ap = (ArcPlan *) plans->Items[i];
		if (ap->GetDate() == date)
			return ap;
	}
	return NULL;
}

//---------------------------------------------------------------------------

void __fastcall ArcPlan::Render()
{
	if (ArchiveForm->this_date && date != ArchiveForm->this_date || ArchiveForm->From->Checked && (int) date < (int) ArchiveForm->From->Date || ArchiveForm->Till->Checked && (int) date > (int) ArchiveForm->Till->Date)
	{
		AboutForm->Advance(works->Count);
		return;
	}
	ArcWork *aw;
	AnsiString d(DateToStr(date));
	char buf[100];
	if (ArchiveForm->Name->Text.IsEmpty())
		*buf = '\0';
	else
		strcpy(buf,ArchiveForm->Name->Text.Trim().c_str());
	const char *p,*px;
	for (int i = 0; i < works->Count; i++)
	{
		AboutForm->Advance();
		aw = (ArcWork *) works->Items[i];
		if (*buf)
		{
			if (rusisdigit(*buf)) 						// ���������?
			{
				unsigned short num = atoi(p = buf);
				while (rusisdigit(*++p));
				px = aw->cols->GetString(W_ADDRESS);
				if (atoi(px) != num) continue;
				if (*p)
				{
					while (rusisdigit(*++px));
					if (strncmp(p,px,strlen(p))) continue;
				}
			}
			else
			{
				int c = 0;
				for (p = aw->cols->GetString(W_NAME); isdigit(*p) || *p == '+' || isspace(*p); p++);
				for (px = p; isrus(*px++); c++);
				if (!c || russtrnicmp(buf,p,c)) continue;
			}
		}
		aw->Render(ArchiveForm->PlansList->Items->Add(),d.c_str());
	}
}

//---------------------------------------------------------------------------

void __fastcall TArchiveForm::Render()
{
	TWaitCursor Wait;
	AboutForm->Reset("������������� ����� ������������...",OverallItems());
	needs_refresh = false;
	Archives->Items->BeginUpdate();
	Archives->Items->Clear();
	PlansList->Items->BeginUpdate();
	PlansList->Items->Clear();
	ArcPlan *ap;
	for (int i = 0; i < plans->Count; i++)
	{
		ap = (ArcPlan *) plans->Items[i];
		Archives->Items->Add()->Caption = DateToStr(ap->GetDate());
		ap->Render();
	}
	((Srt *) PlansList->Tag)->Process();
	PlansList->Items->EndUpdate();
	Archives->Items->EndUpdate();
	AboutForm->Reset();
  RenderDead();
}

//---------------------------------------------------------------------------

void __fastcall TArchiveForm::FormShow(TObject *)
{
	if (needs_refresh)
		Render();
}

//---------------------------------------------------------------------------

void __fastcall TArchiveForm::FormClose(TObject *,TCloseAction &Action)
{
	PopulationWin->ArcWinView->Checked = false;
}

//---------------------------------------------------------------------------

void __fastcall TArchiveForm::RefreshClick(TObject *)
{
	Archives->Selected = NULL;
	this_date = 0;
	Render();
}

//---------------------------------------------------------------------------

void __fastcall TArchiveForm::ArchivesDblClick(TObject *)
{
	this_date = StrToDate(Archives->Selected->Caption);
	Render();
}

//---------------------------------------------------------------------------

void __fastcall TArchiveForm::PlansListColumnClick(TObject *Sender,TListColumn *Column)
{
	((Srt *) ((TComponent *) Sender)->Tag)->Process(Column);
}

//---------------------------------------------------------------------------

int __fastcall TArchiveForm::OverallItems()
{
	int x = 0;
	ArcPlan *ap;
	for (int i = 0; i < plans->Count; i++)
	{
		ap = (ArcPlan *) plans->Items[i];
		x += ap->GetWorks()->Count;
	}
	return x;
}

//---------------------------------------------------------------------------

void __fastcall TArchiveForm::PreviewOrPrint(bool print)
{
	String foot("����� ");
  switch (page)
  {
    case ZOO_ARC:
    {
    	int x = PlansList->Items->Count;
	    ReportForm->reports->Prepare(Q_ARCHIVE,PlansList,String("����� ������������"),foot + x + ' ' + WorkDecl(x));
      if (print)
        ArcRepForm->Report->Print();
	    else
	      ArcRepForm->Report->Preview();
      break;
    }
    case RAB_ARC:
	    ReportForm->reports->Prepare(Q_ARCRAB,RabbitList,String("����� ���������"),foot + RabDecl(RabbitList->Items->Count));
      if (print)
        ArcRabForm->Report->Print();
	    else
	      ArcRabForm->Report->Preview();
  }
}

//---------------------------------------------------------------------------

void __fastcall TArchiveForm::PreviewClick(TObject *)
{
	PreviewOrPrint(false);
}

//---------------------------------------------------------------------------

void __fastcall TArchiveForm::PrintItClick(TObject *)
{
	PreviewOrPrint(true);
}

//---------------------------------------------------------------------------

void __fastcall TArchiveForm::DeleteClick(TObject *)
{
  TListView *lw = listviews[page];
	if (!(lw->SelCount)) return;
	TListItems *lia = lw->Items;
	TList *l = new TList;
	TItemStates Is;
	Is << isSelected;
	TListItem *li = lw->Selected;
	do
		l->Add(li);
	while (li = lw->GetNextItem(li,sdAll,Is));
	lia->BeginUpdate();
  RabName *rn;
  Rabbit *r;
  unsigned short name_key;
  ArcPlan *ap;
  ArcWork *aw;
  int j;
	for (int i = 0; i < l->Count; i++)
  {
    li = (TListItem *) l->Items[i];
    switch (page)
    {
      case ZOO_ARC:
        aw = (ArcWork *) li->Data;
        for (j = 0; j < plans->Count; j++)
        {
          ap = (ArcPlan *) plans->Items[j];
          if (ap->GetWorks()->Remove(aw) >= 0)
          {
            delete aw;
            break;
          }
        }
        if (j == plans->Count)
	        PopulationWin->Terminator("������ �������������� ������!");
        break;
      case RAB_ARC:
        r = (Rabbit *) li->Data;
        dead->Remove(r);
        if (name_key = r->GetNameKey())
        {
    		  if (rn = NameForm->FindRabName(name_key,r->GetSex()))
			      rn->SetLock();
		      else
			      PopulationWin->Terminator("��� �����! #4");
        }
    }
    delete li;
  }
	lia->EndUpdate();
	delete l;
}

//---------------------------------------------------------------------------

void __fastcall TArchiveForm::ArchivePagesChange(TObject *)
{
  if (notify) return;
  page = (Y_TYPE) ArchivePages->ActivePage->PageIndex;
}

//---------------------------------------------------------------------------

void __fastcall TArchiveForm::ClearAll()
{
  RabbitList->Items->BeginUpdate();
  PlansList->Items->BeginUpdate();
  Archives->Items->BeginUpdate();
  RabbitList->Items->Clear();
  for (int i = 0; i < plans->Count; delete (ArcPlan *) plans->Items[i++]);
  plans->Clear();
  PlansList->Items->Clear();
  Archives->Items->Clear();
  Archives->Items->EndUpdate();
  RabbitList->Items->EndUpdate();
  PlansList->Items->EndUpdate();
}

//---------------------------------------------------------------------------

TStream& __fastcall operator >> (TStream& s,TArchiveForm *af)
{
  af->notify++;
  int max;
  ArcPlan *ap;
  s.ReadBuffer(&max,sizeof(max));
	while(max--)
  {
    ap = new ArcPlan(s);
    if (ap->GetDate() >= today - ParamForm->Config.arctime)
      af->plans->Add(ap);
    else
      delete ap;
  }
	if (old_file_version || version_2_0 || version_2_2 || version_3_0 || version_3_1 || version_3_9 || version_4_2 || version_4_3 || version_5_0 || version_5_1)
  {
    s >> af->RabbitList;
    af->dead->Clear();
    max = 0;
    while (max < af->RabbitList->Items->Count)
      af->dead->Add(CreateRabbit(af->RabbitList->Items->Item[max++]));
  }
  else
    s >> af->dead;
  af->notify--;
  return s;
}

//---------------------------------------------------------------------------

TStream& __fastcall operator << (TStream& s, TArchiveForm *af)
{
	int max = af->plans->Count;
	s.WriteBuffer(&max,sizeof(max));
	for (int i = 0; i < max; s << (ArcPlan *) af->plans->Items[i++]);
  s << af->dead;
  return s;
}
//---------------------------------------------------------------------------

void __fastcall TArchiveForm::RabbitListChange(TObject *,TListItem *Item,TItemChange Change)
{
  if (notify || !Item || !Item->Selected) return;
  Rabbit *r = (Rabbit *) Item->Data;
  if (r && r->GetNotes())
    NewNotes->Text = r->GetNotes();
  else
    NewNotes->Clear();  
}

//---------------------------------------------------------------------------

void __fastcall TArchiveForm::NewNotesKeyUp(TObject *, WORD &Key,TShiftState Shift)
{
  if (Key != 13) return;
  TListItem *li = RabbitList->Selected;
  if (!li) return;
  ((Rabbit *) li->Data)->SetNotes(NewNotes->Text.Trim().c_str());
	RenderDead();
}

//---------------------------------------------------------------------------

void __fastcall TArchiveForm::RenderDead()
{
	RabbitList->Items->BeginUpdate();
	RabbitList->Items->Clear();
	TListItem *li;
	Rabbit *r;
	TDateTime Dt;
	for (int i = 0; i < dead->Count; i++)
	{
		li = RabbitList->Items->Add();
		li->ImageIndex = -2;
		r = dead->GetRabbit(i);
		li->Data = r;
		Dt = (int) r->GetZone(); // �� ����� ����, ���� ������
		li->Caption = DateToStr(Dt);
		li->SubItems->Add(r->GetFullName());
		li->SubItems->Add(r->GetSexChar());
		if (r->GetAge(true))
			li->SubItems->Add(int(r->GetZone() - r->GetAge(true)));
		else
			li->SubItems->Add(' ');
		li->SubItems->Add(ParamForm->GetBreedName(r->GetBreed(),AS_TAB));
		li->SubItems->Add(r->GetClassName(AS_TAB));
		if (r->GetWhere())
			li->SubItems->Add(r->GetAddressName(true,true)); // ������ �������� ������
		else
			li->SubItems->Add(' ');
		if (r->GetNotes())
			li->SubItems->Add(r->GetNotes());
	}
	((Srt *) RabbitList->Tag)->Process();
	RabbitList->Items->EndUpdate();
}

