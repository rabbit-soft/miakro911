#include <vcl.h>
#pragma hdrstop

#include "Bone.h"
#include "Params.h"
#include "BoneRep.h"
#include "ReportWin.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"

TBoneForm *BoneForm;

const char * const bon_names[MAX_BON] = { "���","III","II","I","�����" };
static const BON bx[MAX_BON] = { B_UNKNOWN,B_ELITE,B_FIRST,B_SECOND,B_THIRD };
static const char * const automan[2] =
{
  "�������������� ����������:",
  "������������� ����������:"
};

//---------------------------------------------------------------------------

__fastcall TBoneForm::TBoneForm(TComponent* Owner) : TForm(Owner)
{
  notify = 0;
  rabbit = NULL;
}

//---------------------------------------------------------------------------

void __fastcall TBoneForm::ComboChange(TObject *Sender)
{
  if (!rabbit || notify) return;
  BON b = bx[((TComboBox *) Sender)->ItemIndex];
  switch (((TComponent *) Sender)->Tag)
  {
    case 0:
      CurBon.SetWeight(b);
      break;
    case 1:
      CurBon.SetBody(b);
      break;
    case 2:
      CurBon.SetHair(b);
      break;
    case 3:
      CurBon.SetColor(b);
  }
  BoneLabel->Caption = bon_names[CurBon.Calc()];
  CurBon.SetManual(true);
  ClassLabel->Caption = automan[true];
}

//---------------------------------------------------------------------------

void __fastcall TBoneForm::FormShow(TObject *)
{
  if (!rabbit) return;
  CurBon = rabbit->Bon;
  notify++;
  BoneLabel->Caption = bon_names[rabbit->CalcBon()];
  Weight->ItemIndex = bx[rabbit->GetBonWeight()];
  Body->ItemIndex = bx[rabbit->GetBonBody()];
  Hair->ItemIndex = bx[rabbit->GetBonHair()];
  Color->ItemIndex = bx[rabbit->GetBonColor()];
  ClassLabel->Caption = automan[rabbit->GetBonManual()];
  notify--;
}

//---------------------------------------------------------------------------


