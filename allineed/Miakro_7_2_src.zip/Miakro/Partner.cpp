#include <vcl\vcl.h>
#pragma hdrstop

#include "Partner.h"

//---------------------------------------------------------------------------

#pragma resource "*.dfm"
TPartnerForm *PartnerForm;

//---------------------------------------------------------------------------

__fastcall TPartnerForm::TPartnerForm(TComponent* Owner) : TForm(Owner)
{
}

//---------------------------------------------------------------------------