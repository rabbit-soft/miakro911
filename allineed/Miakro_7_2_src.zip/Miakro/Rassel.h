#ifndef RasselH
#define RasselH

//---------------------------------------------------------------------------

#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>

#include "Rabbit.h"

//---------------------------------------------------------------------------
class TRasselForm : public TForm
{
__published:
	TListView *RasselList;
	void __fastcall RasselListDblClick(TObject *Sender);
private:
	TListView *cur_list;
public:
	ListRab *list;
			 __fastcall TRasselForm(TComponent* Owner);
	void __fastcall Render(TListView *lw);
};

//---------------------------------------------------------------------------

extern PACKAGE TRasselForm *RasselForm;

#endif

