#ifndef UndoH
#define UndoH

#include <vcl\Classes.hpp>

class ListRab;
class ListBuild;

enum U_TYPE { U_RABBITS,U_YOUNGS,U_BUILDS,U_NAMES,U_BREEDS,U_ZONES,U_ZOO,U_PARAMS,U_ZOO_ZRC,U_MONEY,U_ARCLOST,U_MAX };
enum U_GROUP { G_RABS_BUILDS,G_MAX };

//---------------------------------------------------------------------------

class Undo
{
  protected:
    const char *title;
  public:
            __fastcall Undo() { }
    virtual __fastcall ~Undo() { }
    virtual void __fastcall Apply() = 0;   // �������� ���������
    const char *Title() { return title; }
};

//---------------------------------------------------------------------------

class U_RabPassport : public Undo
{
  private:
    ListRab   *rabbits;
    ListBuild *builds;
  public:
                __fastcall U_RabPassport();
                __fastcall ~U_RabPassport();
    void        __fastcall Apply();
    ListRab *   __fastcall GetRabbits()  { return rabbits; }
    ListBuild * __fastcall GetBuilds() { return builds; }
};


//---------------------------------------------------------------------------

class UndoList : public TList
{
  private:
    bool __fastcall DeleteUndo();
  public:
    __fastcall UndoList() : TList() {}
    __fastcall ~UndoList();
    Undo * __fastcall GetUndo() { return Count ? (Undo *) Items[0] : NULL; }
    void   __fastcall Store(U_GROUP ug); // ��������� ������������ ��� Undo
    void   __fastcall Retrieve(); // ������������ ������������ ��� Undo
};

#endif
