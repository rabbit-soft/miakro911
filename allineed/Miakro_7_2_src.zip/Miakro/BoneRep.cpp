#include <vcl.h>
#pragma hdrstop

#include "BoneRep.h"
#include "Bone.h"
#include "Params.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"
TBoneReport *BoneReport;

//---------------------------------------------------------------------------

__fastcall TBoneReport::TBoneReport(TComponent* Owner) : TForm(Owner)
{
  Report->Page->Orientation = poLandscape;
}

//---------------------------------------------------------------------------

void __fastcall TBoneReport::RenderRabbit(Rabbit *r)
{
  char buf[100];
  TListItem *li = Fake->Items->Add();
	li->ImageIndex = -2;
	ostrstream s(buf,sizeof(buf));
  bool x = ParamForm->Config.double_sur;
  ParamForm->Config.double_sur = true;
  r->NameAndSurname(s);
  ParamForm->Config.double_sur = x;
  if (r->GetGroup() > 1)
    s << " [" << (int) r->GetGroup() << ']';
  s << ends;
  li->Caption = buf;
  li->SubItems->Add(r->GetClassName(AS_FULL));
  li->SubItems->Add(ParamForm->GetZoneName(r->GetZone(),AS_FULL,true));
  li->SubItems->Add(r->GetAddressName(false,true));
  li->SubItems->Add(r->GetSexChar());
  TDateTime D((int) r->GetAge(true));
  li->SubItems->Add(DateToStr(D));
  li->SubItems->Add(bon_names[r->GetBonWeight()]);
  li->SubItems->Add(bon_names[r->GetBonBody()]);
  li->SubItems->Add(bon_names[r->GetBonHair()]);
  li->SubItems->Add(bon_names[r->GetBonColor()]);
}

//---------------------------------------------------------------------------

int __fastcall TBoneReport::RenderRabbitList(TListView *lw)
{
  TListItem *li = lw->Selected;
  if (!li) return 0;
  FarmId->Caption = PopulationWin->FarmId;
 	TItemStates Is;
	Is << isSelected;
	Fake->Items->BeginUpdate();
  Fake->Items->Clear();
  Rabbit *r;
  int count = 0;
	do
  {
    r = (Rabbit *) li->Data;
    count += r->GetGroup();
		RenderRabbit(r);
  }
	while (li = lw->GetNextItem(li,sdAll,Is));
	Fake->Items->EndUpdate();
  return count;
}
