#include <vcl.h>
#pragma hdrstop

#include "UsedFeedRep.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"
TUsedFeedRepForm *UsedFeedRepForm;

//---------------------------------------------------------------------------

__fastcall TUsedFeedRepForm::TUsedFeedRepForm(TComponent* Owner) : TForm(Owner)
{
}

//---------------------------------------------------------------------------
