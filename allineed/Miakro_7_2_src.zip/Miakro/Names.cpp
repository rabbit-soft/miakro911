#include <vcl\vcl.h>
#pragma hdrstop

#include "Miakro.h"
#include "Names.h"
#include "Params.h"
#include "PassportForm.h"
#include "Young.h"
#include "ReportWin.h"
#include "About.h"
#include "Bone.h"
#include "Sorting.h"

bool RabName::import;

//---------------------------------------------------------------------------

#pragma resource "*.dfm"

TNameForm *NameForm;

enum { N_NAME,N_SUR,N_SEX,N_STATUS,N_MAXCOLS };

const unsigned short n_free = 0;
const unsigned short n_used = 65535;

unsigned short RabName::last_key = START_KEY;
unsigned short RabName::last_sur_key = VACANT;
unsigned short RabName::base_date = 0;

//---------------------------------------------------------------------------

void __fastcall RabName::SetLock()
{
	key = LOCK_NAMES;
	RabNameList *nl = FindMe();
	if (nl)
		NameForm->filter = F_IMPOSSIBLE; // ����� refresh
}

//---------------------------------------------------------------------------

__fastcall TNameForm::TNameForm(TComponent* Owner): TForm(Owner)
{
	filter = F_IMPOSSIBLE; // ����� refresh
	notify = 0;
	cookie = edit = NULL;
	vacant_only = sur_changed = false;
	male_names = new RabNameList(false);
	female_names = new RabNameList(true);
	NameView->Tag = (int) new Srt(NameView);
}

//---------------------------------------------------------------------------

__fastcall TNameForm::~TNameForm()
{
	delete male_names;
	delete female_names;
	delete (Srt *) NameView->Tag;
}
//---------------------------------------------------------------------------

__fastcall RabName::RabName(const char *nam,const char *sur) // ������� �����������
{
	char buf[40];
	key = sur_key = VACANT;
	use_count = 0;
	name = strdup(russtrlwr(trim(strcpy(buf,(char *) nam))));
	*name = rustoupper(*name);
	*surname = rustoupper(*(surname = strdup(russtrlwr(trim(strcpy(buf,(char *) sur))))));
}

//---------------------------------------------------------------------------

__fastcall RabName::RabName(TStream& ifs) // ����������� �� ������
{
	use_count = 0;
	ifs.ReadBuffer(&key,sizeof(key));
	if (old_file_version)
	{
		if (key == n_used)
			key = VACANT;
		sur_key = VACANT;
	}
	else
	{
		if (key > RabName::last_key)
			RabName::last_key = key;
		ifs.ReadBuffer(&sur_key,sizeof(sur_key));
		if (sur_key > RabName::last_sur_key)
			RabName::last_sur_key = sur_key;
	}
	name = GetStr(ifs);
	surname = GetStr(ifs);
}

//---------------------------------------------------------------------------

TStream& operator << (TStream& s,RabName *n)
{
	s.WriteBuffer(&n->key,sizeof(n->key));
	s.WriteBuffer(&n->sur_key,sizeof(n->sur_key));
	PutStr(s,n->name);
	PutStr(s,n->surname);
	return s;
}

//---------------------------------------------------------------------------

RabName * __fastcall RabNameList::FindSurname(const char *sur)
{
	RabName *n;

	for (int i = 0; i < Count; i++)
		if (!russtricmp((n = (RabName *) Items[i])->GetSurname(),sur))
		{
			found_index = i;
			return n;
		}
	return NULL;
}

//---------------------------------------------------------------------------

RabName * __fastcall RabNameList::Find(const char *nam)
{
	RabName *n;

	for (int i = 0; i < Count; i++)
		if (!russtricmp((n = (RabName *) Items[i])->GetName(),nam))
		{
			found_index = i;
			return n;
		}
	return NULL;
}

//---------------------------------------------------------------------------

void	__fastcall RabName::Render(bool female) const // ����������� � ������
{
	if (!IsVacant() && NameForm->vacant_only) return;
	TListItem *li = NameForm->NameView->Items->Add();
	li->ImageIndex = -2;
	li->Data = (void *) this;
#ifdef SHOW_NAME_KEYS
  li->Caption = String(name) + ' ' + (int) key;
	li->SubItems->Add(String(surname) + ' ' + (int) sur_key);
#else
	li->Caption = name;
	li->SubItems->Add(surname);
#endif
	li->SubItems->Add(female ? '�' : '�');
	AnsiString x;
	if (IsVacant())
		x = "��������";
	else if (IsUsed())
		x = "������";
	else
		x = int(key);
	li->SubItems->Add(x);
}
																				
//---------------------------------------------------------------------------

void __fastcall TNameForm::RefreshNames()
{
	notify++;
  TWaitCursor Wait;
	NameView->Items->BeginUpdate();
	NameView->Items->Clear();
	if ((PopulationWin->loading || filter != ONLY_GIRLS) && male_names)
		male_names->Render();
	if ((PopulationWin->loading || filter != ONLY_BOYS) && female_names)
		female_names->Render();
	((Srt *) NameView->Tag)->Process();
	NameView->Items->EndUpdate();
	notify--;
}

//---------------------------------------------------------------------------

void __fastcall TNameForm::NameChange(TObject *)
{
	static char add_len;

	if (notify) return;
	notify++;
	Ok->Enabled = false;
	AssignName->Enabled = false;
	Name->Text = Name->Text.Trim();
	if (Name->Text.IsEmpty())
	{
		add_len = 0;
		Name->Clear();
		Sur->Clear();
		notify--;
		return;
	}
	char len = Name->Text.Length();
  if (!len)
  {
    notify--;
    return;
  }
  for (char i = 1; i <= len; i++)
    if (!isrus(Name->Text[i]) || isspace(Name->Text[i]))
    {
  		MessageBox(NULL,"��� ������ �������� ������ �� ������� ����!","������",MB_APPLMODAL|MB_ICONEXCLAMATION|MB_OK);
      if (i > 1)
      {
        Name->Text = Name->Text.SubString(1,i - 1);
        break;
      }
      Name->Clear();
      notify--;
      return;
    }
	if (len < 2)
	{
		Name->Text = rustoupper(Name->Text[1]);
		add_len = 0;
		Sur->Clear();
		notify--;
		Name->SelStart = 1;
		return;
	}
	Name->Text = String(Name->Text[1]) + String(russtrlwr(Name->Text.SubString(2,len - 1).c_str()));
	Name->SelStart = len;
	char *p = strdup(Name->Text.c_str());
	char *su = (char *) MakeSurname(p,len);
	Sur->Text = su;
	free(p);
	free(su);
	notify--;
	Ok->Enabled = !Name->Text.IsEmpty() && !Sur->Text.IsEmpty() && Sex->ItemIndex >= 0;
}

//---------------------------------------------------------------------------

const char * __fastcall TNameForm::MakeSurname(const char *name,char len)
{
	char * const buf = (char *) malloc(40);
	strrev(strcpy(buf,name));
	String Add;
	if (isvowel(*buf))
	{
		if (*buf != '�')
		{
			len--;
			if (buf[1] == '�' && strchr("�",buf[2])) // ������
				len--;											   				 // ������
		}
		Add = buf[1] == '�' ? "��" : "��";
	}
	else if (isconsonant(*buf))
		Add = strchr("����",*buf) ? "��" : "��";
	else
	{
		--len;
		if (buf[1] == '�' && strchr("���������������",buf[2]))
		{
			len--;
			Add = "���";
		}
		else if (buf[1] == '�') // -��
		{
			len--;
			Add = "��";
		}
    else if (*buf == '�')
      Add = "��";
		else
			Add = *buf == '�' && Sex->ItemIndex ? "��" : "��";
	}
	strncpy(buf,name,len);
	strcpy(buf + len,Add.c_str());
	return buf;
}

//---------------------------------------------------------------------------

void __fastcall TNameForm::FormShow(TObject *)
{
	notify++;
	Ok->Enabled = false;
	AssignName->Enabled = NameView->Selected && vacant_only;
	sur_changed = false;
	Name->Clear();
	Sur->Clear();
	cookie = NULL;
	edit = NULL;
	notify--;
}

//---------------------------------------------------------------------------

void __fastcall TNameForm::OkClick(TObject *)
{
	char buf[100];

	Ok->Enabled = false;
	Name->Text = Name->Text.Trim();
	Sur->Text = Sur->Text.Trim();
	if (Name->Text.IsEmpty())
	{
		MessageBox(NULL,"����������� ��� �������!","��������",MB_APPLMODAL|MB_ICONEXCLAMATION|MB_OK);
		return;
	}
	if (Sur->Text.IsEmpty())
	{
		MessageBox(NULL,"����������� ������� �������!","��������",MB_APPLMODAL|MB_ICONEXCLAMATION|MB_OK);
		return;
	}
	if (edit)
	{
		russtrlwr(trim(strcpy(buf,Name->Text.c_str())));
		*buf = rustoupper(*buf);
		edit->SetName(buf);
		russtrlwr(trim(strcpy(buf,Sur->Text.c_str())));
		*buf = rustoupper(*buf);
		edit->SetSurname(buf);
		PopulationWin->ListUpdated();
		YoungForm->Render();
	}
	else
	{
		RabNameList *nl = Sex->ItemIndex ? female_names : male_names;
		nl->Add(new RabName(Name->Text.c_str(),Sur->Text.c_str()));
	}
	notify++;
	Name->Clear();
	Sur->Clear();
	notify--;
	sur_changed = false;
	RefreshNames();
}

//---------------------------------------------------------------------------

void __fastcall TNameForm::SexClick(TObject *)
{
	Name->Text = Name->Text.Trim();
  Sur->Text = Sur->Text.Trim();
	Ok->Enabled = !Name->Text.IsEmpty() && !Sur->Text.IsEmpty();
}

//---------------------------------------------------------------------------

void	__fastcall RabNameList::AdjustLockDates() // ��������� �� ���������� ��� � ����� ��, ���� ���� �����
{
	RabName *rn;
	for (int i = 0; i < Count; i++)
		if ((rn = Get(i))->IsLocked())
			rn->DecreaseLock();
}

//---------------------------------------------------------------------------

void	__fastcall RabNameList::UnlockAll() // ��������� �� ���������� ��� � ����� ��, ���� ���� �����
{
	RabName *rn;
	for (int i = 0; i < Count; i++)
		if ((rn = Get(i))->IsLocked())
			rn->SetFree();
}

//---------------------------------------------------------------------------

void __fastcall TNameForm::NameViewDblClick(TObject *)
{
	TListItem *li = NameView->Selected;
	if (!li) return;
	edit = (RabName *) li->Data;
	Name->Text = edit->GetName();
	Sur->Text = edit->GetSurname();
	Sex->ItemIndex = edit->FindMe() == female_names;
	Ok->Enabled = false;
}

//---------------------------------------------------------------------------

void __fastcall TNameForm::NameViewChange(TObject *Sender, TListItem *Item, TItemChange Change)
{
	if (notify) return;
	notify++;
	if (edit)
	{
		edit = NULL;
		Name->Clear();
		Sur->Clear();
		notify--;
		return;
	}
	AssignName->Enabled = Item->Selected && (vacant_only || Sex->Enabled == false && Passport->AssignType->ItemIndex > 0); // ������������� �������, ���� ���
	notify--;
}

//---------------------------------------------------------------------------

RabNameList * __fastcall RabName::FindMe() const
{
	if (NameForm->male_names->Find(GetName())) return NameForm->male_names;
	if (NameForm->female_names->Find(GetName())) return NameForm->female_names;
	return NULL;
}

//---------------------------------------------------------------------------

bool __fastcall RabName::GetSex() const
{
	return FindMe() == NameForm->female_names;
}

//---------------------------------------------------------------------------

void __fastcall TNameForm::SetMode(char f,bool v)
{
	if (f != filter || v != vacant_only)
	{
		Sex->ItemIndex = f == F_VOID ? -1 : f == ONLY_GIRLS ? 1 : 0;
		Sex->Enabled = f == F_VOID;
		filter = f;
		vacant_only = v;
		if (f != F_IMPOSSIBLE)
			RefreshNames();
	}
}

//---------------------------------------------------------------------------

void __fastcall TNameForm::AssignNameClick(TObject *)
{
	if (!NameView->SelCount) return;
	cookie = (RabName *) NameView->Selected->Data;
}

//---------------------------------------------------------------------------

void __fastcall TNameForm::NameViewColumnClick(TObject *Sender,TListColumn *Column)
{
	((Srt *) ((TComponent *) Sender)->Tag)->Process(Column);
}

//---------------------------------------------------------------------------

void __fastcall TNameForm::DelNameClick(TObject *)
{
	TListItem *li;
	if (!(li = NameView->Selected)) return;
	RabName *rn = (RabName *) li->Data;
	if (!rn->IsVacant() || !rn->IsSurnameReallyVacant())
	{
		MessageBox(NULL,"������� ����� ������ ��������� ���, ���\n������� ���������� �� ����� �������� �\n��������, ���������� �� ����� �����!","��������",MB_APPLMODAL|MB_ICONWARNING|MB_OK);
		return;
	}
	RabNameList *nl = rn->FindMe();
	nl->Remove(rn);
	delete li;
	delete rn;
}

//---------------------------------------------------------------------------

void __fastcall RabNameList::Render()
{
	RabName *rn;
	AboutForm->Reset("������������� ������ ���...",Count);
	for (int i = 0; i < Count; i++) // ����������� � ������
	{
		rn = Get(i);
		rn->Render(female);
	}
	AboutForm->Reset();
}

//---------------------------------------------------------------------------

void __fastcall TNameForm::SurChange(TObject *)
{
	if (notify) return;
	char len = Sur->Text.Length();
  if (!len)
  {
    Ok->Enabled = false;
    return;
  }
  notify++;
  Sur->Text = Sur->Text.Trim();
  for (char i = 1; i <= len; i++)
    if (!isrus(Sur->Text[i]) || isspace(Sur->Text[i]))
    {
  		MessageBox(NULL,"������� ������ �������� ������ �� ������� ����!","������",MB_APPLMODAL|MB_ICONEXCLAMATION|MB_OK);
      if (i > 1)
        Sur->Text = Sur->Text.SubString(1,i - 1);
      else
        Sur->Clear();
      break;
    }

	sur_changed = true;
	Ok->Enabled = !Name->Text.IsEmpty() && !Sur->Text.IsEmpty();
  notify--;
}

//---------------------------------------------------------------------------

TStream& __fastcall operator >> (TStream& s,RabNameList *nl)
{
	unsigned short count;
	s.ReadBuffer(&count,sizeof(count));
	for (nl->Capacity = count; count--; nl->Add(new RabName(s)));
	return s;
}

//---------------------------------------------------------------------------

TStream& __fastcall operator << (TStream& s,RabNameList *nl)
{
	unsigned short c = nl->Count;
	s.WriteBuffer(&c,sizeof(c));
	for (int i = 0; i < c; s << (RabName *) nl->Items[i++]);
	return s;
}

//---------------------------------------------------------------------------

bool __fastcall RabNameList::Add(RabName *rn)
{
	if (Find(rn->GetName()))
		return false;
	TList::Add(rn);
	return true;
}

//---------------------------------------------------------------------------

void __fastcall TNameForm::MakeRabNameBusy(Rabbit *r)
{
	RabNameList *rl = r->GetSex() == FEMALE ? female_names : male_names;
	RabName *rn;
	const char *p = r->GetName();
	if (p && !rl->Find(p))
	{
		AnsiString a("��� \"");
		a += AnsiString(p) + "\" ����������� � ������!";
		ReportForm->Report->Lines->Add(a);
		ReportForm->changed = false;
	}
	if ((p = r->GetSurname()) && (rn = female_names->Find(p)) && !rn->IsUsed())
		rn->SetLock();
	if ((p = r->GetPathonomic()) && (rn = male_names->Find(p)) && !rn->IsUsed())
		rn->SetLock();
}

//---------------------------------------------------------------------------

void __fastcall RabName::DecreaseLock()
{
	unsigned short delta = today - RabName::base_date;
	if (key > delta)
		key -= delta;
	else
		key = VACANT;
}

//---------------------------------------------------------------------------

const char * __fastcall TNameForm::Find(unsigned short x,bool surname,SEX sex)
{
	if (x == VACANT) return NULL;
	RabNameList *rl;
	RabName *rn;
	const char *p;

	switch (sex)
	{
		case MALE:
			rl = male_names;
			break;
		default:
			if (p = Find(x,surname,MALE))
				return p;
		case FEMALE:
			rl = female_names;
	}
	for (int i = 0; i < rl->Count; i++)
	{
		rn = rl->Get(i);
		if (surname)
		{
			if (rn->GetSurKey() == x)
				return rn->GetSurname();
		}
		else if (rn->GetKey() == x)
			return rn->GetName();
	}
	return NULL;
}

//---------------------------------------------------------------------------

unsigned short __fastcall TNameForm::FindNameKeyBySurKey(unsigned short x,SEX sex)
{
	if (x != VACANT)
  {
    RabNameList *rl;
    RabName *rn;

    switch (sex)
    {
      case MALE:
        rl = male_names;
        break;
      case FEMALE:
        rl = female_names;
        break;
      default:
        return 0;
    }
    for (int i = 0; i < rl->Count; i++)
    {
      rn = rl->Get(i);
      if (rn->GetSurKey() == x)
        return rn->GetKey();
    }
  }
	return 0;
}

//---------------------------------------------------------------------------

unsigned short __fastcall TNameForm::FindKey(const char *p,SEX sex)
{
	RabNameList *rl;
	RabName *rn;
	unsigned short x;

	if (!p || !*p) return VACANT;
	switch (sex)
	{
		case MALE:
			rl = male_names;
			break;
		default:
			if (x = FindKey(p,MALE)) return x;
		case FEMALE:
			rl = female_names;
	}
	return (rn = rl->Find(p)) ? rn->GetKey() : 0;
}


//---------------------------------------------------------------------------

RabName * __fastcall TNameForm::FindRabName(unsigned short x,SEX sex)
{
	if (x == VACANT) return NULL;
	RabNameList *rl;
	RabName *rn;

	switch (sex)
	{
		case MALE:
			rl = male_names;
			break;
		default:
			if (rn = FindRabName(x,MALE))
				return rn;
		case FEMALE:
			rl = female_names;
	}
	for (int i = 0; i < rl->Count; i++)
		if ((rn = rl->Get(i))->GetKey() == x)
			return rn;
	return NULL;
}

//---------------------------------------------------------------------------

RabName * __fastcall TNameForm::FindRabName(const char *p,SEX sex,bool surname) // ����� �� ������������
{
	RabNameList *rl;
	RabName *rn;

	switch (sex)
	{
		case MALE:
			rl = male_names;
			break;
		default:
			if (rn = FindRabName(p,MALE,surname))
				return rn;
		case FEMALE:
			rl = female_names;
	}
	return surname ? rl->FindSurname(p) : rl->Find(p);
}

//---------------------------------------------------------------------------

unsigned short __fastcall RabName::GetOrSetSurKey()
{
	if (!sur_key)
		sur_key = ++RabName::last_sur_key;
	return sur_key;
}

//---------------------------------------------------------------------------

void __fastcall TNameForm::TestForFalseNameLocks()
{
	male_names->TestForFalseNameLocks();
	female_names->TestForFalseNameLocks();
}

//---------------------------------------------------------------------------

void __fastcall RabNameList::TestForFalseNameLocks()
{
	ListRab *lr = PopulationWin->rabbits;
	RabName *rn;
	unsigned short key;
	int j;

	for (int i = 0; i < Count; i++)
		if ((rn = Get(i))->IsUsed())
		{
			key = rn->GetKey();
			for (j = 0; j < lr->Count; j++)
				if (lr->GetRabbit(j)->GetNameKey() == key)
					break;
			if (j == lr->Count)
			{
				rn->SetFree();
				NameForm->SetMode(F_IMPOSSIBLE,false);
			}
		}
}

//---------------------------------------------------------------------------

unsigned short __fastcall RabName::MakeUsed()
{
	if (RabName::import)
	{
		use_count++;
		if (key)
			return key;
	}
	return key = ++last_key;
}

//---------------------------------------------------------------------------

void __fastcall TNameForm::UnLockClick(TObject *)
{
	TListItem *li;
	if (!(li = NameView->Selected)) return;
	RabName *rn = (RabName *) li->Data;
	if (rn->IsLocked())
	{
		rn->SetFree();
		RefreshNames();
	}
	else
		MessageBox(NULL,"��� �� �������������!","��������",MB_APPLMODAL|MB_ICONWARNING|MB_OK);
}

//---------------------------------------------------------------------------

void __fastcall TNameForm::UnlockAllClick(TObject *)
{
	if (MessageBox(NULL,"�� ������������� ������ �������������� ��� ��������������� �����???","������",MB_APPLMODAL|MB_ICONQUESTION|MB_YESNO|MB_DEFBUTTON2) == IDNO) return;
	male_names->UnlockAll();
	female_names->UnlockAll();
	RefreshNames();
}

//---------------------------------------------------------------------------

bool __fastcall RabName::IsSurnameReallyVacant()
{
	ListRab *lr = PopulationWin->rabbits->FindRabbitsWithThisSurKey(sur_key);
	if (lr)
	{
		delete lr;
		return false;
	}
	return true;
}

//---------------------------------------------------------------------------

void __fastcall TNameForm::Clear()
{
  male_names->Clear();
  female_names->Clear();
  NameView->Items->Clear();
  RabName::last_key = START_KEY;
  RabName::last_sur_key = VACANT;
}


