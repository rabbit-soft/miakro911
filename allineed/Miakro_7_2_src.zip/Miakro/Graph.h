#ifndef GraphH
#define GraphH

//---------------------------------------------------------------------------

#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ExtCtrls.hpp>
#include <vcl\ComCtrls.hpp>
#include <Chart.hpp>
#include <Series.hpp>
#include <TeeFunci.hpp>
#include <TeEngine.hpp>
#include <TeeProcs.hpp>
#include "Rabbit.h"
#include "CSPIN.h"
#include <Menus.hpp>

//---------------------------------------------------------------------------

class Aver
{
	private:
		unsigned long  gross;
		int						 num;
		unsigned short age;
	public:
		__fastcall Aver(unsigned long w,unsigned short d);
		float 				 __fastcall Get() { return gross / (float) num; }
		unsigned short __fastcall When() { return age; }
		void __fastcall More(unsigned long w) { gross += w; num++; }
		void __fastcall Render(SEX sx) const;
};

//---------------------------------------------------------------------------

class AverList : public TList
{
	private:
		SEX sex;
		Aver * __fastcall Find(unsigned short d) const;
		bool 	 __fastcall PassedFilter(const TListItem *li,const Rabbit *r);
	public:
				 __fastcall AverList(SEX sx);
		void __fastcall More(unsigned short w,unsigned short d);
		void __fastcall Render() const;
		Aver * __fastcall GetAver(int i) const { return (Aver *) Items[i]; }
};

//---------------------------------------------------------------------------

class TGraphForm : public TForm
{
__published:
	TStatusBar *GpStatus;
	TPageControl *Pages;
	TTabSheet *KillPage;
	TTabSheet *WeightPage;
	TTabSheet *LostPage;
	TLabel *Label1;
	TLabel *Label2;
	TLabel *MaleLabel;
	TLabel *FemaleLabel;
	TLabel *Label3;
	TLabel *Label4;
	TLabel *Label5;
	TLabel *Label6;
	TLabel *Label7;
	TTrackBar *MaleTrack;
	TTrackBar *FemaleTrack;
	TButton *Apply;
	TPanel *DrawPanel;
	TImage *Graph;
	TRadioGroup *ManualAvto;
	TListView *LostList;
	TListView *ReasonsList;
	TListView *Workers;
	TChart *WeightChart;
	TPanel *Panel1;
	TLineSeries *Series1;
	TLineSeries *Series2;
	TAddTeeFunction *TeeFunction1;
	TRadioGroup *Who;
	TLineSeries *Series3;
	TButton *Refresh;
	TPanel *Panel2;
	TPanel *Panel3;
	TEdit *Reason;
	TCSpinEdit *ReasonRate;
	TButton *Add;
	TEdit *Worker;
	TCSpinEdit *WorkerRate;
	TDateTimePicker *When;
	TLabel *Label8;
	TPopupMenu *Popup;
	TMenuItem *Delete;
	TMenuItem *N1;
	TMenuItem *Preview;
	TMenuItem *Print;
	TPopupMenu *ReasonPopup;
	TPopupMenu *WorkersPopup;
	TMenuItem *DeleteReason;
	TMenuItem *DeleteWorker;
	void __fastcall TrackChange(TObject *Sender);
	void __fastcall ApplyClick(TObject *Sender);
	void __fastcall ManualAvtoClick(TObject *Sender);
	void __fastcall FormShow(TObject *Sender);
	void __fastcall WhoClick(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall RefreshClick(TObject *Sender);
	void __fastcall PreviewClick(TObject *Sender);
	void __fastcall PrintClick(TObject *Sender);
	void __fastcall AddClick(TObject *Sender);
	void __fastcall LostListDblClick(TObject *Sender);
	void __fastcall DeleteClick(TObject *Sender);
	void __fastcall ReasonsListDblClick(TObject *Sender);
	void __fastcall WorkersDblClick(TObject *Sender);
	void __fastcall DeleteReasonClick(TObject *Sender);
	void __fastcall DeleteWorkerClick(TObject *Sender);
	void __fastcall LostListColumnClick(TObject *Sender, TListColumn *Column);
private:
	AverList *weights[MAX_SEX];
	void __fastcall SubRender(bool fem);
	void __fastcall Verticaller(bool fem);
	void __fastcall AutoMod(bool fem); // ������������� ������
	void __fastcall PreviewOrPrint(bool print);
public:
	char notify;
			 __fastcall TGraphForm(TComponent* Owner);
			 __fastcall ~TGraphForm();
	void __fastcall Render();
	void __fastcall RenderWeights();
	void __fastcall AutoSet();
	void __fastcall SetGpStatus();
	void __fastcall ClearWeights();
	void __fastcall LostRabbit(const Rabbit *r);
	friend TStream& __fastcall operator >> (TStream& s,TGraphForm *gf);
	friend TStream& __fastcall operator << (TStream& s,TGraphForm *gf);
};

//---------------------------------------------------------------------------

extern TGraphForm *GraphForm;

//---------------------------------------------------------------------------

#endif
