#ifndef ReportYoungH
#define ReportYoungH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Db.hpp>
#include <DBTables.hpp>
#include <ExtCtrls.hpp>
#include <Qrctrls.hpp>
#include <quickrpt.hpp>
#include <QuickRpt.hpp>
//---------------------------------------------------------------------------
class TRepYoungForm : public TForm
{
__published:
	TQuickRep *RepYoung;
	TQRBand *QRBand1;
	TQRLabel *Title;
	TQRBand *QRBand5;
	TQRLabel *QRLabel1;
	TQRLabel *QRLabel2;
	TQRLabel *QRLabel3;
	TQRLabel *QRLabel4;
	TQRLabel *QRLabel5;
	TQRLabel *QRLabel7;
	TQRLabel *QRLabel9;
	TQRLabel *QRLabel10;
	TQRLabel *QRLabel11;
	TQRBand *QRBand4;
	TQRLabel *Summary;
	TQRBand *QRBand3;
	TQRSysData *QRSysData2;
	TQRSysData *QRSysData1;
	TQRSysData *QRSysData3;
	TQRSysData *QRSysData4;
	TQRBand *QRBand2;
	TQRDBText *QRDBText1;
	TQRDBText *QRDBText2;
	TQRDBText *QRDBText3;
	TQRDBText *QRDBText5;
	TQRDBText *QRDBText6;
	TQRDBText *QRDBText7;
	TQRDBText *QRDBText8;
	TQRDBText *QRDBText10;
	TQRDBText *QRDBText11;
	TDataSource *DataSource1;
	TTable *Table;
	TQRLabel *QRLabel6;
	TQRDBText *QRDBText4;
  TQRLabel *QRLabel8;
  TQRDBText *QRDBText9;
  TQRLabel *QRLabel12;
  TQRDBText *QRDBText12;
  TQRShape *QRShape1;
private:
public:
	__fastcall TRepYoungForm(TComponent* Owner);
};

//---------------------------------------------------------------------------

extern PACKAGE TRepYoungForm *RepYoungForm;

//---------------------------------------------------------------------------

#endif

