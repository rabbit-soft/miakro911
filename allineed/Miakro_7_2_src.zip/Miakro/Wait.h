#ifndef WaitH
#define WaitH

//---------------------------------------------------------------------------

#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>

#include "Rabbit.h"

//---------------------------------------------------------------------------

class TWaitForm : public TForm
{
__published:
	TLabel *IdLabel;
	TButton *Button1;
	TButton *Button2;
private:
public:
	ListRab *list;
	__fastcall TWaitForm(TComponent* Owner);

};

//---------------------------------------------------------------------------

extern PACKAGE TWaitForm *WaitForm;

//---------------------------------------------------------------------------
#endif

