#ifndef NamesH
#define NamesH

//---------------------------------------------------------------------------

#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ComCtrls.hpp>
#include <vcl\ExtCtrls.hpp>
#include "rusctype.h"
#include <vcl\Menus.hpp>

#include "Rabbit.h"

extern const unsigned short n_free;
extern const unsigned short n_used;

class RabNameList;
class RabName;

enum { ONLY_BOYS,ONLY_GIRLS,F_VOID,F_IMPOSSIBLE };

#define VACANT		0
#define MIN_LOCK  (VACANT + 1)
#define LOCK_NAMES 365
#define START_KEY (LOCK_NAMES + 1)

//---------------------------------------------------------------------------

class RabName
{
	private:
		unsigned short key; // ���������� ���� ������� ����� ( > 365); 0 - ��������; 1 - 365 - ���� ����������
		unsigned short sur_key; // ������������� ���� ��� �������. �������� ��� ������� �����
		char *name;
		char *surname;
		char use_count;    // ������ ��� ������� �� ������ ������������� ���
	public:
		static bool import;
		static unsigned short last_key,last_sur_key;
		static unsigned short base_date;
										__fastcall RabName(const char *name, const char *surname);
										__fastcall RabName(TStream& ifs); // ����������� �� ������
										__fastcall ~RabName() { free(name); free(surname); }
		void 			 	 		__fastcall SetLock();
		void 			 	 		__fastcall SetFree() { if (!RabName::import || !--use_count) key = VACANT; }
		void				 		__fastcall SetName(const char *px) { if (name) free(name); name = px && *px ? strdup(px) : NULL; }
		void				 		__fastcall SetSurname(const char *px) { if (surname) free(surname); surname = px && *px ? strdup(px) : NULL; }
		const char * 		__fastcall GetName() const { return name; }
		const char * 		__fastcall GetSurname() const { return surname; }
		void				 		__fastcall Render(bool female) const;
		RabNameList	 *	__fastcall FindMe() const;
		bool				 		__fastcall GetSex() const;
		void						__fastcall MakeVacant() { key = VACANT; }
		bool					 	__fastcall IsVacant() const { return key == VACANT; }
		bool					 	__fastcall IsUsed() const { return key >= START_KEY; }
		bool					 	__fastcall IsLocked() const { return !IsVacant() && !IsUsed(); }
		unsigned short	__fastcall MakeUsed();
		void						__fastcall DecreaseLock();
		unsigned short	__fastcall GetKey() const { return key; }
		unsigned short	__fastcall GetSurKey() const { return sur_key; }
		unsigned short	__fastcall GetOrSetSurKey();
		bool 						__fastcall IsSurnameReallyVacant();
		friend TStream& operator <<(TStream& s,RabName *n);
};

//---------------------------------------------------------------------------

class RabNameList : public TList
{
	private:
		bool female;
		char *fname;
	public:
		int found_index;
									__fastcall RabNameList(bool f) : TList() { female = f; }
									__fastcall ~RabNameList() { Clear(); }
  	void 					__fastcall UnlockAll();
		void 					__fastcall Clear() { 	for (int i = Count; --i >= 0; delete Get(i)); TList::Clear(); }
		RabName * 	 	__fastcall Get(int index) { return (RabName *) Items[index]; }
		RabName *	 		__fastcall Find(const char *name); 																	// ����� ���. ������ found_index
		RabName *	 		__fastcall Find(AnsiString a) const { return Find(a.c_str()); }			// ����� ��� �� AnsiStr
    RabName *     __fastcall FindSurname(const char *sur);
		const char * 	__fastcall GetSurname(const char *name) { const RabName *rn; return (rn = Find(name)) ? rn->GetSurname() : NULL; }
		void 					__fastcall Erase(RabName *what) { Remove(what); delete what; }
		bool					__fastcall Add(RabName *rn);
		void					__fastcall Render();
		void					__fastcall AdjustLockDates();
		void 					__fastcall TestForFalseNameLocks();
		friend TStream& __fastcall operator >>(TStream& s,RabNameList *nl);
		friend TStream& __fastcall operator <<(TStream& s,RabNameList *nl);
};

//---------------------------------------------------------------------------

class TNameForm : public TForm
{
__published:
	TListView *NameView;
	TGroupBox *GroupBox1;
	TEdit *Name;
	TLabel *Label1;
	TLabel *Label2;
	TEdit *Sur;
	TRadioGroup *Sex;
	TButton *Ok;
	TButton *AssignName;
	TPopupMenu *NameListPopup;
	TMenuItem *DelName;
	TButton *Cancel;
	TMenuItem *UnLock;
	TMenuItem *N1;
	TMenuItem *UnlockAll;
	void __fastcall NameChange(TObject *Sender);
	void __fastcall FormShow(TObject *Sender);
	void __fastcall OkClick(TObject *Sender);
	void __fastcall SexClick(TObject *Sender);
	void __fastcall NameViewDblClick(TObject *Sender);
	void __fastcall NameViewChange(TObject *Sender, TListItem *Item,TItemChange Change);
	void __fastcall AssignNameClick(TObject *Sender);
	void __fastcall NameViewColumnClick(TObject *Sender, TListColumn *Column);
	void __fastcall DelNameClick(TObject *Sender);
	void __fastcall SurChange(TObject *Sender);
	void __fastcall UnLockClick(TObject *Sender);
	void __fastcall UnlockAllClick(TObject *Sender);
private:
	RabName *edit;
	char filter;
	bool vacant_only;
	bool sur_changed;
public:
	char notify;
	RabName  *cookie;       // ������� ��� ��� �������
	RabNameList *male_names;
	RabNameList *female_names;
								 __fastcall TNameForm(TComponent* Owner);
								 __fastcall ~TNameForm();
	void 					 __fastcall SetMode(char sex,bool vacant_only);
	void 					 __fastcall Clear();
	const char * 	 __fastcall MakeSurname(const char *name,char len);
	void    			 __fastcall MakeRabNameBusy(Rabbit *r);
	void 					 __fastcall RefreshNames();
	void					 __fastcall AdjustLockDates() { male_names->AdjustLockDates(); female_names->AdjustLockDates(); RabName::base_date = today; }
	const char *	 __fastcall Find(unsigned short x,bool surname,SEX sex);
	RabName    *	 __fastcall FindRabName(unsigned short x,SEX sex);
	unsigned short __fastcall FindKey(const char *p,SEX sex);
	RabName    *	 __fastcall FindRabName(const char *p,SEX sex,bool surname = false); // ����� �� ������������
  unsigned short __fastcall FindNameKeyBySurKey(unsigned short x,SEX sex);
	void					 __fastcall TestForFalseNameLocks();
	friend RabName;
};

//---------------------------------------------------------------------------

extern TNameForm *NameForm;

//---------------------------------------------------------------------------

#endif
