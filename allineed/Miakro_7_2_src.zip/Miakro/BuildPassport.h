#ifndef BuildPassportH
#define BuildPassportH

//---------------------------------------------------------------------------

#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ExtCtrls.hpp>
#include <vcl\ComCtrls.hpp>

#include "Miakro.h"
#include "CSPIN.h"

class MiniFarm;
class Tier;

//---------------------------------------------------------------------------

class TBuildPas : public TForm
{
	__published:
	TRadioGroup *TierNum;
	TLabel *Label3;
	TButton *Use;
	TButton *Cancel;
	TGroupBox *UpperTierGroup;
	TComboBox *UpperTier;
	TEdit *UpperNotes;
	TLabel *Label1;
	TLabel *Label6;
	TGroupBox *LowerTierGroup;
	TLabel *Label7;
	TLabel *Label9;
	TComboBox *LowerTier;
	TEdit *LowerNotes;
	TGroupBox *UpperDelimGroup;
	TCheckBox *UpperAB;
	TCheckBox *UpperCD;
	TCheckBox *UpperBC;
	TCheckBox *UpperHeater;
	TGroupBox *LowerDelimGroup;
	TCheckBox *LowerAB;
	TCheckBox *LowerCD;
	TCheckBox *LowerBC;
	TCheckBox *LowerHeater;
	TRadioGroup *LowerJurtaLink;
	TRadioGroup *UpperJurtaLink;
	TCheckBox *UpperHeaterB;
	TCheckBox *LowerHeaterB;
	TCheckBox *UpperNest;
	TCheckBox *UpperNestB;
	TCheckBox *LowerNest;
	TCheckBox *LowerNestB;
	TLabel *Label2;
	TLabel *AddressLabel;
	TLabel *LowBusyLabel;
	TLabel *UpBusyLabel;
	TCheckBox *UpperDelim;
	TCheckBox *LowerDelim;
	TLabel *FarmNumber;
  TPanel *Panel1;
  TImage *ViewFarm;
	TCheckBox *UpperRepair;
	TCheckBox *LowerRepair;
  TCheckBox *LowerHeaterOn;
  TCheckBox *LowerHeaterOnB;
  TCheckBox *UpperHeaterOn;
  TCheckBox *UpperHeaterOnB;
	TCSpinEdit *GetNumber;
	TLabel *NumberOk;
	TLabel *StartCountLabel;
	TCSpinEdit *StartNumber;
	void __fastcall FormShow(TObject *Sender);
	void __fastcall TierChange(TObject *Sender);
	void __fastcall TierNumClick(TObject *Sender);
	void __fastcall UpperRepairClick(TObject *Sender);
	void __fastcall LowerNotesChange(TObject *Sender);
	void __fastcall UpperNotesChange(TObject *Sender);
	void __fastcall DelimClick(TObject *Sender);
	void __fastcall HeatNestClick(TObject *Sender);
	void __fastcall LowerJurtaLinkClick(TObject *Sender);
	void __fastcall UpperJurtaLinkClick(TObject *Sender);
	void __fastcall UpperDelimClick(TObject *Sender);
	void __fastcall LowerDelimClick(TObject *Sender);
	void __fastcall LowerRepairClick(TObject *Sender);
  void __fastcall UpperHeaterOnClick(TObject *Sender);
	void __fastcall GetNumberChange(TObject *Sender);
	void __fastcall StartNumberChange(TObject *Sender);
private:
		MiniFarm *pas_minifarm;   // �������������� ���������
		unsigned short old_number; // ������� ����� ���������
		char notify;
		void __fastcall LowerVisibility(Tier *ti);
		void __fastcall UpperVisibility(Tier *ti);
		void __fastcall MakeBusyLabel(TLabel *label,Tier *ti);
    void __fastcall DeleteRabs(char i);
public:
		OPEN_MODE mode;
		TList *rabs[2]; // ������ ������� �������� ��� �������� � ������� ������
							 __fastcall TBuildPas(TComponent* Owner);
							 __fastcall ~TBuildPas();
		MiniFarm * __fastcall OwnPasMiniFarm();
};

//---------------------------------------------------------------------------

extern TBuildPas *BuildPas;

//---------------------------------------------------------------------------

#endif
