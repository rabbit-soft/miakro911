#include <vcl.h>
#pragma hdrstop

#include "FeedGraph.h"
#include "Money.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"
TFeedGraphForm *FeedGraphForm;

//---------------------------------------------------------------------------

__fastcall TFeedGraphForm::TFeedGraphForm(TComponent* Owner) : TForm(Owner)
{
}

//---------------------------------------------------------------------------


void __fastcall TFeedGraphForm::PrintClick(TObject *)
{
  int tmpH,tmpW,tmpWMargin,tmpHMargin;
  TPrinterOrientation OldOrientation;
  TWaitCursor Wait;
  OldOrientation = Printer()->Orientation;
  Printer()->Orientation = poLandscape;
  try
  {
    Printer()->BeginDoc();
    try
    {
      Printer()->Title = String("�������� ������� �� ") + DateToStr(today);
      FeedChart->PrintResolution = 0;
      OtsevChart->PrintResolution = 0;
      tmpW = Printer()->PageWidth;
      tmpWMargin = floor(5.0 * tmpW / 100.0);
      tmpW = tmpW - 2 * tmpWMargin;
      tmpW = tmpW / 2;
      tmpH = Printer()->PageHeight;
      tmpHMargin = floor(5.0 * tmpH / 100.0);
      tmpH = tmpH - 2 * tmpHMargin;
      tmpH = tmpH / 2;
      FeedChart->PrintPartial(Rect(tmpWMargin,tmpHMargin,tmpWMargin + tmpW,tmpHMargin + tmpH));
      OtsevChart->PrintPartial(Rect(tmpWMargin + tmpW,tmpHMargin,tmpWMargin + 2 * tmpW,tmpHMargin + tmpH));
      Printer()->EndDoc();
    }
    catch (...)
    {
      Printer()->Abort();
      Printer()->EndDoc();
      throw;
    }
  }
  __finally
  {
    Printer()->Orientation = OldOrientation;
  }
}

//---------------------------------------------------------------------------

void __fastcall TFeedGraphForm::Render()
{
  TWaitCursor Wait;
	FeedChart->Series[0]->Clear();
	OtsevChart->Series[0]->Clear();
  String FeedName,FeedSpec;
  int value;
  TransList *tl = TransForm->translist;
  TransList *processed = new TransList(false);
  Trans *t;
  for (int i = 0; i < tl->Count; i++)
  {
    t = tl->GetTrans(i);
    if (processed->IndexOf(t) == -1)
      switch (t->GetType())
      {
        case FEED:
					value = t->GetWeight() + TransForm->CalcGrossFeedWeight(t,processed);
					if ((value -= TransForm->CalcUsedFeedWeight(t)) >= 0) // �� ���� ����� ������
					{
            String A(t->GetName());
            if (ParamForm->Config.use_feed_spec)
              A = A + ' ' + t->GetKind();
						FeedChart->Series[0]->AddY(value,A.c_str(),clTeeColor);
					}
					break;
				case OTSEV:
          if (t->IsSold()) continue;
					value = t->GetWeight() + TransForm->CalcGrossFeedWeight(t,processed);
					if ((value -= TransForm->CalcUsedFeedWeight(t)) >= 0)
          {
            String A(t->GetName());
            if (ParamForm->Config.use_feed_spec)
              A = A + ' ' + t->GetKind();
						OtsevChart->Series[0]->AddY(value,A.c_str(),clTeeColor);
					}
			}
	}
	delete processed;
}

//---------------------------------------------------------------------------

void __fastcall TFeedGraphForm::FormShow(TObject *)
{
  Render();
}

//---------------------------------------------------------------------------

void __fastcall TFeedGraphForm::UseSpecClick(TObject *)
{
  UseSpec->Checked = (ParamForm->Config.use_feed_spec ^= true);
  Render();
}

//---------------------------------------------------------------------------

