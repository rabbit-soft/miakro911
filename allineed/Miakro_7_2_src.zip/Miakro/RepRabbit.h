//---------------------------------------------------------------------------
#ifndef RepRabbitH
#define RepRabbitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <quickrpt.hpp>
#include <Db.hpp>
#include <DBTables.hpp>
#include <Qrctrls.hpp>
#include <QuickRpt.hpp>
//---------------------------------------------------------------------------
class TRepRabForm : public TForm
{
__published:	// IDE-managed Components
	TQuickRep *Report;
	TTable *Table;
	TDataSource *DataSource1;
	TQRBand *QRBand1;
	TQRLabel *Title;
	TQRBand *QRBand3;
	TQRSysData *QRSysData2;
	TQRSysData *QRSysData1;
	TQRSysData *QRSysData3;
	TQRSysData *QRSysData4;
	TQRBand *QRBand4;
	TQRLabel *Summary;
	TQRBand *QRBand2;
	TQRDBText *QRDBText1;
	TQRDBText *QRDBText2;
	TQRDBText *QRDBText3;
	TQRDBText *QRDBText4;
	TQRDBText *QRDBText5;
	TQRDBText *QRDBText6;
	TQRDBText *QRDBText7;
	TQRDBText *QRDBText8;
	TQRDBText *QRDBText9;
	TQRBand *QRBand5;
	TQRLabel *QRLabel1;
	TQRLabel *QRLabel2;
	TQRLabel *QRLabel3;
	TQRLabel *QRLabel4;
	TQRLabel *QRLabel5;
	TQRLabel *QRLabel6;
	TQRLabel *QRLabel7;
	TQRLabel *QRLabel8;
	TQRLabel *QRLabel9;
	TQRLabel *QRLabel10;
	TQRDBText *QRDBText10;
	TQRDBText *QRDBText11;
	TQRLabel *QRLabel11;
  TQRLabel *QRLabel12;
  TQRDBText *QRDBText12;
  TQRLabel *QRLabel13;
  TQRDBText *QRDBText13;
  TQuickRep *RemRep;
  TQRBand *QRBand6;
  TQRMemo *RemField;
  TQRBand *TitleOfRem;
  TQRLabel *RemLabel;
  TQRBand *QRBand8;
  TQRSysData *RemWhenPrinted;
  TQRSysData *QRSysData5;
  TQRLabel *RemDupTitle;
  TQRCompositeReport *ZooCompReport;
  TQRShape *HorLine;
private:	// User declarations
public:		// User declarations
	__fastcall TRepRabForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TRepRabForm *RepRabForm;
//---------------------------------------------------------------------------
#endif

