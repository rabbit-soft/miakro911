#ifndef PartnerH
#define PartnerH

#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ComCtrls.hpp>

class TPartnerForm : public TForm
{
__published:
	TGroupBox *GroupBox1;
	TListView *PartnerView;
	TButton *Ok;
	TButton *Button2;
private:
public:
	__fastcall TPartnerForm(TComponent* Owner);

};

//---------------------------------------------------------------------------

extern TPartnerForm *PartnerForm;

//---------------------------------------------------------------------------

#endif
