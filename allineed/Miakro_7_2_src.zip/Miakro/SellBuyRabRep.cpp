#include <vcl.h>
#pragma hdrstop

#include "SellBuyRabRep.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"
TSellBuyRabbitsForm *SellBuyRabbitsForm;

//---------------------------------------------------------------------------

__fastcall TSellBuyRabbitsForm::TSellBuyRabbitsForm(TComponent* Owner) : TForm(Owner)
{
}

//---------------------------------------------------------------------------
