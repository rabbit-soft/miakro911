#ifndef ZooRepH
#define ZooRepH

//---------------------------------------------------------------------------

#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Db.hpp>
#include <DBTables.hpp>
#include <ExtCtrls.hpp>
#include <quickrpt.hpp>
#include <Qrctrls.hpp>
#include <QuickRpt.hpp>

//---------------------------------------------------------------------------

class TZooRepForm : public TForm
{
__published:
	TQuickRep *Report;
	TDataSource *DataSource1;
	TTable *Table;
	TQRBand *QRBand1;
	TQRLabel *Title;
	TQRBand *QRBand2;
	TQRLabel *QRLabel1;
	TQRLabel *QRLabel2;
	TQRLabel *QRLabel3;
	TQRLabel *QRLabel4;
	TQRLabel *QRLabel5;
	TQRLabel *QRLabel6;
	TQRLabel *QRLabel7;
	TQRLabel *QRLabel8;
	TQRBand *QRBand4;
	TQRDBText *QRDBText1;
	TQRDBText *QRDBText2;
	TQRDBText *QRDBText3;
	TQRDBText *QRDBText4;
	TQRDBText *QRDBText5;
	TQRDBText *QRDBText6;
	TQRDBText *QRDBText7;
	TQRDBText *QRDBText8;
	TQRBand *QRBand5;
	TQRLabel *Summary;
	TQRBand *QRBand3;
	TQRSysData *WhenPrinted;
	TQRSysData *QRSysData4;
	TQuickRep *RemRep;
	TQRBand *QRBand6;
	TQRMemo *RemField;
	TQRBand *TitleOfRem;
	TQRLabel *RemLabel;
	TQRBand *QRBand8;
	TQRSysData *RemWhenPrinted;
	TQRSysData *QRSysData2;
	TQRCompositeReport *ZooCompReport;
	TQRLabel *DupTitle;
	TQRLabel *RemDupTitle;
  TQRShape *QRShape1;
  TQRShape *QRShape2;
	void __fastcall ZooCompReportAddReports(TObject *Sender);
	void __fastcall TitleOfRemBeforePrint(TQRCustomBand *Sender,
          bool &PrintBand);
private:
	TQRCompositeReport *zoo_report;
public:
	__fastcall TZooRepForm(TComponent* Owner);
};

//---------------------------------------------------------------------------

extern PACKAGE TZooRepForm *ZooRepForm;

//---------------------------------------------------------------------------

#endif

