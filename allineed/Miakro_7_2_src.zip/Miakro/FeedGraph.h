#ifndef FeedGraphH
#define FeedGraphH

//---------------------------------------------------------------------------

#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Chart.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include <Menus.hpp>
#include <Series.hpp>
#include <TeEngine.hpp>
#include <TeeProcs.hpp>

//---------------------------------------------------------------------------

class TFeedGraphForm : public TForm
{
__published:
  TPageControl *Pages;
  TTabSheet *TabSheet1;
  TTabSheet *TabSheet2;
  TMainMenu *MainMenu1;
  TMenuItem *Actions;
  TMenuItem *Print;
  TChart *FeedChart;
  TChart *OtsevChart;
  TPieSeries *Series1;
  TPieSeries *Series2;
  TMenuItem *UseSpec;
  TMenuItem *N1;
  void __fastcall PrintClick(TObject *Sender);
  void __fastcall FormShow(TObject *Sender);
  void __fastcall UseSpecClick(TObject *Sender);
private:
public:
  __fastcall TFeedGraphForm(TComponent* Owner);
  void __fastcall Render();
};

//---------------------------------------------------------------------------

extern PACKAGE TFeedGraphForm *FeedGraphForm;

//---------------------------------------------------------------------------

#endif
