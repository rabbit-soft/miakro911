#include <vcl\vcl.h>
#pragma hdrstop

#include <Printers.hpp>

#include "ReportWin.h"
#include "Builds.h"
#include "Miakro.h"
#include "Params.h"
#include "Rabbit.h"
#include "MoneyForm.h"
#include "Money.h"
#include "Names.h"
#include "Young.h"
#include "Zoo.h"
#include "PassportForm.h"
#include "Graph.h"
#include "Import.h"
#include "QuickRx.h"
#include "RepRabbit.h"
#include "RepBuild.h"
#include "ZooRep.h"
#include "ReportYoung.h"
#include "ArcRep.h"
#include "Archive.h"
#include "About.h"
#include "LossRep.h"
#include "MeatSold.h"
#include "SkinSold.h"
#include "SellBuyRabRep.h"
#include "Feed.h"
#include "Other.h"
#include "HaveMeat.h"
#include "HaveSkin.h"
#include "UsedFeedRep.h"
#include "Otsevrep.h"
#include "ArcRab.h"
#include "BoneRep.h"
#include "Bone.h"
#include "PlemPassport.h"

#define SPEC_COLUMN 5 // � ������ ���������
#define SPEC_ITEM 0   // � ����

//---------------------------------------------------------------------------

#pragma resource "*.dfm"

const char *cmd;
TReportForm *ReportForm;
TQuickRep *Reports::rep_table[MAX_REPORTS];
TQRLabel  *Reports::head_table[MAX_REPORTS];
TQRLabel  *Reports::summary_table[MAX_REPORTS];

static char wc_id[] = "WinCoords V1.4";

#define BACK_FILE "safety.cfg"

//---------------------------------------------------------------------------

__fastcall TReportForm::TReportForm(TComponent* Owner) : TForm(Owner)
{
	notify = 0;
	notes_li = NULL;
	changed = false;
	form_array[RAB_W] = PopulationWin;
	form_array[BUI_W] = BuildWin;
	form_array[TRA_W] = TransForm;
	form_array[ZOO_W] = ZooForm;
	form_array[YOU_W] = YoungForm;
	form_array[REP_W] = ReportForm;
	form_array[ARC_W] = ArchiveForm;
	auto_lists = new TList;
	auto_lists->Add(PopulationWin->RabbitList); // �������
	auto_lists->Add(BuildWin->BuildsList);      // ���������
	auto_lists->Add(YoungForm->YoungList);      // ��������
	auto_lists->Add(ZooForm->ZooList);          // ����������
	auto_lists->Add(ArchiveForm->PlansList);    // ����� ������������
	Reports::rep_table[Q_BUTCHER] = ButcherReport->Report;
	Reports::head_table[Q_BUTCHER] = ButcherReport->Title;
	Reports::summary_table[Q_BUTCHER] = ButcherReport->Summary;
	Reports::rep_table[Q_RABBITS] = RepRabForm->Report;
	Reports::head_table[Q_RABBITS] = RepRabForm->Title;
	Reports::summary_table[Q_RABBITS] = RepRabForm->Summary;
	Reports::rep_table[Q_BUILDINGS] = RepBuildForm->Report;
	Reports::head_table[Q_BUILDINGS] = RepBuildForm->Title;
	Reports::summary_table[Q_BUILDINGS] = RepBuildForm->Summary;
	Reports::rep_table[Q_ZOO] = ZooRepForm->Report;
	Reports::head_table[Q_ZOO] = ZooRepForm->Title;
	Reports::summary_table[Q_ZOO] = ZooRepForm->Summary;
	Reports::rep_table[Q_YOUNG] = RepYoungForm->RepYoung;
	Reports::head_table[Q_YOUNG] = RepYoungForm->Title;
	Reports::summary_table[Q_YOUNG] = RepYoungForm->Summary;
	Reports::rep_table[Q_ARCHIVE] = ArcRepForm->Report;
	Reports::head_table[Q_ARCHIVE] = ArcRepForm->Title;
	Reports::summary_table[Q_ARCHIVE] = ArcRepForm->Summary;
	Reports::rep_table[Q_LOSS] = LossRepForm->Report;
	Reports::head_table[Q_LOSS] = LossRepForm->Title;
	Reports::summary_table[Q_LOSS] = LossRepForm->Summary;
	Reports::rep_table[Q_MEATSOLD] = MeatSoldForm->Report;
	Reports::head_table[Q_MEATSOLD] = MeatSoldForm->Title;
	Reports::summary_table[Q_MEATSOLD] = MeatSoldForm->Summary;
	Reports::rep_table[Q_SKINSOLD] = SkinSoldForm->Report;
	Reports::head_table[Q_SKINSOLD] = SkinSoldForm->Title;
	Reports::summary_table[Q_SKINSOLD] = SkinSoldForm->Summary;
	Reports::rep_table[Q_SELLBUYRAB] = SellBuyRabbitsForm->Report;
	Reports::head_table[Q_SELLBUYRAB] = SellBuyRabbitsForm->Title;
	Reports::summary_table[Q_SELLBUYRAB] = SellBuyRabbitsForm->Summary;
	Reports::rep_table[Q_FEED] = FeedForm->Report;
	Reports::head_table[Q_FEED] = FeedForm->Title;
	Reports::summary_table[Q_FEED] = FeedForm->Summary;
	Reports::rep_table[Q_OTHER] = OtherForm->Report;
	Reports::head_table[Q_OTHER] = OtherForm->Title;
	Reports::summary_table[Q_OTHER] = OtherForm->Summary;
	Reports::rep_table[Q_HAVEMEAT] = HaveMeatForm->Report;
	Reports::head_table[Q_HAVEMEAT] = HaveMeatForm->Title;
	Reports::summary_table[Q_HAVEMEAT] = HaveMeatForm->Summary;
	Reports::rep_table[Q_HAVESKIN] = HaveSkinForm->Report;
	Reports::head_table[Q_HAVESKIN] = HaveSkinForm->Title;
	Reports::summary_table[Q_HAVESKIN] = HaveSkinForm->Summary;
	Reports::rep_table[Q_USEDFEED] = UsedFeedRepForm->Report;
	Reports::head_table[Q_USEDFEED] = UsedFeedRepForm->Title;
	Reports::summary_table[Q_USEDFEED] = UsedFeedRepForm->Summary;
	Reports::rep_table[Q_OTSEV] = OtsevRepForm->Report;
	Reports::head_table[Q_OTSEV] = OtsevRepForm->Title;
	Reports::summary_table[Q_OTSEV] = OtsevRepForm->Summary;
	Reports::rep_table[Q_ARCRAB] = ArcRabForm->Report;
	Reports::head_table[Q_ARCRAB] = ArcRabForm->Title;
	Reports::summary_table[Q_ARCRAB] = ArcRabForm->Summary;
	Reports::rep_table[Q_BONE] = BoneReport->Report;
	Reports::head_table[Q_BONE] = BoneReport->Title;
	Reports::summary_table[Q_BONE] = BoneReport->Summary;
	reports = new Reports;
	HdSets[H_NAMES] << 1 << 2;
	HdSets[H_BREEDS] << 1 << 2;
	HdSets[H_CHIL] << 8;
	HdSets[H_KCHIL] << 7 << 15;
	HdSets[H_KFA] << 12;
	HdSets[H_KMO] << 9 << 15; // ������ � ���
	ParamForm->View2Cfg();
	PopulationWin->OldName = PopulationWin->DefaultName;
#ifndef DEMO
	String FileName;
	if (_argc > 1)
	{
		FileName = _argv[1];
		int pos = FileName.LastDelimiter('\\');
		SetCurrentDir(FileName.SubString(1,--pos));
		PopulationWin->OldName = FileName;
		PopulationWin->LoadAll(FileName,false);
		if (ParamForm->Config.automode)
			GraphForm->AutoSet();
	}
	else
	{
		TFileStream *ifs = NULL;
		try
		{
			ifs = new TFileStream(last_used_file,fmOpenRead);
			PopulationWin->OldName = GetBufStr(*ifs);
			if (PopulationWin->OldName.AnsiCompareIC(AnsiString("CRASH")))
			{
				PopulationWin->LoadAll(PopulationWin->OldName,false);
				if (ParamForm->Config.automode)
					GraphForm->AutoSet();
			}
		}
		catch(...) {}
		if (ifs) delete ifs;
	}
#endif
	win_coords = new WinCoorList();
	TFileStream *ws = NULL;
	try
	{
		ws = new TFileStream(WINCOOR_FILE,fmOpenRead);
		AboutForm->Reset("���������� ����...",1);
		if (strcmp(GetBufStr(*ws),wc_id))
		{
			MessageBox(NULL,"���������� ������ ����� ������� ���������.\n����� ������������� ������� ������ ���� ���������!","��������������",MB_APPLMODAL|MB_ICONEXCLAMATION|MB_OK);
			columners = new Columners();
		}
		else
		{
			*ws >> win_coords;
			columners = new Columners(*ws);
			win_coords->Process();
			AboutForm->Reset();
		}
	}
	catch(...) { columners = new Columners(); }
  if (ws) delete ws;
	AboutForm->Reset();
	Passport->Vacc->Caption = ParamForm->GetSpecJobName(AS_SHORT);
	Passport->Family->Columns->Items[SPEC_COLUMN]->Caption = ParamForm->GetSpecJobName(AS_SHORT);
	Passport->VaccGroup->Caption = ParamForm->GetSpecJobName(AS_FULL);
	ParamForm->P_Vacc->Caption = ParamForm->GetSpecJobName(AS_FULL);
	ParamForm->SpecJobTime->Caption = ParamForm->GetSpecJobName(AS_FULL);
	if (ParamForm->Config.gen_tree_width)
		PopulationWin->GenTreePanel->Width = ParamForm->Config.gen_tree_width;
  if (ParamForm->Config.young_gen_tree_width)
    YoungForm->GenTreePanel->Width = ParamForm->Config.young_gen_tree_width;
  PopulationWin->ShowGenTreeClick(NULL);
  YoungForm->ShowGenTreeClick(NULL);
  Alarm();
}

//---------------------------------------------------------------------------

__fastcall TReportForm::~TReportForm()
{
	notify++;
	delete reports;
	delete win_coords;
	delete columners;
	delete auto_lists;
}

//---------------------------------------------------------------------------

void __fastcall TReportForm::FormClose(TObject *, TCloseAction &Action)
{
	PopulationWin->ViewReport->Checked = false;
  notes_li = NULL;
}

//---------------------------------------------------------------------------

void __fastcall TReportForm::FormDestroy(TObject *)
{
	PopulationWin->notify++;
	BuildWin->notify++;
	TransForm->notify++;
	ZooForm->notify++;
	YoungForm->notify++;
	ParamForm->notify++;
	TransForm->notify++;
	Passport->notify++;
}

//---------------------------------------------------------------------------

void __fastcall TReportForm::RememberMapClick(TObject *)
{
	if (!Report->Lines->Count || !changed) return;
	try
	{
		if (Report->Lines->Strings[0][1] != '*') throw("������ ������ �� ���������� �� *");
		Report->Lines->Strings[0] = "*** ����� ������������ �������� ***";
		for (int i = 0; i < Report->Lines->Count; i++)
			if (Report->Lines->Strings[i].Length() && Report->Lines->Strings[i][1] == '=')
			{
				Report->Lines->Strings[i++] = "=== ����� ����� ������������ �������� ===";
				while (i < Report->Lines->Count)
					Report->Lines->Delete(i);
				Report->Lines->SaveToFile(map_file);
				changed = false;
				return;
			}
		throw("����������� �������� ������ (������ ���������� � =)");
	}
	catch (const char *p) { MessageBox(NULL,p,"������",MB_APPLMODAL|MB_ICONEXCLAMATION|MB_OK); }
	catch (...) { MessageBox(NULL,"������ ������ ����� ������������ ��������!","������",MB_APPLMODAL|MB_ICONEXCLAMATION|MB_OK); }
}

//---------------------------------------------------------------------------

void __fastcall TReportForm::TrySaveMap()
{
	if (!changed || !Report->Lines->Count || Report->Lines->Strings[0][1] != '*') return;
	for (int i = 0; i < Report->Lines->Count; i++)
		if (Report->Lines->Strings[i].Length() && Report->Lines->Strings[i][1] == '=')
		{
			RememberMapClick(NULL);
			return;
		}
}

//---------------------------------------------------------------------------

void __fastcall TReportForm::OpenMapClick(TObject *)
{
	Report->Lines->Clear();
	try { Report->Lines->LoadFromFile(map_file); }
	catch (...) { MessageBox(NULL,"���� ������������ �������� ����������� ��� ��������!","�������",MB_APPLMODAL|MB_ICONEXCLAMATION|MB_OK); }
	changed = false;
}

//---------------------------------------------------------------------------

unsigned short __fastcall RepInfo::CalcRecLen(TListView *lw,unsigned short *arr)
{
	const TListItems *lia = lw->Items;
	const TListColumns *lc = lw->Columns;
	const TListItem *li;
	unsigned short sum = 0,x,y;

	for (int i = 0; i < ((TListColumns *) lc)->Count; i++) // �� ��������
	{
		x = 1;
		for (int j = 0; j < ((TListItems *) lia)->Count; j++) // �� �������
		{
			li = ((TListItems *) lia)->Item[j];
			if (i)
			{
				if (i - 1 < li->SubItems->Count)
					y = li->SubItems->Strings[i - 1].Length();
			}
			else
				y = li->Caption.Length();
			if (x < y)
				x = y;
		}
		arr[i] = x;
		sum += x;
	}
	return sum;
}

//---------------------------------------------------------------------------

__fastcall Reports::Reports() : TList()
{
	current = Q_BUTCHER;
	AnsiString n;
	for (int i = 0; i < (int) MAX_REPORTS; i++)
	{
		n = (int) i;
		Add(new RepInfo(rep_table[i],Reports::head_table[i],Reports::summary_table[i]));
	}
}

//---------------------------------------------------------------------------

void __fastcall Reports::Prepare(QRP what,TListView *lw,AnsiString h,AnsiString f)
{
	RepInfo *ri = GetRepInfo(current = what);
	ri->Set(h,f);
	ri->MakeReport(lw);
}

//---------------------------------------------------------------------------

void __fastcall RepInfo::MakeReport(TListView *lw)
{
	TFileStream *s = NULL;
	try
	{
		report->DataSet->Active = false;
		{
#ifdef DBG
			String path("C:\\Program Files\\DmSoft\\Miakro\\");
			path += ((TTable *) report->DataSet)->TableName;
			try { s = new TFileStream(path,fmCreate); }
#else
			try { s = new TFileStream(((TTable *) report->DataSet)->TableName,fmCreate); }
#endif
			catch(...) { throw("��������� �������� ��������� ����!"); }
			TWaitCursor Wait;
			TListItems *lia = lw->Items;
			TListColumns *lcs = lw->Columns;
			TStrings *ss;
			TListItem *li;
			unsigned short * const arr = new unsigned short[lcs->Count];
			memset(arr,0,lcs->Count * sizeof(unsigned short));
			DbHead Head;
			memset(&Head,0,sizeof(Head));
			Head.vers = 3;
			Head.year = 98;
			Head.month = Head.date = 1;
			Head.numrec = lia->Count;
			Head.reclen = CalcRecLen(lw,arr) + 1;
			Head.headlen = sizeof(DbHead) + sizeof(DbRec) * lcs->Count + 2;
			s->WriteBuffer(&Head,sizeof(Head));
			DbRec Rec;
			for (int i = 0; i < lcs->Count; i++)   // �� ��������
			{
				memset(&Rec,0,sizeof(Rec));
				*Rec.name = char ('A' + i);
				Rec.type = 'C';
				Rec.len = arr[i];
				s->WriteBuffer(&Rec,sizeof(Rec));
			}
			char x = 0xd;
			s->WriteBuffer(&x,1);
			x = 0;
			s->WriteBuffer(&x,1); //	s << ends;
			char * const rec = new char[Head.reclen - 1];
			char *p;
			int z;
			for (int i = 0; i < lia->Count; i++)  // �� �������
			{
				memset(rec,' ',Head.reclen - 1);
				p = rec;
				li = lia->Item[i];
				ss = li->SubItems;
				for (int j = 0; j < lcs->Count; j++) // �� ��������
				{
					if (j)
					{
						if (j - 1 < ss->Count && (z = ss->Strings[j - 1].Length()))
							strncpy(p,ss->Strings[j - 1].c_str(),z);
					}
					else
						strncpy(p,li->Caption.c_str(),z = li->Caption.Length());
					p += arr[j];
				}
				x = ' ';
				s->WriteBuffer(&x,1);
				s->WriteBuffer(rec,Head.reclen - 1);
			}
			delete[] rec;
			delete[] arr;
		}
		if (s)
		{
			delete s;
			s = NULL;
			report->DataSet->Active = true;
		}	
	}
	catch (const char *p) { MessageBox(NULL,p,"������",MB_APPLMODAL|MB_ICONEXCLAMATION|MB_OK); }
	catch (Sysutils::Exception& exc) { MessageBox(NULL,(String("�������� � BDE: ") + exc.Message).c_str(),"������",MB_APPLMODAL|MB_ICONEXCLAMATION|MB_OK); }
	if (s) delete s;
}

//---------------------------------------------------------------------------

void __fastcall Reports::ToDb(TStream& s,AnsiString a,START_STOP start)
{
	static String sum;
	switch (start)
	{
		case START:
			sum = AnsiString('\"') + a + "\",";
			break;
		case MIDDLE:
			sum += AnsiString('\"') + a + "\",";
			break;
		case STOP:
			sum += AnsiString('\"') + a + "\"\n";
			char *buf = new char[sum.Length() + 1];
			strcpy(buf,sum.c_str());
			s.WriteBuffer(buf,sum.Length() + 1);
			delete[] buf;
	}
}

//---------------------------------------------------------------------------

__fastcall WinCoorList::WinCoorList() : TList()
{
	Capacity = MAX_W;
	for (int i = 0; i < MAX_W; i++)
		Add(new WinCoor(W_ID(i)));
}

//---------------------------------------------------------------------------

TStream& operator << (TStream& s,WinCoor *wc)
{
	wc->Coords.left = wc->win->Left;
	wc->Coords.top = wc->win->Top;
	if (wc->win->BorderStyle == bsSizeable)
	{
		wc->Coords.right = wc->win->Width;
		wc->Coords.bottom = wc->win->Height;
	}
	else
		wc->Coords.right = wc->Coords.bottom = 0;
	s.WriteBuffer(&wc->what,1);
	s.WriteBuffer(&wc->Coords,sizeof(wc->Coords));
	wc->visible = wc->win->Visible;
	s.WriteBuffer(&wc->visible,1);
	return s;
}

//---------------------------------------------------------------------------

TStream& operator >> (TStream& s,WinCoor *wc)
{
	s.ReadBuffer(&wc->what,1);
	s.ReadBuffer(&wc->Coords,sizeof(wc->Coords));
	s.ReadBuffer(&wc->visible,1);
	return s;
}

//---------------------------------------------------------------------------

void __fastcall WinCoor::Render() const
{
	if (Coords.right && Coords.bottom)
	{
		win->Position = poDesigned;
		win->Left = Coords.left;
		win->Top = Coords.top;
		if (win->BorderStyle == bsSizeable)
		{
			win->Width = Coords.right;
			win->Height = Coords.bottom;
		}
		if (win->Visible != visible)
			switch (what)
			{
				case BUI_W:
					PopulationWin->ViewbuildsClick(NULL);    // ���������
					break;
				case TRA_W:
					PopulationWin->ShowActivesClick(NULL);   // ����
					break;
				case ZOO_W:
					PopulationWin->ViewZooClick(NULL);       // ����������
					break;
				case YOU_W:
					PopulationWin->ViewYoungsClick(NULL);    // ��������
					break;
				case REP_W:
					PopulationWin->ViewReportClick(NULL);    // �����
					break;
				case ARC_W:                                // ������
					PopulationWin->ArcWinViewClick(NULL);
			}
	}
	else
		win->Position = poScreenCenter;
}

//---------------------------------------------------------------------------

void __fastcall TReportForm::PrintMeClick(TObject *)
{
	AnsiString x("O��������� ");
	Report->Print(x + DateToStr(today));
}

//---------------------------------------------------------------------------

TStream& operator >> (TStream& s,WinCoorList *wcl)
{
	unsigned char c;
	s.ReadBuffer(&c,1);
	for (int i = 0; i < c; s >> wcl->GetWinCoor(i++));
	return s;
}

//---------------------------------------------------------------------------

TStream& operator << (TStream& s,WinCoorList *wcl)
{
	PutStr(s,wc_id);
	unsigned char x = wcl->Count;
	s.WriteBuffer(&x,1);
	for (int i = 0; i < x; s << wcl->GetWinCoor(i++));
	return s;
}

//---------------------------------------------------------------------------

void __fastcall Columners::ApplyWidth(CLIST_TYPE cl)
{
	Columner *c = Find(cl);
	if (c)
		c->Render();
}

//---------------------------------------------------------------------------

TStream& __fastcall operator << (TStream& s,Columners *c)
{
	unsigned short i;
	for (i = 0; i < (unsigned short) MAX_CLISTS; i++) // ���� ������ � �������� �����������. ���� ������� ���, ������ ��
		c->RefreshOrCreate((CLIST_TYPE) i);
	unsigned short x = c->Count;
	s.WriteBuffer(&x,sizeof(x));
	for (i = 0; i < x; s << c->GetColumner(i++));
	return s;
}

//---------------------------------------------------------------------------

__fastcall Columner::Columner(TStream& s)
{
	params = new TList;
	s.ReadBuffer(&Id,sizeof(Id)); // ���������
  unsigned char w;
	s.ReadBuffer(&w,1);           // ����� ��������
	unsigned short x;
	for (params->Capacity = w; w--; params->Add((void *) x)) // ������ ��� ������� �������
		s.ReadBuffer(&x,sizeof(x));
}

//---------------------------------------------------------------------------

TStream& __fastcall operator << (TStream& s,Columner *c)
{
	s.WriteBuffer(&c->Id,sizeof(c->Id));
	unsigned short x;
	char w = c->params->Count;  // ����� ��������
	s.WriteBuffer(&w,1);
	for (char i = 0; i < w; s.WriteBuffer(&x,sizeof(x)))
		x = (unsigned short) c->params->Items[i++];
	return s;
}

//---------------------------------------------------------------------------

__fastcall Columner::Columner(CLIST_TYPE id)
{
	Id.id = id;
	Id.show_tier_types = ParamForm->Config.show_tier_types;
	Id.show_area_types = ParamForm->Config.show_area_types;
	Id.double_sur      = ParamForm->Config.double_sur;
	Id.tab_abbr        = ParamForm->Config.tab_abbr;
	TListView *lw = (TListView *) ReportForm->auto_lists->Items[id];
	params = new TList();
	char cols = lw->Columns->Count;
	for (char i = 0; i < cols; params->Add((void *) lw->Columns->Items[i++]->Width));
}

//---------------------------------------------------------------------------

void __fastcall Columner::UpdateParams()
{
	TListView *lw = (TListView *) ReportForm->auto_lists->Items[Id.id];
	char cols = lw->Columns->Count;
	for (char i = 0; i < cols; i++)
		params->Items[i] = (void *) lw->Columns->Items[i]->Width;
}

//---------------------------------------------------------------------------

void __fastcall Columner::Render()
{
	Columner Attempt((CLIST_TYPE) Id.id);
	if (*this == Attempt)
	{
		TListView *lw = (TListView *) ReportForm->auto_lists->Items[Id.id];
		lw->Columns->BeginUpdate();
		PopulationWin->notify++;
		BuildWin->notify++;
		ZooForm->notify++;
		YoungForm->notify++;
		for (char i = 0; i < params->Count; i++)
			lw->Columns->Items[i]->Width = (int) params->Items[i];
		lw->Columns->EndUpdate();
		YoungForm->notify--;
		ZooForm->notify--;
		BuildWin->notify--;
		PopulationWin->notify--;
	}
}

//---------------------------------------------------------------------------

__fastcall Columners::Columners(TStream& s) : TList()
{
	unsigned short x;
	try
	{
		s.ReadBuffer(&x,sizeof(x));
		Columner *c;
		while (x--)
		{
			Add(c = new Columner(s));
			c->Render();              // ���� ��������� ���������, �� ��������� columner � ���������������� ������
		}
	}
	catch(...) {}
}

//---------------------------------------------------------------------------

__fastcall Columners::~Columners()
{
	for (int i = Count; --i >= 0; delete GetColumner(i));
}

//---------------------------------------------------------------------------

bool __fastcall operator == (Columner& a,Columner& b)
{
	return a.Id.show_tier_types == b.Id.show_tier_types && a.Id.show_area_types == b.Id.show_area_types && a.Id.double_sur == b.Id.double_sur && a.Id.tab_abbr == b.Id.tab_abbr && a.Id.id == b.Id.id;
}

//---------------------------------------------------------------------------

void __fastcall Columners::RefreshOrCreate(CLIST_TYPE id)
{
	Columner *c = Find(id);
	if (c)
		c->UpdateParams();
	else
		Add(new Columner(id)); // ���������� ��������� �� ������� ������������ �������
}

//---------------------------------------------------------------------------

Columner *	__fastcall Columners::Find(CLIST_TYPE id)
{
	Columner *c,Attempt(id);
	for (int i = 0; i < Count; i++)
		if (*(c = GetColumner(i)) == Attempt)
			return c;
	return NULL;
}

//---------------------------------------------------------------------------

__fastcall Backuper::Backuper() : StringList()
{
	TFileStream *s = NULL;
	try
	{
		fname = BACK_FILE;
		s = new TFileStream(fname,fmOpenRead);
		*s >> this;
	}
	catch(...) {}
	if (s) delete s;	
}

//---------------------------------------------------------------------------

void __fastcall TReportForm::ReportChange(TObject *)
{
	if (notify) return;
	changed = true;
}

//---------------------------------------------------------------------------

void __fastcall TReportForm::RememberNotesClick(TObject *Sender)
{
  if (notes_li)
  {
    char x = notes_col_index;
    while (x-- >= notes_li->SubItems->Count)
      notes_li->SubItems->Add(' ');
    notes_li->SubItems->Strings[notes_col_index] = Report->Lines->Count ? NoBreak(Report->Lines->Text.c_str()) : String(' ');
    ((Trans *) notes_li->Data)->SetNotes(notes_li->SubItems->Strings[notes_col_index].c_str());
  }
  LowGroup->Visible = false;
  Close();
  notes_li = NULL;
}

//---------------------------------------------------------------------------

void __fastcall TReportForm::FormShow(TObject *)
{
  LowGroup->Visible = notes_li != NULL;
}

//---------------------------------------------------------------------------

void __fastcall TReportForm::Alarm()
{
  Application->ProcessMessages();
  if (!Visible && Report->Lines->Count)
  {
    PopulationWin->ViewReportClick(NULL);
    Application->ProcessMessages();
  }
}
