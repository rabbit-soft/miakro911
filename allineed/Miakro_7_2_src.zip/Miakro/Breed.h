#ifndef BreedH
#define BreedH

//---------------------------------------------------------------------------

#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ComCtrls.hpp>

#include "Miakro.h"
#include "Rabbit.h"
#include <Menus.hpp>

#define SHORT_BIAS 1
#define COLOR_BIAS 2
#define BREED_STEP 3 // ������-�������-������

//---------------------------------------------------------------------------

class TBreedForm : public TForm
{
__published:
	TGroupBox *GroupBox1;
	TListView *BreedView;
	TEdit *BreedFull;
	TLabel *Label1;
	TLabel *Label2;
	TEdit *BreedShort;
	TEdit *BreedGroup;
	TUpDown *BreedGroupUD;
	TLabel *Label3;
	TButton *Assign;
	TButton *Remember;
	TButton *Cancel;
	TPopupMenu *BreedPopup;
	TMenuItem *Delete;
	void __fastcall FormShow(TObject *Sender);
	void __fastcall RememberClick(TObject *Sender);
	void __fastcall BreedShortChange(TObject *Sender);
	void __fastcall BreedViewDblClick(TObject *Sender);
	void __fastcall BreedViewColumnClick(TObject *Sender, TListColumn *Column);
	void __fastcall BreedViewClick(TObject *Sender);
	void __fastcall DeleteClick(TObject *Sender);
  void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
private:
	int edited;             		// ��������� ������ ������������� ������
	StringList *breed_list;     // ������ - ������, �������, ���
	friend int __stdcall Sorter(long a,long b,long);
public:
	char notify;                // ������
	short cookie;
	void 							 __fastcall Render();
										 __fastcall TBreedForm(TComponent* Owner);
										 __fastcall ~TBreedForm();
	const StringList * __fastcall GetBreedList() const { return breed_list; }
	StringList * 			 __fastcall GetBreedList() { return breed_list; }
	bool							 __fastcall DiffGroups(unsigned short a,unsigned short b);
	void 			 				 __fastcall Clear();
  int                __fastcall FindBreed(const char *p);
	friend void TPopulationWin::SaveAll(AnsiString);
	friend void TPopulationWin::LoadAll(AnsiString,bool);
};

//---------------------------------------------------------------------------

extern TBreedForm *BreedForm;

//---------------------------------------------------------------------------
#endif
