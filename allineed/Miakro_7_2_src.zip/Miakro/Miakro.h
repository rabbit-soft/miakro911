#ifndef MiakroH
#define MiakroH

//#define DBG ************
//#define SHOW_NAME_KEYS
//#define SHOW_KEYS

//---------------------------------------------------------------------------

#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ComCtrls.hpp>
#include <vcl\Menus.hpp>
#include <locale.h>
#include <fstream.h>

#include "rusctype.h"
#include <vcl\Dialogs.hpp>
#include <ExtCtrls.hpp>
#include <ImgList.hpp>

#define DELIMITER ","
#define MAX_COLUMNS 13 // ����� �������� � ������

enum W_ID { RAB_W,BUI_W,TRA_W,ZOO_W,YOU_W,REP_W,ARC_W,MAX_W };  // ��� ��� ����������� ���������
extern TForm *form_array[MAX_W];
extern String FileDate,FileWithoutTime;

class Rabbit;
class ListRab;

enum 					 { DATE_STATUS,ALL_STATUS,SEL_STATUS,FILTER_STATUS }; // ������-���
enum OPEN_MODE { NEW_ENTRY,EDIT_ENTRY,OTSAD_BOYS,SELL_ENTRY,MAX_ENTRIES };
enum RCASE 		 { NOMINATIVE,GENITIVE,DATIVE,ACCUSATIVE,MAX_RCASE };

extern const unsigned char enter,del_key;
extern bool old_file_version,version_2_0,version_2_2,version_3_0,version_3_1,version_3_9,version_4_2,version_4_2,version_4_3,version_5_0,version_5_1,version_6_1,version_6_2;

char *GetStr(TStream& s); 		// �� new
char *GetBufStr(TStream& s);  // ����������� �����
TStream& PriceOut(TStream& s,const Currency& c);
TStream& PriceIn(TStream& s,Currency& c);
void PutStr(TStream& s,const char *src);
void PutStr(TStream& s,String A);
void SaveCombo(TStream& s,const TComboBox *combo);
void LoadCombo(TStream& s,TComboBox *combo);
String& NoBreak(const char *p);

TStream& __fastcall operator >> (TStream& s,TListView *lw);
TStream& __fastcall operator << (TStream& s,TListView *lw);

bool StrCmp(const char *a,const char *b);

Decler(int x);
const char *WorkDecl(int x);
TListItem *HandleScroll(TObject *Sender,int x,int y);

const char * RabDecl(int x,RCASE rcase);
bool TryNewEntry(TComboBox *cb);
extern unsigned short today;
extern const char *day_decl[3];
extern const char *secdecl[MAX_RCASE][3];
extern const char *map_file;

//---------------------------------------------------------------------------

class TPopulationWin : public TForm
{
__published:
	TStatusBar *PopulationStatus;
	TMainMenu *MainMenu1;
	TMenuItem *MareRabReport;
	TMenuItem *N2;
	TMenuItem *N3;
	TMenuItem *Viewbuilds;
	TMenuItem *ViewReport;
	TPopupMenu *RabPopup;
	TMenuItem *Income;
	TMenuItem *FindPlace;
	TMenuItem *N5;
	TMenuItem *Death;
	TMenuItem *MenuExit;
	TMenuItem *TabAbbr;
	TMenuItem *DoubleSurnames;
	TMenuItem *N8;
	TMenuItem *Heterosis;
	TMenuItem *Inbreeding;
	TMenuItem *Butcher;
	TMenuItem *Rassel;
	TMenuItem *OtsadBoys;
	TMenuItem *ShowActives;
	TMenuItem *N4;
	TMenuItem *Preview;
	TMenuItem *ViewZoo;
	TMenuItem *N1;
	TMenuItem *Holost;
	TMenuItem *OtsadGirls;
	TMenuItem *ViewNames;
	TMenuItem *ShowTierTypes;
	TMenuItem *ShowAreaTypes;
	TMenuItem *N11;
	TMenuItem *ShowBreeds;
	TMenuItem *ViewYoungs;
	TMenuItem *ShowFilter;
	TMenuItem *N12;
	TMenuItem *ParamWin;
	TMenuItem *SaveAs;
	TMenuItem *N9;
	TSaveDialog *SaveAsDialog;
	TMenuItem *OpenFarm;
	TOpenDialog *OpenDialog;
	TMenuItem *NewFarm;
	TMenuItem *Save;
	TMenuItem *SortFMenu;
	TMenuItem *N7;
	TMenuItem *DeathPart;
	TMenuItem *ButcherPart;
	TMenuItem *N13;
	TMenuItem *FixParents;
	TMenuItem *SplitGroup;
	TMenuItem *ToMother;
	TMenuItem *N14;
	TMenuItem *Import;
	TOpenDialog *ImportDialog;
	TMenuItem *GoToButcher;
	TListView *FakeButcherList;
	TMenuItem *ButcherList;
	TMenuItem *N15;
	TMenuItem *About;
	TMenuItem *Print;
	TMenuItem *N6;
	TMenuItem *N10;
	TMenuItem *MoverWin;
	TMenuItem *Exchange;
	TMenuItem *N16;
	TMenuItem *FillSuckers;
	TMenuItem *ArcWinView;
	TMenuItem *N17;
	TMenuItem *MarkSection;
  TMenuItem *WhoIsPregnant;
  TMenuItem *FullGroupSplit;
  TMenuItem *BonPassport;
  TMenuItem *N18;
  TMenuItem *PlemPreview;
  TMenuItem *PlemPrint;
  TMenuItem *AutoBon;
  TGroupBox *GenTreePanel;
  TSplitter *Splitter1;
  TListView *RabbitList;
  TTreeView *GenTree;
  TMenuItem *ShowGenTree;
  TMenuItem *N20;
  TMenuItem *N19;
  TMenuItem *PreviewSvid;
  TMenuItem *PrintSvid;
	TMenuItem *N21;
	TMenuItem *NumberBeforeName;
	TMenuItem *ShowNumbers;
	TImageList *Images;
	TMenuItem *N22;
	TMenuItem *IntegrityTest;
	void __fastcall ViewbuildsClick(TObject *Sender);
	void __fastcall ViewReportClick(TObject *Sender);
	void __fastcall IncomeClick(TObject *Sender);
	void __fastcall RabbitListDblClick(TObject *Sender);
	void __fastcall MenuExitClick(TObject *Sender);
	void __fastcall TabAbbrClick(TObject *Sender);
	void __fastcall RabbitListColumnClick(TObject *Sender, TListColumn *Column);
	void __fastcall RabbitListDragOver(TObject *Sender, TObject *Source, int X,	int Y, TDragState State, bool &Accept);
	void __fastcall DoubleSurnamesClick(TObject *Sender);
	void __fastcall HeterosisClick(TObject *Sender);
	void __fastcall InbreedingClick(TObject *Sender);
	void __fastcall FindPlaceClick(TObject *Sender);
	void __fastcall RasselClick(TObject *Sender);
	void __fastcall OtsadBoysClick(TObject *Sender);
	void __fastcall ShowActivesClick(TObject *Sender);
	void __fastcall DeathClick(TObject *Sender);
	void __fastcall ButcherClick(TObject *Sender);
	void __fastcall PreviewClick(TObject *Sender);
	void __fastcall ViewZooClick(TObject *Sender);
	void __fastcall RabbitListChange(TObject *Sender,TListItem *Item,TItemChange Change);
	void __fastcall HolostClick(TObject *Sender);
	void __fastcall OtsadGirlsClick(TObject *Sender);
	void __fastcall ViewNamesClick(TObject *Sender);
	void __fastcall ShowTierTypesClick(TObject *Sender);
	void __fastcall ShowAreaTypesClick(TObject *Sender);
	void __fastcall ShowBreedsClick(TObject *Sender);
	void __fastcall ViewYoungsClick(TObject *Sender);
	void __fastcall ShowFilterClick(TObject *Sender);
	void __fastcall ParamWinClick(TObject *Sender);
	void __fastcall RabbitListClick(TObject *Sender);
	void __fastcall SaveAsClick(TObject *Sender);
	void __fastcall OpenFarmClick(TObject *Sender);
	void __fastcall NewFarmClick(TObject *Sender);
	void __fastcall SaveClick(TObject *Sender);
	void __fastcall SortFMenuClick(TObject *Sender);
	void __fastcall DeathPartClick(TObject *Sender);
	void __fastcall ButcherPartClick(TObject *Sender);
	void __fastcall FixParentsClick(TObject *Sender);
	void __fastcall SplitGroupClick(TObject *Sender);
	void __fastcall ToMotherClick(TObject *Sender);
	void __fastcall ImportClick(TObject *Sender);
	void __fastcall GoToButcherClick(TObject *Sender);
	void __fastcall ButcherListClick(TObject *Sender);
	bool __fastcall FormHelp(WORD Command, int Data, bool &CallHelp);
	void __fastcall PrintClick(TObject *Sender);
	void __fastcall MoverWinClick(TObject *Sender);
	void __fastcall RabbitListDragDrop(TObject *Sender, TObject *Source,int X, int Y);
	void __fastcall AboutClick(TObject *Sender);
	void __fastcall ExchangeClick(TObject *Sender);
	void __fastcall FillSuckersClick(TObject *Sender);
	void __fastcall ArcWinViewClick(TObject *Sender);
	void __fastcall MarkSectionClick(TObject *Sender);
	void __fastcall WhoIsPregnantClick(TObject *Sender);
  void __fastcall FullGroupSplitClick(TObject *Sender);
  void __fastcall BonPassportClick(TObject *Sender);
  void __fastcall PlemPreviewClick(TObject *Sender);
  void __fastcall AutoBonClick(TObject *Sender);
  void __fastcall ShowGenTreeClick(TObject *Sender);
  void __fastcall PreviewSvidClick(TObject *Sender);
	void __fastcall FormCloseQuery(TObject *Sender, bool &CanClose);
	void __fastcall IntegrityTestClick(TObject *Sender);
private:
	int										not_passed;		// �������������
	void 			 __fastcall RestoreIfNeeded();
	int	 			 __fastcall CountAllRabbitsInList(bool with_suckers) const;
	void 			 __fastcall SaveAll(AnsiString FileName);
	void 			 __fastcall AfterLoad(bool show_all = true);
	void 			 __fastcall ConnectNamesAndRabbits(ListRab *lx,int& j);
	void __fastcall Shower();
	bool __fastcall IsNotOneLineSelected();
	void __fastcall DeleteDbfs();
	int  __fastcall Bonner(ListRab *lr);
	void __fastcall Genner(TTreeNodes *tns,const Rabbit *r,TTreeNode *tn);
public:
	char notify;
	bool crash;
	bool loading;
	String ThisFarm; // ��� ���� �����
	String FarmId;   // ����� ���������� �������� �����
	String OldName,DefaultName;
	ListRab *rabbits; 																					// ��������� ������ �������� ����������� ������� � ���� �� �����������!
			 __fastcall TPopulationWin(TComponent* Owner);
			 __fastcall ~TPopulationWin();
	void __fastcall RefreshStatus();
	void __fastcall RefreshRabbitListView(); 										// �������� �������� �� ������ rabbits
	void __fastcall ShowRabbit(Rabbit *r,TListItem *li = NULL); // �������� ������� � ������� ������
	void __fastcall Putter(TListItem *rabli,TListItem *buildli);
	void __fastcall ListUpdated();
	int	 __fastcall CountSelected(bool with_suckers) const; // ���������� ����� ����� ��������� �������� � ���������� ��� ��� ���
	bool __fastcall Passporter(Rabbit *r,TListItem *li = NULL);
	void __fastcall ResolveFuckers(); // ��������� ��������� �� ������ ������ ���
	void __fastcall LoadAll(AnsiString FileName,bool clear); // � ������������ ��� ���
	bool __fastcall ClearFarm(bool everything = false,bool norequest = false);
	void __fastcall SaveLastUsedFile() const;
	void __fastcall MakeMainTitle();
	void __fastcall Terminator(const char *p);
	void __fastcall PreviewOrPrintRabbits(bool print);
	void __fastcall PreviewOrPrintButcher(bool print);
	void __fastcall ScanLostDates(); 										// �������� ����������� �������
	int  __fastcall MakeSuckers(bool view);
	bool __fastcall IsFarmNotEmpty();
	bool __fastcall RabMarker(Rabbit *r,bool no_unselect = false);
	void __fastcall PrepareOldName();
  void __fastcall Store();
  void __fastcall RefreshGenTree(TTreeNodes *lia,const Rabbit *r);
};

//---------------------------------------------------------------------------

class TWaitCursor
{
	private:
		TCursor oldc;
	public:
		TWaitCursor(bool busy = false) : oldc(Screen->Cursor) { Screen->Cursor = TCursor (busy ? crAppStart : crHourGlass); }
		~TWaitCursor() { Screen->Cursor = oldc; }
};

//---------------------------------------------------------------------------

extern TPopulationWin *PopulationWin;

//---------------------------------------------------------------------------

#endif
 
 

