#ifndef ShedH
#define ShedH

//---------------------------------------------------------------------------

#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Chart.hpp>
#include <ExtCtrls.hpp>
#include <Series.hpp>
#include <TeEngine.hpp>
#include <TeeProcs.hpp>
#include <ComCtrls.hpp>
#include <Menus.hpp>

class RabInfo;
enum SHED_CHARTS { RAB_CHART,TIER_CHART,SEC_CHART,FREE_SEC_CHART,STAT_CHART,CLASS_CHART,MAX_CHARTS };

//---------------------------------------------------------------------------

class TShedForm : public TForm
{
__published:
  TPageControl *ShedPages;
  TTabSheet *TabSheet1;
  TTabSheet *TabSheet2;
  TChart *ShedChart;
  TChart *TierChart;
  TPieSeries *Series3;
  TTabSheet *TabSheet3;
  TTabSheet *TabSheet4;
  TChart *FreeSecChart;
  TPieSeries *PieSeries2;
  TChart *SecChart;
  TPieSeries *PieSeries1;
  TBarSeries *Series1;
  TBarSeries *Series2;
  TMainMenu *MainMenu1;
  TMenuItem *ShedMenu;
  TMenuItem *Print;
  TTimer *ShedTimer;
  TMenuItem *N1;
  TMenuItem *Rotation;
  TMenuItem *Quicker;
  TMenuItem *Slower;
  TTabSheet *RabbitPie;
  TChart *StatChart;
  TPieSeries *PieSeries3;
  TChart *ClassChart;
  TPieSeries *PieSeries4;
  TTabSheet *ClassPage;
  void __fastcall PrintClick(TObject *Sender);
  void __fastcall ShedTimerTimer(TObject *Sender);
  void __fastcall ShedPagesChange(TObject *Sender);
  void __fastcall FormShow(TObject *Sender);
  void __fastcall FormCloseQuery(TObject *Sender, bool &CanClose);
  void __fastcall RotationClick(TObject *Sender);
  void __fastcall QuickerClick(TObject *Sender);
  void __fastcall SlowerClick(TObject *Sender);
private:
  static TChart *shed_charts[MAX_CHARTS];
public:
       __fastcall TShedForm(TComponent* Owner);
  void __fastcall Render(const RabInfo *ri);
};

//---------------------------------------------------------------------------

extern PACKAGE TShedForm *ShedForm;

//---------------------------------------------------------------------------

#endif
