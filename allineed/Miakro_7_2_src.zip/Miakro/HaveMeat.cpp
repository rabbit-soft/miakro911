#include <vcl.h>
#pragma hdrstop

#include "HaveMeat.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"
THaveMeatForm *HaveMeatForm;

//---------------------------------------------------------------------------

__fastcall THaveMeatForm::THaveMeatForm(TComponent* Owner) : TForm(Owner)
{
}

//---------------------------------------------------------------------------
