#ifndef ZonesH
#define ZonesH

//---------------------------------------------------------------------------

#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ComCtrls.hpp>
#include "Rabbit.h"

class StringList;

//---------------------------------------------------------------------------

class TZoneForm : public TForm
{
__published:
	TListView *ZoneView;
	TGroupBox *GroupBox1;
	TEdit *FullName;
	TEdit *ShortName;
	TEdit *Gen;
	TLabel *Label1;
	TLabel *Label2;
	TLabel *Label3;
	TButton *Ok;
	TButton *Cancel;
	TButton *Auto;
	TButton *Add;
	void __fastcall FullNameChange(TObject *Sender);
	void __fastcall ShortNameChange(TObject *Sender);
	void __fastcall GenChange(TObject *Sender);
	void __fastcall AddClick(TObject *Sender);
	void __fastcall AutoClick(TObject *Sender);
	void __fastcall ZoneViewChange(TObject *Sender, TListItem *Item,TItemChange Change);
	void __fastcall OkClick(TObject *Sender);
	void __fastcall FormShow(TObject *Sender);
	void __fastcall ZoneViewDblClick(TObject *Sender);
private:
	TListItem *edit_item;
	const char * __fastcall CutStart(const char *p);
	void 				 __fastcall TestDone(void);
public:
	StringList *zone_list;
	unsigned short cookie; 						// ������� ����� ����
	void 				 __fastcall Render();
							 __fastcall TZoneForm(TComponent* Owner);
							 __fastcall ~TZoneForm() { delete zone_list; }
	StringList * __fastcall GetZoneList() const { return zone_list; }
	void 				 __fastcall Clear() { zone_list->ClearStrings(); ZoneView->Items->Clear(); }
};

//---------------------------------------------------------------------------

extern TZoneForm *ZoneForm;

//---------------------------------------------------------------------------

#endif
