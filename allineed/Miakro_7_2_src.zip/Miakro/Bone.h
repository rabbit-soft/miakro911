#ifndef BoneH
#define BoneH

//---------------------------------------------------------------------------

#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Menus.hpp>

#include "Rabbit.h"

extern const char * const bon_names[];

//---------------------------------------------------------------------------

class TBoneForm : public TForm
{
__published:
  TGroupBox *GroupBox1;
  TLabel *Label1;
  TComboBox *Weight;
  TLabel *Label2;
  TComboBox *Body;
  TLabel *Label3;
  TComboBox *Hair;
  TLabel *Label4;
  TComboBox *Color;
  TLabel *ClassLabel;
  TLabel *BoneLabel;
  TButton *Ok;
  TButton *Cancel;
  void __fastcall ComboChange(TObject *Sender);
  void __fastcall FormShow(TObject *Sender);
private:
public:
  char notify;
  Rabbit *rabbit;
  Bon CurBon;
  __fastcall TBoneForm(TComponent* Owner);
};

//---------------------------------------------------------------------------

extern PACKAGE TBoneForm *BoneForm;

//---------------------------------------------------------------------------

#endif
