#include <vcl.h>
#pragma hdrstop

#include "LossRep.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"
TLossRepForm *LossRepForm;

//---------------------------------------------------------------------------

__fastcall TLossRepForm::TLossRepForm(TComponent* Owner) : TForm(Owner)
{
}

//---------------------------------------------------------------------------



